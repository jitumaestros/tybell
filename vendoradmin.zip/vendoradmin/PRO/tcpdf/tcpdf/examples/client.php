<?php
//============================================================+
// File name   : example_048.php
// Begin       : 2009-03-20
// Last Update : 2013-05-14
//
// Description : Example 048 for TCPDF class
//               HTML tables and table headers
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: HTML tables and table headers
 * @author Nicola Asuni
 * @since 2009-03-20
 */

// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');
include('c.php');

$n='1';


                  

               $sqlii=mysqli_query($conn,"select * from users where role='0'");
                  while($users=mysqli_fetch_array($sqlii)){
    $book=mysqli_num_rows(mysqli_query($conn,"select * from bookings where user_id='".$users['id']."' and status!='2'"));
    $books=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where user_id='".$users['id']."' and status!='2' order by id desc"));
   $time1a = $books['dates'];

                $time2a =strtotime('now');

                $diffdhgg = $time2a-$time1a;
                date("d H:i:s",$diffdhgg);
                $days = $diffdhgg / 86400;
                $day_explode = explode(".", $days);
                $d = $day_explode[0];

                $hours = '.'.$day_explode[1].'';
                $hour = $hours * 24;
                $hourr = explode(".", $hour);
                $h = $hourr[0];

                $minute = '.'.$hourr[1].'';
                $minutes = $minute * 60;
                $minute = explode(".", $minutes);
                $m = $minute[0];

                $seconds = '.'.$minute[1].'';
                $second = $seconds * 60;
                $s = round($second);


                if($h==1){

                $hr=$h.' hour';
                }

                else{

                $hr=$h.' hours';

                }

                $hour =$da *24+$ha;

                $day =$d;

                $month =$d/30;
                $years =$d/365;

                $week =$d/7;
                $weeks =round($week, 0);

                if($weeks==1){

                $weeksdss=$weeks.' Semana';
                }

                else{

                $weeksdss=$weeks.' Semanas';

                }

                if($day==1){

                $dayd=$day.' día';
                }

                else{

                $dayd=$day.' dias';

                }
                $monthd =round($month, 0);

                $year1 =round($years, 0);

                if($monthd==1){

                $monthddd=$monthd.' mes';
                }

                else{

                $monthddd=$monthd.' meses';

                }

                if($year1==1){

                $year12=$year1.' año';
                }

                else{

                $year12=$year1.' años';

                }

                if($day >='365'){

                $duratingD=$year12;

                }


                else if($day >='30'){

                $duratingD=$monthddd;

                }

                else if($day >= '7'){

                $duratingD=$weeksdss;

                }

                else if($day > '0'){
                $duratingD=$dayd;

                }


                else if($h > '0'){
                $duratingD=$hr;

                }

                else{

                $duratingD=$m.' Min';

                }

        

$datess = date('d-m-Y',$books['dates']).'hace'.$duratingD;


$my_html .= '<tr>
<td>'.$n++.'</td>
<td>'.$users['first_name'].' '.$users['last_name'].'</td>
<td>'.$users['phone'].'</td>
<td>'.$users['email'].'</td>
<td>'.$book.'</td>

<td>'.$datess.'</td>


 </tr>';
  }



// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 048');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
/*$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 048', PDF_HEADER_STRING);
*/
// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
  require_once(dirname(__FILE__).'/lang/eng.php');
  $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', 'B', 20);

// add a page
$pdf->AddPage();

$pdf->Write(0, 'Cliente', '', 0, 'L', true, 0, false, false, 0);



$pdf->SetFont('helvetica', '', 8);

// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------

// NON-BREAKING TABLE (nobr="true")



// -----------------------------------------------------------------------------

// NON-BREAKING ROWS (nobr="true")

$tbl =<<<EOD
<table border="1" align="center">
      
 <tr>
 
 <th>S.No</th>
  <th>Nombre Apellido</th>
  <th> Número de teléfono</th>
  <th>Correo electronico</th>
  <th>Reservas</th>
  <th>Ultima visita </th>

</tr>

$my_html

</table>
EOD;

$pdf->writeHTML($tbl, true, false, false, false, '');

// -----------------------------------------------------------------------------

//Close and output PDF document
//$pdf->Output('example_048.pdf', 'I');
$pdf->Output('client.pdf', 'D');


//============================================================+
// END OF FILE
//============================================================+
