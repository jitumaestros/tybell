<?php include('../common/config.php');

extract($_POST);

$sql=mysqli_query($conn,"SELECT * FROM `users` WHERE `email`='$email' and role='2' ");
$count=mysqli_num_rows($sql);
if($count){
	
$fetch=mysqli_fetch_array($sql);

	if($fetch['password']==$password){

	$_SESSION['user_id']=$fetch['id'];
	 echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>
Inicio de sesión exitoso. por favor espera</span>
</div></div>';




echo  '<script>function auto_refresh(){
       window.location="vendoradmin/dashboard.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';



	

 }

		
	else{


		 echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>
Por favor ingrese la contraseña correcta</span>
</div></div>';
		
		
		}
	
}
	

else{

echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Por favor, introduzca el correo electrónico correcto o la contraseña
</span>
</div></div>';


	
	
	}

?>





