<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Blog management</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Top publications</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		<div class="conmment_img_div" >
			<img src="img/camera.jpg" width="100%" class="img-responsive" style="  max-width: 200px;"> 
			<div class="upload_img">
				<button>Upload Image</button>
				<input type="file" name="">
			</div>
			
		</div>
		
		
		<div class="col-sm-12">
			<div class="form-group">
				<label>Topical Title</label>
				<input type="text" class="form-control" name="" >
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>Topical Description</label>
				<textarea class="form-control"> 
				</textarea>
			</div>
		</div>
	
		
		
		<button class="addsalonbtn">Comment Save</button>
		

	</div>
</div>
<?php include ('footer.php');?>