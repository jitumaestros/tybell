<?php include ('header.php');

if (isset($_GET['deleteid'])) {
mysqli_query($conn,"delete from customer where id='".$_GET['deleteid']."'");

	echo"<script>alert('Borrado exitosamente');window.location='removecustomer.php';</script>";
}


?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0"> Clientes</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active"> Clientes</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		
		<div class="table-respnsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<th>S.No.</th>
					<th >Nombre del cliente</th>
					<th>Dirección del cliente</th>
					<th>Número de teléfono móvil</th>	
					<th>Teléfono de casa</th>

					<th>Dirección de correo electrónico del cliente</th>
					<th>Imagen</th>
				<th>Editar</th>
						<th>Retirar</th>

					<th colspan="2"></th>
				</thead>
				<tbody>

				<?php $n='1';
				$sqli=mysqli_query($conn,"select * from customer order by id desc");
while($custm=mysqli_fetch_array($sqli)){

				?>
					<tr>
						<td><?php echo $n++;?></td>
						<td><?php echo $custm['firstname'];?> <?php echo $custm['lastname'];?></td>
						<td><?php echo $custm['address'];?> </td>
						<td><?php echo $custm['mobile_number'];?> </td>
						<td><?php echo $custm['home_phone'];?> </td>
						<td><?php echo $custm['email_address'];?> </td>
						<td><img src="img/<?php echo $custm['image'];?>" width="130px"> </td>
						
						<td><a href="modify_customer.php?id=<?php echo $custm['id'];?>"><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						<td><a href="?deleteid=<?php echo $custm['id']; ?>" onclick="return confirm('Estas seguro que quieres borrarlo');"><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
						
					</tr>
					<?php }?>
					<!-- <tr>
						<td>1</td>
						<td>Lorem Ipsum</td>
						<td>Lorem Ipsum is simply dummy text </td>
						<td>1532565t </td>
						<td>abc@gmail.com </td>
						<td>11/2/2016</td>
						<td>11:00 to 10:00</td>
						
						<td><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						<td><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
						
					</tr> -->
				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>