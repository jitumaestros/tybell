<?php include ('header.php');?>
	<div class="finance_wrapper">
		<div class="finanace_blog">
			<p>Total Earnings through Dala3</p>
			<p>* including commission and fees</p>
			<h1>$15</h1>
			<table class="table  table-bordered table-hover">
				<thead>
					<tr>
						<th>Number</th>
						<th>Invoice period</th>
						<th>Amount</th>
						<th>End of period balance</th>
						<th>Items</th>
						<th>Status</th>
						<th>Detailed report</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>UK28872-1</td>
						<td>01/11/2018 - 15/11/2018</td>
						<td>$6.3</td>
						<td>$6.3</td>
						<td>1</td>
						<td>
							<div class="tooltip_hover">
								<span class="paymen_recie">Payment Received <i class="fa fa-info"></i></span>
								<div class="payment_NOTE">
									<div class="title_pay">
										Notes
									</div>
									<div class="contetn_hover">
										Thank you this invoice has been settied no further action required
									</div>
								</div>
							</div>
						</td>
						<td><i class="fa fa-download"></i> Download PDF</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>


<?php include ('footer.php');?>