<?php include('../common/config.php');

  extract($_POST);

$dates=strtotime('now');


   $feedback1 = mysqli_real_escape_string($conn,$feedback);

   $book=mysqli_fetch_array(mysqli_query($conn,"select * from bookings  where id='$salon_id'"));

 $check= mysqli_query($conn,"INSERT INTO feedback (user_id, salon_id, rating, feedback, strtotime,ambience,staff,cleanliness,booking_id)VALUES ('".$_SESSION['user_id']."', '".$salon_id."', '$rating', '$feedback1', '$dates','$ambience','$staff','$cleanliness','$booking_id')");

 $insert_id= mysqli_insert_id($conn);

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Revisión enviada con exitosamente</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="completed_Reservas.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 ?>


