<?php include('../common/config.php');


if($_GET['id']=='1'){
$blogf=mysqli_fetch_array(mysqli_query($conn,"select * from blog_home where id='".$_GET['id']."'"));

}else{

$blogf=mysqli_fetch_array(mysqli_query($conn,"select * from publication where id='".$_GET['id']."'"));

}

$titles=$blogf['title'];

 $urls="https://maestrosinfotech.com/Tybell/treatment-files/blog_deatils.php?id=".$_GET['id']."";

$imagef=$blogf['image'];

   $imagelink="https://maestrosinfotech.com/Tybell/image/$imagef";

$titledata=$titles;


?>

 
<!DOCTYPE html>

<html lang="en">

<head>

  <title>Tybell</title>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta property="fb:app_id" content="398107417551833" />
           <meta property="og:title" content="<?php echo $titledata; ?> ">

            <meta property="og:site_name" content="Tybell " />

             <meta property="og:description" content="tybell ">
            <meta property="og:image"  content="<?php echo $imagelink;?>">
            <meta property="og:url" content="<?php echo $urls;?>">
            <meta property="og:site_name" content="<?php echo $baseurl.'treatment-files/blog_deatils.php?id='.$_GET['id']; ?>">

  <link rel="stylesheet" href="css/bootstrap.min.css">

  
<link href="https://unpkg.com/@ionic/core@latest/css/ionic.bundle.css" rel="stylesheet">

  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">


  <script src="js/jquery.min.js"></script>

  <script src="js/bootstrap.min.js"></script>


<script src="js/jquery-1.11.3.min.js"></script>


  <script src="https://unpkg.com/@ionic/core@latest/dist/ionic.js"></script>

<link rel="stylesheet" type="text/css" href="css/style.css">

<link rel="stylesheet" type="text/css" href="css/treatment-files.css">
<link rel="stylesheet" type="text/css" href="../css/responsive.css">

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

<style type="text/css">
	body{
		display: block !important;	
	}
</style>
  

</head>

	<header>

		<nav class="navbar navbar-inverse">

		  <div class="container">

		  	<div class="top_nav_bar">

		  		<div class="col-sm-4">

					<div class="contact_wrapper text-left">

						<h1>Blog</h1>

					</div>

				</div>

				<div class="col-sm-4">

					<div class="logo_div text-center">

						<a href="../index.php"><p class="logo_1">Tybell</p></a> 

					</div>

				</div>

				<div class="col-sm-4">

				
				</div>

		  	</div>

		  </div>

			


			 <div class="container">

			  <div class="overflow-h">

				

				    <div class="navbar-header">

				      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">

				        <span class="icon-bar"></span>

				        <span class="icon-bar"></span>

				        <span class="icon-bar"></span>                        

				      </button>

				      

				    </div>

				    <div class="collapse navbar-collapse" id="myNavbar">

				      <ul class="nav navbar-nav header_menu">	       

			        		

				        <li><a href="index.php">HOME</a></li>
<!-- 				        <li><a href="blog_deatils.php">User Questions</a></li>
 -->				        <li><a href="../treatment_guide.php">Tybell Guides</a></li>


				       <!--  <li><a href="#">EDITOR’S PICKS</a></li>

				        <li><a href="#">DON’T TRY THIS AT HOME</a></li> -->

				       <!--  <li><a href="#">BEAUTY BOARD</a></li>

				        <li><a href="#">TREATMENT GUIDE</a></li> -->

				        <li><a href="search_bar.php"><i class="fa fa-search"></i></a></li>

				        

				      </ul>

				     

				    </div>

				  </div>		

				</div>



				<div class="drop_down" id="db1" style="display: none;">

			        			<div class="container">

			        				<div class="col-sm-4">

			        					<div class="content_blog_db_1">

			        						<ul class="list_menu_bd">

			        							<li><a href="">Haircuts and Hairdressing</a></li>

			        							<li><a href="">Blow Dry</a></li>

			        							<li><a href="">Ladies' Hair Colouring & Highlights</a></li>

			        							<li><a href="">Ladies' Brazilian Blow Dry</a></li>

			        							<li><a href="">Balayage & Ombre</a></li>

			        							<li><a href="">Men's Haircut</a></li>

			        							<li><a href=""><b>See all hair treatments</b></a></li>

			        						</ul>

			        					</div>

			        				</div>

			        				<div class="col-sm-4">

			        					<a href="">

			        						<div class="blog_2db">

				        						<div class="img_blog1">

				        							<div class="img_main_db">

				        								<img src="img/db1.jpg">

				        							</div>

				        						</div>

				        						<div class="content_blog_bd">

				        							<p>Last minute? Cuts near you</p>

				        						</div>

				        					</div>

			        					</a>	        					

			        					

			        				</div>

			        				<div class="col-sm-4">

			        					<a href="">

			        						<div class="blog_2db">

				        						<div class="img_blog1">

				        							<div class="img_main_db">

				        								<img src="img/db1.jpg">

				        							</div>

				        						</div>

				        						<div class="content_blog_bd">

				        							<p>Last minute? Cuts near you</p>

				        						</div>

				        					</div>

			        					</a>

			        				</div>

			        			</div>

			        		</div>

			</nav>

		

	</header>



	<script type="">

	function toggless1(id){

		$('.addclass').toggleClass('active_db');

		$('#'+id).toggle();



	}



</script>

<body>