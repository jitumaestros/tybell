<?php include('../common/config.php');

  extract($_POST);

$dates=strtotime('now');

$image=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], "../image/".$image);


       $description1 = mysqli_real_escape_string($conn,$description);

 $check= mysqli_query($conn,"INSERT INTO comment (user_id, title, description, image, strtotime)VALUES ('".$_SESSION['user_id']."', '$title', '$description1', '$image', '$dates')");

 $insert_id= mysqli_insert_id($conn);

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Comentario agregado exitosamente</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="comment.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 ?>


