<?php include('../../common/config.php');

extract($_POST);

$vide=mysqli_query($conn,"delete from likes where user_id ='".$_SESSION['user_id']."' and post_id='$id' and status='0' and comment_id='$comment_id'");
 $likescounts=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$id."' and status='0' and comment_id='$comment_id'"));

if($vide){



    ?>
				 <a href="javascript:;" onclick="likevdeo('<?php echo $id;?>','<?php echo $_SESSION['user_id'];?>','<?php echo $comment_id;?>');"><i class="fa fa-thumbs-o-up" aria-hidden="true" style="margin-left:110px; font-size: 18px"></i><?php echo $likescounts;?></a></span>

<?php   }else{

echo '<div class="alert alert-danger"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong > Error..</strong></div>'; 

}
?>