<?php include ('header.php');?>
<main class="">
    <div class="container">

      

        <div class="search_widget">
            <form action="" class="search_form" >
                <div class="search_widget_label">Search for:</div>
                <div class="search_widget_input">
                    <input name="s" type="text" id="s" value="">
                </div>
                <div class="search_widget_button">
                    <button><span>Search <i class="fa fa-search"></i></span></button>
                </div>
                <!--        <input name="action" type="hidden" value="searchPosts" />-->
            </form>
        </div>


      
    </div>
</main>
<?php include ('footer.php');?>