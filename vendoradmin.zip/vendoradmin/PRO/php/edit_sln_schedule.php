<?php include('../../../common/config.php');
extract($_POST);

$check= mysqli_query($conn,"update salon_opening_hr set day='$day', start_time='$start_time', end_time='$end_time' where id='$ids'");

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Horario de apertura editado con éxito.</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="setting.php?setting=setting";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
  echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

  
}

 


?>