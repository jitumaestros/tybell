<div id="myModaldele" class="modal fade" role="dialog">
  <div class="modal-dialog" style="    margin-top: 97px;
  margin-right: 254px;">

  <!-- Modal content-->
  <div class="modal-content" style=" width: 83%;
    height: 197px;">
    <div class="modal-header">
      <button type="button" class="close" data-dismiss="modal">&times;</button>
      <h4 class="modal-title">Confirmar reservaciones</h4>
                    <div id="selectjobsdsgg"></div>

    </div>
    <div class="modal-body">
      <p>¿Estás seguro de que quieres confirmar las reservas?</p>
    </div>


    <div>

      <a href="javascript:;" onclick="confirmbooking('<?php echo $_POST['id'];?>');"><button type="button" class="btn btn-default" style="  margin-left: 40px;
        font-size: 18px;
        color: white;background: #BB2A59;    margin-bottom: 49px;">Sí</button>

        <button type="button" class="btn btn-default"  data-dismiss="modal" style=" margin-left: 120px;
        font-size: 18px;
        color: white;background: #BB2A59; color:white;    margin-bottom: 49px;">Cancelar</button>
        <br>

      </div>

<!--       <div class="modal-footer">
-->        <!-- <button type="button" class="btn btn-default" data-dismiss="modal">Close</button> -->
<!--       </div>
-->  


  </div>

</div>
</div>
<script>
  function confirmbooking(id)
  {
   // alert(id);
    $.ajax({
     type: "POST",
     url: "php/confirmbooking.php",
     data: "id="+id,
     success: function(html)
     {     
      $("#selectjobsdsgg").html(html);
   // alert(html);

    }


  });

  }


</script>