<?php include ('header.php');

if (isset($_POST['submit'])) {

if($_FILES['file']['name']){
$r= mt_rand();
$filess = "";
foreach ($_FILES['file']['name'] as $key => $value) {

 
  $file_name=str_replace(' ', '_', $_FILES["file"]["name"][$key]);
  $filess .= $file_name.",";
      
                $file_tmp=$_FILES["file"]["tmp_name"][$key];
  move_uploaded_file($file_tmp, "../image/".$file_name);


}
}
$filessa = substr($filess,0,-1);


  extract($_POST);

		$select = mysqli_query($conn,"SELECT * FROM users where name='$salonname'");
 		$checkuser= mysqli_num_rows($select);
 		if ($checkuser >0) {
	 $msg= '<div class="col-sm-12"><div class="alert alert-danger ">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    Already Add This salon
  </div></div>';
}				

else{


 $check= mysqli_query($conn,"INSERT INTO users (business_name, adress, contact_number,salon_desc, salon_pic, first_name,last_name, email, phone,role,latitude,longitude,district,password)VALUES ('$salonname','$salonaddress','$m_number','$salon_des','$filessa','$first_name','$last_name','$email','$m_number','2','$latitude','$longitude','$district','$password')");
 		$insert_id= mysqli_insert_id($conn);

 if ($check) {
   $msg= '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Add salon sucessful</span>
</div></div>';
$msg.=  '<script>function auto_refresh(){
       window.location="removesalon.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
 else{
	$msg='error';
}
}

}

 ?>


<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Add Salon</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Add Salon</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
          
        </div>
    </div>
   <form method="post" >
    	<?php echo $msg;?>
   
	<div class="addsalon">
		<h3>Fields to create a salon:</h3>
		<div class="salon_img_div" style="background: url('img/camera.jpg');">
			<input type="file" class="choosefile" name="file[]" multiple="multiple">
		</div>
		
		
  		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Name</label>
				<input type="text" class="form-control" placeholder="" name="salonname" required>
			</div>
		</div>

		<div class="col-sm-6">
			<div class="form-group">
				<label>First name</label>
				<input type="text" class="form-control" placeholder="" name="first_name" required>
			</div>
		</div>


<div class="col-sm-6">
			<div class="form-group">
				<label>Last Name</label>
				<input type="text" class="form-control" placeholder="" name="last_name" required>
			</div>
		</div>


		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Email Address</label>
				<input type="email" class="form-control" placeholder="" name="email" required>
			</div>
		</div>

       <div class="col-sm-6">
			<div class="form-group">
				<label>Salon Password</label>
				<input type="password" class="form-control" placeholder="" name="password" required>
			</div>
		</div>

		<div class="col-sm-6">
			<div class="form-group">
				<label>District</label>
				<select class="form-control" name="district" required>
                <option value="">Select district</option>
                <?php $serv=mysqli_query($conn,"select * from district ");

             		while($sernm=mysqli_fetch_array($serv)){

             			?>
             			<option value="<?php echo $sernm['id'];?>"><?php echo $sernm['name'];?></option>

             			<?php }?>		

             		</select>
			</div>
		</div>

		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Address</label>
				<input type="text" class="form-control" placeholder="" name="salonaddress"  id="txtPlacesss" required>
			</div>
		</div>

		<input type="hidden" name="latitude" id="latitude">
							<input type="hidden" name="longitude" id="longitude">

		<div class="col-sm-6">
			<div class="form-group">
				<label>Mobile Number</label>
				<input type="text" class="form-control" placeholder="" name="m_number" required>
			</div>
		</div>
		
		<!-- <div class="col-sm-6">
			<div class="form-group">
				<label>Salon Started Date in Tybell</label>
				<input type="date" class="form-control" name="salon_stard_date" required>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Creation Date</label>
				<input type="date" class="form-control" name="salon_create_date" required>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Open Time</label>
				<input type="time" class="form-control"  name="salon_open_time" required>
			</div>
		</div> -->
		<!-- <div class="col-sm-6">
			<div class="form-group">
				<label>Salon Close Time</label>
				<input type="time" class="form-control" name="salon_close_time" required>
			</div>
		</div> -->
		<div class="col-sm-12">
			<div class="form-group">
				<label>Short Description in salon</label>
				<textarea class="form-control" name="salon_des">
					
				</textarea>
			</div>
		</div>	
		
	</div>
	<br>
	<div class="addsalon">
		<h3>Fields to create a Salon Manager:</h3>
		<div class="col-sm-12">
			<div class="form-group">
				<label>General Manager Name</label>
				<input type="text" class="form-control" name="vendor_name" >
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>Email </label>
				<input type="text" class="form-control" name="vendor_email">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>Phone</label>
				<input type="text" class="form-control" name="vednor_phone">
			</div>
		</div>
		<button class="addsalonbtn" name="submit" type="submit">Add Salon </button>
		
	</div>
</form>
</div>
<?php include ('footer.php');?>
<script type="text/javascript">
	
	$(document).ready(function (profil) {
 $("#editprof").on('submit',(function(profil) {
 	//alert();
  $("#form_abc1_img").show();
  profil.preventDefault();
  $.ajax({
   url: "php/edit_profile.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
     $("#form_abc1_img").hide();
 // alert(data);
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});
</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE&sensor=false&libraries=places"></script>

<script type="text/javascript">

  google.maps.event.addDomListener(window, 'load', function () {

/*    var options = {

      componentRestrictions: {country: "in"}
    };*/
    var places = new google.maps.places.Autocomplete(document.getElementById('txtPlacesss'));

    google.maps.event.addListener(places, 'place_changed', function () {

      var place = places.getPlace();

      var address = place.formatted_address;

      var latitude = place.geometry.location.lat();

      var longitude = place.geometry.location.lng();

      var mesg = "Address: " + address;

      mesg += "\nLatitude: " + latitude;

      mesg += "\nLongitude: " + longitude;


      $("#latitude").val(latitude);
      $("#longitude").val(longitude);

    });

  });

</script>
