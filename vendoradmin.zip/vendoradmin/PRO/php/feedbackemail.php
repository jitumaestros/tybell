<style>@media only screen and (max-device-width: 700px) {
      .table-wrapper {
        margin-top: 0px !important;
        border-radius: 0px !important;
      }
      .header {
        border-radius: 0px !important;

      }
    }
    </style>
  </head>
<?php include('../../../common/config.php');

extract($_POST);

mysqli_query($conn,"insert into feedbackemail set salon_id='$ids',email='$email'");
$inser = mysqli_query($conn,"select * from users where id='".$ids."' ");

  if(mysqli_num_rows($inser)>0){

$anddsf = mysqli_fetch_array($inser);
$sonm='needs your helkp!';
$fullname=$anddsf['business_name'].' '.$sonm;

  $messagetrrt.=' <body style="-webkit-font-smoothing:antialiased;-webkit-text-size-adjust:none;margin:0;padding:0;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-size:100%;line-height:1.6">

    <table style="background: #F5F6F7;" width="100%" cellpadding="0" cellspacing="0">

      <tbody><tr>

        <td>

          <table cellpadding="0" cellspacing="0" class="table-wrapper" style="margin:auto;margin-top:50px;border-radius:7px;-webkit-border-radius:7px;-moz-border-radius:7px;max-width:700px !important;box-shadow:0 8px 20px #e3e7ea !important;-webkit-box-shadow:0 8px 20px #e3e7ea !important;-moz-box-shadow:0 8px 20px #e3e7ea !important;box-shadow: 0 8px 20px #e3e7ea !important; -webkit-box-shadow: 0 8px 20px #e3e7ea !important; -moz-box-shadow: 0 8px 20px #e3e7ea !important;">

            <tbody><tr>
      
                <td class="container" bgcolor="#FFFFFF" style="display:block !important;margin:0 auto !important;clear:both !important;background: #2AD8A7;padding: 25px 35px;">

                  <img src="https://maestrosinfotech.com/Tybell/img/logo.png" style="max-width:145px">
               </td>
            </tr>
            <tr>
              <td class="container content" bgcolor="#FFFFFF" style="padding:35px 40px;border-bottom-left-radius:6px;border-bottom-right-radius:6px;display:block !important;margin:0 auto !important;clear:both !important">

  <div class="content-box" style="max-width:600px;margin:0 auto;display:block">
<h4 style="font-family:&quot;Helvetica Neue&quot;, Helvetica, Arial, &quot;Lucida Grande&quot;, sans-serif;margin-bottom:15px;color:#47505E;margin:0px 0 10px;line-height:1.2;font-weight:200;font-size:13px;font-weight:bold;margin-bottom:30px">Hola</h4>

<p style="font-weight:normal;padding:0;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;line-height:1.7;margin-bottom:1.3em;font-size:15px;color:#47505E">

Como uno de nuestros valiosos clientes, nos encantó que dejaras una reseña: actualmente estamos en el proceso de configurar nuestro perfil en línea con Tybell y tu opinión realmente podría marcar la diferencia.
</p>
<p style="font-weight:normal;padding:0;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;line-height:1.7;margin-bottom:1.3em;font-size:15px;color:#47505E">

Tomará menos de un minuto y su comentario nos permitirá compartir nuestra reputación con cualquier visitante futuro y nos ayudará a hacer crecer nuestra familia de clientes.
</p>
<p style="font-weight:normal;padding:0;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;line-height:1.7;margin-bottom:1.3em;font-size:15px;color:#47505E">Muy apreciado,<br>'.$anddsf['business_name'].'</p>

  </div>

  </td>

<td>

 </td>

     </tr>

       </tbody></table>

          <div class="footer" style="padding-top:30px;padding-bottom:55px;width:100%;text-align:center;clear:both !important">

            <p class="social-icons" style="font-weight:normal;padding:0;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;line-height:1.7;margin-bottom:1.3em;font-size:15px;color:#47505E;font-size:12px;color:#666;padding-top:5px">

              <a href="" style="color:#1EA69A;word-wrap:break-word;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight:800;color:#999;color:#049075 !important"><img width="25" src="http://cdn2.hubspot.net/hubfs/677576/email-fb.png" style="max-width:100%"></a>

              <a href="" style="color:#1EA69A;word-wrap:break-word;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight:800;color:#999;color:#049075 !important"><img width="25" src="http://cdn2.hubspot.net/hubfs/677576/email-twitter.png" style="max-width:100%"></a>

              <a href="" style="color:#1EA69A;word-wrap:break-word;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight:800;color:#999;color:#049075 !important"><img width="25" src="http://cdn2.hubspot.net/hubfs/677576/email-insta.png" style="max-width:100%"></a>
              <a href="" style="color:#1EA69A;word-wrap:break-word;font-family:&quot;Helvetica Neue&quot;, &quot;Helvetica&quot;, Helvetica, Arial, sans-serif;font-weight:800;color:#999;color:#049075 !important"><img width="25" src="http://cdn2.hubspot.net/hubfs/677576/email-pinterest.png" style="max-width:100%"></a>
            </p>
          </div>
        </td>
      </tr>
    </tbody></table>';
       maildss($email,$fullname,$fullname ,$messagetrrt,'');

  echo '<span style="font-weight:bold;color:green">E-mail ha sido enviado!</span>';

echo  '<script>function auto_refresh(){

       window.location="customer_review.php?report=report";

    }

    var refreshId = setInterval(auto_refresh, 3000);

</script>';

  }else{

  		echo '<span style="font-weight:bold;color:red">Error</span>';

  }

?>