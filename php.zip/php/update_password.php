<?php include('../common/config.php');

  extract($_POST);


 if($pass != $new_pass)
    {
      echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Password not matched"</span>
</div></div>';
      
    }

    else
    {
           $sql3 = "UPDATE `users` SET `password`='$pass' WHERE `id`='$user_id'";
             $result3 = mysqli_query($conn,$sql3);

              echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Updated password</span>
</div></div>';
    }




?>