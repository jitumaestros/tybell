<?php include ('header.php'); 
$edit=mysqli_fetch_array(mysqli_query($conn,"select * from salon_opening_hr where id='".$_GET['edit']."'"));

?>
<style type="text/css">
	.uipload button {
		width: 100%;
		padding: 7px 0;
		background: #34A8B0;
		border: 0;
		color: #fff;
		font-size: 16px;
		border-radius: 0px;
	}
	.uipload {
		width: 100%;
		position: relative;
	}
</style>
<div class="upload_list">
	<div class="venuedesyla-blog-2">
		<div class="tab-pane" id="tab_block2">
			<h3>Opening Hour</h3>
			<div class="form-group">

				<form method="post" id="addslnschedule">
					<input type="hidden" name="ids" value="<?php echo $_GET['edit'];?>">
					<div class="input-new-box">
						<div class="inoput-box">
							<div class="mr_input_box">
								<label>
									<input type="checkbox" value="<?php echo $edit['day'];?>" name="day" checked>  &nbsp; <?php echo $edit['day'];?>
								</label>

								<select type="text" class="form-control" name="start_time" placeholder="Start Time">
								<option value="<?php echo $edit['start_time'];?>"><?php echo $edit['start_time'];?></option>
									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
									<option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
									<option value="05:00 pm">05:00 pm</option>
									<option value="06:00 pm">06:00 pm</option>

								</select>

								<span>To</span>

								<select type="text" class="form-control" name="end_time" placeholder="End Time">
									<option value="<?php echo $edit['end_time'];?>"><?php echo $edit['end_time'];?></option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
									<option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
									<option value="05:00 pm">05:00 pm</option>
									<option value="06:00 pm">06:00 pm</option>
								</select>
							</div>
						</div>
					</div>

					<div class="form-group text-right">
						<button class="btn btn-default addsalonbtn" name="submit" type="submit">Submit
						</button>
					</div>
					<div id="addschesln"></div>
				</form>
			</div>
		</div>
	</div>
<script type="text/javascript">
	$(document).ready(function (addslnsche) {
$("#addslnschedule").on('submit',(function(addslnsche) {
//alert();

$("#form_abc1_img").show();
addslnsche.preventDefault();
$.ajax({
url: "php/edit_sln_schedule.php",
type: "POST",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,
success: function(data){
// 	alert(data);
$("#form_abc1_img").hide();
$("#addschesln").show().html(data);
},
error: function(){}          
});

}));
});
</script>
