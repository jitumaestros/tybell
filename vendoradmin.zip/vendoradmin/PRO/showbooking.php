<?php include('../../common/config.php');

extract($_POST);


$tim1='10:00 am';

$tim2='11:00 am';

$tim3='12:00 pm';

$tim4='01:00 pm';

$tim5='02:00 pm';

$tim6='03:00 pm';

$tim7='04:00 pm';

$tim8='05:00 pm';

$tim9='06:00 pm';


$schedule_date=$id;

$sqlii=mysqli_query($conn,"select * from staff where salon_id ='".$_SESSION['user_id']."'");

while($stfnm=mysqli_fetch_array($sqlii)){


 ?>

 <div class="listoftime">
  <ul class="timimgn mycss-2">
    <li><div class="staff-img" >
      <img src="../img/<?php echo $stfnm['profile_pic_path'];?>">
      <?php echo $stfnm['name'];?>
    </div></li>
    <?php 
    $bookings=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='10:00 am' and schedule_date='$schedule_date'"));


      $blocks=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='10:00 am' and dates='$schedule_date'"));



    $userss=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings['user_id']."'"));

    $countssss=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and and schedule_time='10:00 am' and schedule_date='$schedule_date'")); 


    $ser=explode(',', $bookings['service_id']);
    $sernm='';
    foreach ($ser as $key => $value) {
      $sernmd=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value'"));
      if($sernm==''){

        $sernm=$sernmd['name'];

      }else{
        $sernm=$sernm.' , '.$sernmd['name'];

      }

    }




      $dur1s=explode(' ', $bookings['duration']);

$dur=$dur1s[0];
if($dur=='1'){

$dur1='60';

}else if($dur=='2'){

$dur1='120';

}else if($dur=='3'){

$dur1='180';

}
else if($dur=='4'){

$dur1='240';

}
else if($dur=='5'){

$dur1='300';

}else{

$dur1=$dur;

}


 $endTime = strtotime("+$dur1 minutes",strtotime($bookings['schedule_time']));

   $ser=explode(',', $bookings['service_id']);
           $aern=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser['0']."'"));


        $subcats=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern['subcategory_id']."'"));



   if($blocks >0){ ?>
        <li><div class="booking1"><p class="date2">Permiso para llegar tarde</p></div></li>
 <?php }else{ 

    if($tim1==$bookings['schedule_time']){
      ?>
      <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings['id'];?>','10:00 am','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings['service_id'];?>');">
      <div class="booking hover-bboking"><h4 class="date"><?php echo $userss['first_name'].' '.$userss['last_name'];?> </h4><p class="date"><?php echo $sernm;?></p><p class="date"><?php echo $bookings['duration'];?> 

  <div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss['first_name'].' '.$userss['last_name'];?></b></p>
                      <p><?php echo $userss['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings['schedule_date'];?>, <?php echo $bookings['schedule_time'];?> - <?php echo date('H:i a',$endTime);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats['name'];?></p>
                            <p>-<?php echo $bookings['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>

      </div></a></li>
      <?php } else{ ?>

      <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings['id'];?>','10:00 am','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings['service_id'];?>');"></a></li>
      <?php   } } 



      $bookings1=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='11:00 am' and schedule_date='$schedule_date'"));

      $blocks1=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='11:00 am' and dates='$schedule_date'"));


      $userss1=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings1['user_id']."'"));

      $countss=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='11:00 am' and schedule_date='$schedule_date'"));  

      $ser1=explode(',', $bookings1['service_id']);
      $sernm1='';
      foreach ($ser1 as $key => $value1) {
        $sernmd1=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value1'"));
        if($sernm1==''){

          $sernm1=$sernmd1['name'];

        }else{
          $sernm1=$sernm1.' , '.$sernmd1['name'];

        }

      }

  $dur1s1=explode(' ', $bookings1['duration']);

$dur1=$dur1s1[0];
if($dur1=='1'){

$dur11='60';

}else if($dur1=='2'){

$dur11='120';

}else if($dur1=='3'){

$dur11='180';

}
else if($dur1=='4'){

$dur11='240';

}
else if($dur1=='5'){

$dur11='300';

}else{

$dur11=$dur1;

}


 $endTime1 = strtotime("+$dur11 minutes",strtotime($bookings1['schedule_time']));

   $ser1=explode(',', $bookings1['service_id']);
           $aern1=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser1['0']."'"));


        $subcats1=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern1['subcategory_id']."'"));


 if($blocks1 >0){ ?>
        <li><div class="booking1"><p class="date2">Permiso para llegar tarde</p></div></li>
 <?php }else{ 

      if($tim2==$bookings1['schedule_time']){


       if($countss=='0'){
       }else{?>
       <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings1['id'];?>','11:00 am','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings1['service_id'];?>');">
       <div class="booking hover-bboking"><h4 class="date"><?php echo $userss1['first_name'].' '.$userss1['last_name'];?> </h4>
       <p class="date"><?php echo $sernm1;?></p><p class="date"><?php echo $bookings1['duration'];?> 

<div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss1['first_name'].' '.$userss1['last_name'];?></b></p>
                      <p><?php echo $userss1['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings1['schedule_date'];?>, <?php echo $bookings1['schedule_time'];?> - <?php echo date('H:i a',$endTime1);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings1['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats1['name'];?></p>
                            <p>-<?php echo $bookings1['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings1['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings1['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings1['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>

       </div></a></li>
       <?php } }else{ ?>

       <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings1['id'];?>','11:00 am','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings1['service_id'];?>');"></a></li>
       <?php   }  }


       $bookings2=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='12:00 pm' and schedule_date='$schedule_date'"));

      $blocks2=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='12:00 pm' and dates='$schedule_date'"));



       $userss2=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings2['user_id']."'"));

       $countsss=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and and schedule_time='12:00 pm' and schedule_date='$schedule_date'"));  


       $ser2=explode(',', $bookings2['service_id']);
       $sernm2='';
       foreach ($ser2 as $key => $value2) {
        $sernmd2=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value2'"));
        if($sernm2==''){

          $sernm2=$sernmd2['name'];

        }else{
          $sernm2=$sernm2.' , '.$sernmd2['name'];

        }

      }

 $dur1s2=explode(' ', $bookings2['duration']);

$dur2=$dur1s2[0];
if($dur2=='1'){

$dur12='60';

}else if($dur2=='2'){

$dur12='120';

}else if($dur2=='3'){

$dur12='180';

}
else if($dur2=='4'){

$dur12='240';

}
else if($dur2=='5'){

$dur12='300';

}else{

$dur12=$dur2;

}


 $endTime2 = strtotime("+$dur12 minutes",strtotime($bookings2['schedule_time']));

   $ser2=explode(',', $bookings2['service_id']);
           $aern=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser2['0']."'"));


        $subcats=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern2['subcategory_id']."'"));


 if($blocks2 >0){ ?>
        <li><div class="booking1"><p class="date2">Permiso para llegar tarde</p></div></li>
 <?php }else{ 

      if($tim3==$bookings2['schedule_time']){
        if($countsss=='0'){ 

        }else {?>

        <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings2['id'];?>','12:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings2['service_id'];?>');">
        <div class="booking hover-bboking"><h4 class="date"><?php echo $userss2['first_name'].' '.$userss2['last_name'];?>
         </h4><p class="date"><?php echo $sernm2;?></p><p class="date"><?php echo $bookings2['duration'];?>

<div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss2['first_name'].' '.$userss2['last_name'];?></b></p>
                      <p><?php echo $userss2['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings2['schedule_date'];?>, <?php echo $bookings2['schedule_time'];?> - <?php echo date('H:i a',$endTime2);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings2['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats2['name'];?></p>
                            <p>-<?php echo $bookings2['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings2['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings2['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings2['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>


         </div></a></li>
        <?php } }else{ ?>

        <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings2['id'];?>','06:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings2['service_id'];?>');"></a></li>

        <?php   }  }

        $bookings3=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='01:00 pm' and schedule_date='$schedule_date'"));

      $blocks3=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='01:00 pm' and dates='$schedule_date'"));



        $userss3=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings3['user_id']."'"));

        $countsss1=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and and schedule_time='01:00 pm' and schedule_date='$schedule_date'"));  

        $ser3=explode(',', $bookings3['service_id']);
        $sernm3='';
        foreach ($ser3 as $key => $value3) {
          $sernmd3=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value3'"));
          if($sernm3==''){

            $sernm3=$sernmd3['name'];

          }else{
            $sernm3=$sernm3.' , '.$sernmd3['name'];

          }

        }

        $dur1s3=explode(' ', $bookings3['duration']);

$dur3=$dur1s3[0];
if($dur3=='1'){

$dur13='60';

}else if($dur3=='2'){

$dur13='120';

}else if($dur3=='3'){

$dur13='180';

}
else if($dur3=='4'){

$dur13='240';

}
else if($dur3=='5'){

$dur13='300';

}else{

$dur13=$dur3;

}


 $endTime3 = strtotime("+$dur1 minutes",strtotime($bookings3['schedule_time']));

   $ser3=explode(',', $bookings3['service_id']);
           $aern3=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser3['0']."'"));


        $subcats3=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern3['subcategory_id']."'"));


 if($blocks3 >0){ ?>
        <li><div class="booking1"><p class="date2">Permiso para llegar tarde</p></div></li>
 <?php }else{ 
        if($tim4==$bookings3['schedule_time']){

         if($countsss1=='0'){
         }else{?>
         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings3['id'];?>','01:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings3['service_id'];?>');">

         <div class="booking hover-bboking"><h4 class="date"><?php echo $userss3['first_name'].' '.$userss3['last_name'];?> </h4><p class="date"><?php echo $sernm3;?></p> <p class="date"><?php echo $bookings3['duration'];?>


       <div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss3['first_name'].' '.$userss3['last_name'];?></b></p>
                      <p><?php echo $userss3['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings3['schedule_date'];?>, <?php echo $bookings3['schedule_time'];?> - <?php echo date('H:i a',$endTime3);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings3['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats3['name'];?></p>
                            <p>-<?php echo $bookings3['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings3['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings3['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings3['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>


         </div></a></li>
         <?php } }else{ ?>

         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings3['id'];?>','01:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings3['service_id'];?>');"></a></li>
         
         <?php  } }

         $bookings4=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='02:00 pm' and schedule_date='$schedule_date'"));

$blocks4=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='02:00 pm' and dates='$schedule_date'"));



         $userss4=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings4['user_id']."'"));

         $countsss2=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and and schedule_time='02:00 pm' and schedule_date='$schedule_date'"));  

         $ser4=explode(',', $bookings4['service_id']);
         $sernm4='';
         foreach ($ser4 as $key => $value4) {

          $sernmd4=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value4'"));
          if($sernm4==''){

            $sernm4=$sernmd4['name'];

          }else{
            $sernm4=$sernm4.' , '.$sernmd4['name'];

          }

        }
$dur1s4=explode(' ', $bookings4['duration']);

$dur4=$dur1s4[0];
if($dur4=='1'){

$dur14='60';

}else if($dur4=='2'){

$dur14='120';

}else if($dur4=='3'){

$dur14='180';

}
else if($dur4=='4'){

$dur14='240';

}
else if($dur4=='5'){

$dur14='300';

}else{

$dur14=$dur4;

}


 $endTime4 = strtotime("+$dur14 minutes",strtotime($bookings4['schedule_time']));

   $ser4=explode(',', $bookings4['service_id']);
           $aern4=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser4['0']."'"));


        $subcats4=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern4['subcategory_id']."'"));



 if($blocks4 >0){ ?>
        <li><div class="booking1"><p class="date2">Permiso para llegar tarde</p></div></li>
 <?php }else{

        if($tim5==$bookings4['schedule_time']){

         if($countsss2=='0'){
         }else{?>
         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings4['id'];?>','02:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings4['service_id'];?>');">

         <div class="booking hover-bboking"><h4 class="date"><?php echo $userss4['first_name'].' '.$userss4['last_name'];?> </h4><p class="date"><?php echo $sernm4;?></p><p class="date"><?php echo $bookings4['duration'];?> 

             <div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss4['first_name'].' '.$userss4['last_name'];?></b></p>
                      <p><?php echo $userss4['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings4['schedule_date'];?>, <?php echo $bookings4['schedule_time'];?> - <?php echo date('H:i a',$endTime4);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings4['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats4['name'];?></p>
                            <p>-<?php echo $bookings4['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings4['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings4['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings4['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>


         </div></a></li>
         <?php } }else{ ?>

         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings4['id'];?>','02:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings4['service_id'];?>');"></a></li>


         <?php  } }

         $bookings5=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='03:00 pm' and schedule_date='$schedule_date'"));


$blocks5=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='03:00 pm' and dates='$schedule_date'"));



         $userss5=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings5['user_id']."'"));

         $countsss12=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and and schedule_time='03:00 pm' and schedule_date='$schedule_date'"));  


         $ser5=explode(',', $bookings5['service_id']);
         $sernm5='';
         foreach ($ser4 as $key => $value5) {

          $sernmd5=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value5'"));
          if($sernm5==''){

            $sernm5=$sernmd5['name'];

          }else{
            $sernm5=$sernm5.' , '.$sernmd5['name'];

          }

        }


  $dur1s5=explode(' ', $bookings5['duration']);

$dur5=$dur1s5[0];
if($dur5=='1'){

$dur15='60';

}else if($dur5=='2'){

$dur15='120';

}else if($dur5=='3'){

$dur15='180';

}
else if($dur5=='4'){

$dur15='240';

}
else if($dur5=='5'){

$dur15='300';

}else{

$dur15=$dur5;

}


 $endTime5 = strtotime("+$dur15 minutes",strtotime($bookings5['schedule_time']));

   $ser5=explode(',', $bookings5['service_id']);
           $aern5=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser5['0']."'"));


        $subcats5=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern5['subcategory_id']."'"));


 if($blocks5 >0){ ?>
        <li><div class="booking1"><p class="date2">Permiso para llegar tarde</p></div></li>
 <?php }else{ 

        if($tim6==$bookings5['schedule_time']){

         if($countsss12=='0'){
         }else{?>
         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings5['id'];?>','03:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings5['service_id'];?>');">

         <div class="booking hover-bboking"><h4 class="date"><?php echo $userss5['first_name'].' '.$userss5['last_name'];?> </h4><p class="date"><?php echo $sernm5;?></p><p class="date"><?php echo $bookings5['duration'];?> 

 <div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss5['first_name'].' '.$userss5['last_name'];?></b></p>
                      <p><?php echo $userss5['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings5['schedule_date'];?>, <?php echo $bookings5['schedule_time'];?> - <?php echo date('H:i a',$endTime5);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings5['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats5['name'];?></p>
                            <p>-<?php echo $bookings5['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings5['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings5['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings5['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>


         </div></a></li>
         <?php } }else{ ?>

         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings5['id'];?>','03:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings5['service_id'];?>');"></a></li>


         <?php  } }

         $bookings6=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='04:00 pm' and schedule_date='$schedule_date' "));


$blocks6=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='04:00 pm' and dates='$schedule_date'"));


         $userss6=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings6['user_id']."'"));

         $countsss6=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and and schedule_time='04:00 pm' and schedule_date='$schedule_date'"));  

         $ser6=explode(',', $bookings6['service_id']);
         $sernm6='';
         foreach ($ser6 as $key => $value6) {

          $sernmd6=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value6'"));
          if($sernm6==''){

            $sernm6=$sernmd6['name'];

          }else{
            $sernm6=$sernm6.' , '.$sernmd6['name'];

          }

        }


  $dur1s6=explode(' ', $bookings6['duration']);

$dur6=$dur1s6[0];
if($dur6=='1'){

$dur16='60';

}else if($dur6=='2'){

$dur16='120';

}else if($dur6=='3'){

$dur16='180';

}
else if($dur6=='4'){

$dur16='240';

}
else if($dur6=='5'){

$dur16='300';

}else{

$dur16=$dur6;

}


 $endTime6 = strtotime("+$dur16 minutes",strtotime($bookings6['schedule_time']));

   $ser6=explode(',', $bookings6['service_id']);
           $aern6=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser6['0']."'"));


        $subcats6=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern6['subcategory_id']."'"));

 if($blocks6 >0){ ?>
        <li><div class="booking1"><p class="date">Permiso para llegar tarde</p></div></li>
 <?php }else{ 

        if($tim7==$bookings6['schedule_time']){

         if($countsss6=='0'){
         }else{?>
         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings6['id'];?>','04:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings6['service_id'];?>');">

         <div class="booking hover-bboking"><h4 class="date"><?php echo $userss6['first_name'].' '.$userss6['last_name'];?> </h4><p><?php echo $sernm6;?></p><p class="date"><?php echo $bookings6['duration'];?> 

<div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss6['first_name'].' '.$userss6['last_name'];?></b></p>
                      <p><?php echo $userss6['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings6['schedule_date'];?>, <?php echo $bookings6['schedule_time'];?> - <?php echo date('H:i a',$endTime6);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings6['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats6['name'];?></p>
                            <p>-<?php echo $bookings6['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings6['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings6['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings6['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>


         </div></a></li>
         <?php } }else{ ?>

         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings6['id'];?>','04:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings6['service_id'];?>');"></a></li>
         

         <?php  }  }
         $bookings7=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='05:00 pm' and schedule_date='$schedule_date'"));

$blocks7=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='05:00 pm' and dates='$schedule_date'"));



         $userss7=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings7['user_id']."'"));

         $countsss7=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and and schedule_time='05:00 pm' and schedule_date='$schedule_date'"));  

         $ser7=explode(',', $bookings7['service_id']);
         $sernm7='';
         foreach ($ser7 as $key => $value7) {

          $sernmd7=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value7'"));
          if($sernm7==''){

            $sernm7=$sernmd7['name'];

          }else{
            $sernm7=$sernm7.' , '.$sernmd7['name'];

          }

        }
$dur1s7=explode(' ', $bookings7['duration']);

$dur7=$dur1s7[0];
if($dur7=='1'){

$dur17='60';

}else if($dur7=='2'){

$dur17='120';

}else if($dur7=='3'){

$dur17='180';

}
else if($dur7=='4'){

$dur17='240';

}
else if($dur7=='5'){

$dur17='300';

}else{

$dur17=$dur7;

}


 $endTime7 = strtotime("+$dur17 minutes",strtotime($bookings7['schedule_time']));

   $ser7=explode(',', $bookings7['service_id']);

           $aern7=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser7['0']."'"));


        $subcats7=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern7['subcategory_id']."'"));

 if($blocks7 >0){ ?>
        <li><div class="booking1"><p class="date2">Permiso para llegar tarde</p></div></li>
 <?php }else{ 

        if($tim8==$bookings7['schedule_time']){

         if($countsss7=='0'){
         }else{?>
         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings7['id'];?>','05:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings7['service_id'];?>');">

         <div class="booking hover-bboking"><h4 class="date"><?php echo $userss7['first_name'].' '.$userss7['last_name'];?> </h4><p><?php echo $sernm7;?></p><p class="date"><?php echo $bookings7['duration'];?>

<div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss7['first_name'].' '.$userss7['last_name'];?></b></p>
                      <p><?php echo $userss7['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings7['schedule_date'];?>, <?php echo $bookings7['schedule_time'];?> - <?php echo date('H:i a',$endTime7);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings7['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats7['name'];?></p>
                            <p>-<?php echo $bookings7['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings7['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings7['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings7['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>

         </div></a></li>
         <?php } }else{ ?>

         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings7['id'];?>','05:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings7['service_id'];?>');"></a></li>
         

         <?php  } }

         $bookings8=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and schedule_time='06:00 pm' and schedule_date='$schedule_date'"));

$blocks8=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id ='".$_SESSION['user_id']."' and staff_id='".$stfnm['id']."' and start_time='06:00 pm' and dates='$schedule_date'"));



         $userss8=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bookings8['user_id']."'"));

         $countsss9=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and staffid='".$stfnm['id']."' and and schedule_time='06:00 pm' and schedule_date='$schedule_date'")); 

         $ser8=explode(',', $bookings8['service_id']);
         $sernm8='';
         foreach ($ser8 as $key => $value8) {

          $sernmd8=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$value8'"));
          if($sernm8==''){

            $sernm8=$sernmd8['name'];

          }else{
            $sernm8=$sernm8.' , '.$sernmd8['name'];

          }

        }$dur1s8=explode(' ', $bookings8['duration']);

$dur8=$dur1s8[0];
if($dur8=='1'){

$dur18='60';

}else if($dur8=='2'){

$dur18='120';

}else if($dur8=='3'){

$dur18='180';

}
else if($dur8=='4'){

$dur18='240';

}
else if($dur8=='5'){

$dur18='300';

}else{

$dur18=$dur8;

}


 $endTime8 = strtotime("+$dur18 minutes",strtotime($bookings8['schedule_time']));

   $ser8=explode(',', $bookings8['service_id']);
           $aern8=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$ser8['0']."'"));


        $subcats8=mysqli_fetch_array(mysqli_query($conn,"select * from subcategory where id='".$aern8['subcategory_id']."'"));



 if($blocks8 >0){ ?>
        <li><div class="booking1"><p class="date2">Permiso para llegar tarde</p></div></li>
 <?php }else{ 

        if($tim9==$bookings8['schedule_time']){

         if($countsss9=='0'){
         }else{?>
         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings8['id'];?>','06:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings8['service_id'];?>');">

         <div class="booking hover-bboking"><h4 class="date"><?php echo $userss8['first_name'].' '.$userss8['last_name'];?> </h4><p class="booking"><?php echo $sernm8;?></p><p class="date"><?php echo $bookings8['duration'];?>

<div class="hover-show-div">
                <div class="hover-blog_2">
                  <div class="header">
                    <p>Cita confirmada</p>                    
                  </div>
                  <div class="blofy-content-hover">
                      <p style="color: #69CA40;">Primera Visita</p>
                      <p><b><?php echo $userss8['first_name'].' '.$userss8['last_name'];?></b></p>
                      <p><?php echo $userss8['phone'];?></p>
                  </div>
                  <div class="blog-content-hver-2">
                      <table>
                        <tr>
                          <th>Fecha</th>
                          <td><?php echo $bookings8['schedule_date'];?>, <?php echo $bookings8['schedule_time'];?> - <?php echo date('H:i a',$endTime8);?> </td>
                        </tr>
                        <tr>
                          <th>Duración</th>
                          <td><?php echo $bookings8['duration'];?></td>
                        </tr>
                        <tr>
                          <th>Servicio</th>
                          <td>
                            <p><?php echo $subcats8['name'];?></p>
                            <p>-<?php echo $bookings8['duration'];?></p>
                          </td>
                        </tr>
                        <tr>
                          <th>pago</th>
                          <td>sin pager $<?php echo $bookings8['total_amount'];?></td>
                        </tr>
                        <tr>
                          <th>Comision</th>
                          <td>0%</td>
                        </tr>
                        <tr>
                          <th>Fuente</th>
                          <td>Tybell partners -salonuser1</td>
                        </tr>
                         <tr>
                          <th>Reservado en </th>
                          <td><?php echo date('D M d Y h:i a' ,$bookings8['strtotime']);?></td>
                        </tr>
                        <tr>
                          <th>I notas </th>
                          <td><?php echo $bookings8['note'];?></td>
                        </tr>
                      </table>
                  </div>
                </div>
              </div>


          </div></a></li>
         <?php } }else{ ?>

         <li><a href="javascript:;" onclick="showappointment('<?php echo $bookings8['id'];?>','06:00 pm','<?php echo $stfnm['id'];?>','<?php echo $schedule_date;?>','<?php echo $bookings8['service_id'];?>');"></a></li>
         <?php   } } ?>

       </ul>
     </div>
     <?php } ?>




