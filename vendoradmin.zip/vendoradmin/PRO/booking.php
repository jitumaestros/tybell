<?php include ('header.php'); ?>
<!-- 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<div class="Clientes_table_main">
  <div class="container-fluid">
    <div class="row">
      <div class="col -sm-12">
        <div class="Clientes_table_block">
          <div class="col-sm-12 padder">
            <div class="table-responsive"> 
                <table class="table table-bordered" id="datatable">
                  <thead>
                    <tr>
                 <th>Reserva Nº</th>
                      <th> Cliente</th>
                      <th> Teléfono</th>
                      <th>Mail</th>
                      <th> Fecha</th>
                      <th> Hora</th>
                      <th> Duración</th>
                      <th> Miembro del Equipo</th>
                      <th> Tipo de Servicio</th>
                      <th> Servicio</th>
                      <th> Pago $</th>

                    </tr>
                  </thead>
                  <tbody>
                  <?php 
                    $n='1';
                   $sqlii=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and booking_status='4' group by order_ref ");
                  while($book=mysqli_fetch_array($sqlii)){

    $users=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$book['user_id']."'"));
    $stf=mysqli_fetch_array(mysqli_query($conn,"select * from staff where id='".$book['staffid']."'"));

    $serv=explode(',',$book['service_id']);
    $servnm='';
    $cat='';
    $price='';
    foreach ($serv as $key => $values) {
$service=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$values'"));
if($servnm==''){

$servnm=$service['name'];

}else{

  $servnm=$servnm.' , '.$service['name'];

}

$category=mysqli_fetch_array(mysqli_query($conn,"select * from category where id='".$service['category_id']."'"));
$cat=$category['name'];

    }

                    ?>
                    <tr>

                    <td><?php echo $book['order_ref'];?></td>
                      <td> <?php echo $users['first_name'].' '.$users['last_name'];?> </td>
                      <td><?php echo $book['phone'];?>   </td>
                      <td> <?php echo $book['email'];?> </td>
                      <td> <?php echo $book['schedule_date'];?> </td>
                      <td> <?php echo $book['schedule_time'];?> </td>
                    
                      <td> <?php echo $book['duration'];?> </td>
                      <td> <?php echo $stf['name'];?> </td>
                      <td> <?php echo $cat;?> </td>
                      <td> <?php echo $servnm;?> </td>
                      <td> <?php echo $book['total_amount'];?> </td>

                    </tr>

                    <?php }?>

                  </tbody>
                </table>
            </div>
          </div>
        
      </div>
    </div>
  </div>
</div>

<?php include ('footer.php');?>

<script type="text/javascript">
  
  function sendemails(id){
    $("#shosendhtml").show();
  }


  function mailsclose(){
    $("#shosendhtml").hide();
  }

</script>
 
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.15/datatables.min.css"/>

<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.15/datatables.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
$('#datatable').DataTable( {

} );
} );


   
$(document).ready(function (abc41s) {
 $("#sendemail").on('submit',(function(abc41s) {
    $('#loading').show();

  $("#form_abc1_img").show();
  abc41s.preventDefault();
  $.ajax({
   url: "php/sendemailclient.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
                $('#loading').hide();

     $("#form_abc1_img").hide();
   $("#returndfdg").show().html(data);
      },
     error: function(){}          
    });

 }));
});

 </script>


