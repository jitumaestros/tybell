<?php include('../../common/config.php');
extract($_POST);

 $dates1=strtotime($dates);
if($dates==''){

$datess=date('Y-m-d');


}else{

$datess=date('Y-m-d',$dates1);


}

$bokserv=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where id='".$id."'"));

$userbk=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bokserv['user_id']."'"));

$dur1=$bokserv['duration'];


//echo $times=$time+$dur1;
$dur1s=explode(' ', $bokserv['duration']);

$dur=$dur1s[0];
if($dur=='1'){

$dur1='60';

}else if($dur=='2'){

$dur1='120';

}else if($dur=='3'){

$dur1='180';

}
else if($dur=='4'){

$dur1='240';

}
else if($dur=='5'){

$dur1='300';

}else{

$dur1=$dur;

}

 $endTime = strtotime("+$dur1 minutes",strtotime($time));


?>    


<link rel="stylesheet" href="datepicker/pikaday.css">
<div id="myModalss" class="modal fade" role="dialog">
  <div class="modal-dialog vendoradmin_model">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header_blog">
        <button type="button" class="close" onclick="closefunction()">&times;</button>
        <ul class="appointment_list">
          <li>
            <a href="javascript:;" class="active_appoint" onclick="toglesses('tab_block1')">Cita</a>
          </li>
          <li>
            <a href="javascript:;" onclick="toglesses('tab_block2')">Bloquear</a>
          </li>
        </ul>
      </div>

      <div class="overflow-h appointment_div" id="tab_block1" >
        <div class="model_body_blog1">
          <form method="post" id="adddbooking" enctype="multipart/form-data">
            <div class="col-sm-12 padder"  >
              <div class="title_blog">
                <div class=" overflow-h">
                  <p class="user-Nasm">Cliente</p>
                  <div  id="countt" class="information">
                    <div class="col-sm-3 padder-left">
                      <div class="form-group input_box dropdown">
                        <input type="hidden" name="user_id" value="<?php echo $bokserv['user_id'];?> ">
                        
                        <input type="hidden" name="bookid" value="<?php echo $id;?> ">
                        
                        <input type="text" class="form-control" name="full_name" onkeyup="search_client(this.value);" id="searcountid" value="<?php echo $userbk['first_name'].' '.$userbk['last_name'];?>" placeholder="Buscar cliente" autocomplete="off" required>
                        <ul class="" id="saeress1"> </ul> 
                      </div>
                    </div>

                    <div class="col-sm-3 padder-left">
                      <div class="form-group input_box">
                        <input type="text" placeholder="Teléfono" required  class="form-control" name="phone" value="<?php echo $userbk['phone'];?>">
                      </div>
                    </div>

                    <div class="col-sm-6 padder-left">
                      <div class="form-group input_box ">
                        <input type="text" placeholder="Email" required  class="form-control"  class="Email" name="email" value="<?php echo $userbk['email'];?>">
                      </div>
                    </div>
                  </div>                           
                </div>                            
              </div>
            </div>


            <div class="col-sm-12 padder">
              <div class="title_blog overflow-h">
                <div class="col-sm-6 form-group input_box ">
                  <p class="user-Nasm"> Tipo de Servicio   </p>
                  <select class="form-control" name="catid"  onchange="subcat(this.value);" required >
                    <option value="">Tipo de Servicio </option>
                    <?php
                      $categry = mysqli_query($conn,"select * from category");
                      while($catnm = mysqli_fetch_array($categry)){ 
                    ?>
                    <option value="<?php echo $catnm['id'];?>">
                      <?php echo $catnm['name'];?>
                    </option>
                    <?php   } ?> 
                  </select>
                </div>
                <div class="col-sm-6 form-group input_box " id="msdddda">
                  <p class="user-Nasm"> Servicio </p>
                  <select  class="form-control" name="service_id[]" multiple="multiple" id="msdddd" required>
                    <!--
                      <?php
                      $cat = mysqli_query($conn,"select * from service where salon_id='".$_SESSION['user_id']."' ");

                      while($row = mysqli_fetch_array($cat)){ 

                      $dfgdfj = explode(",", $service_id);
                      $sel = ''; 
                      for ($i=0; $i < count($dfgdfj); $i++) { 
                      if($row['id']==$dfgdfj[$i]){ $sel = 'selected'; $i = count($dfgdfj);}
                      }

                      ?>

                      <option value="<?php echo $row['id'];?>" <?php echo $sel;?>><?php echo $row['name'];?></option>
                      <?php   } ?>
                    -->
                  </select>
                </div>
                <br>
                <br>
                <div class="dsdasd" style="margin-top: 56px;">
                  <div class="col-sm-3 padder-left" >
                    <div class="form-group input_box ">
                      <label>Fecha</label>
                      <input type="text" placeholder="Schedule Date"  class="form-control clmsms" value="<?php echo $datess;?>"  class="Email" name="schedule_date" id="datepickera" required>
                    </div>
                  </div>
                  <div class="col-sm-3 padder-left">
                    <div class="form-group input_box ">
                      <label>Time</label>
                      <select class="form-control clmsms" name="schedule_time" required>
                       <option value="<?php echo $time;?>"><?php echo $time;?></option>
                        <option value="10:00 am">10:00 am</option>
                         <option value="11:00 am">11:00 am</option>
                         <option value="12:00 pm">12:00 pm</option>
                        <option value="01:00 pm">01:00 pm</option>
                        <option value="02:00 pm">02:00 pm</option>
                        <option value="03:00 pm">03:00 pm</option>
                       <option value="04:00 pm">04:00 pm</option>
                       <option value="05:00 pm">05:00 pm</option>
                       <option value="06:00 pm">06:00 pm</option>

                      </select>
                    </div>
                  </div>
                  <div class="col-sm-3 padder-left">
                    <div class="form-group input_box ">
                      <label>Duración</label>
                      <select class="form-control clmsms" name="duration" required>
                       <option value="<?php echo $bokserv['duration'];?>"><?php echo $bokserv['duration'];?></option>
                        <option value="30 m">30 m</option>
                        <option value="1 h">1 h</option>
                         <option value="2 h">2 h</option>
                        <option value="3 h">3 h</option>
                        <option value="4 h">4 h</option>
                        <option value="5 h">5 h</option>
                      </select>
                    </div>
                  </div>

                  <div class="col-sm-3 padder-left">
                    <div class="form-group input_box ">
                      <label> Miembro del equipo</label>
                      <select name="staffid" class="form-control clmsms" required>
                        <option value="<?php echo $staff_id;?>"><?php $staffnm=mysqli_fetch_array(mysqli_query($conn,"select * from staff where id='".$staff_id."'")); echo $staffnm['name'];?></option>
                        <?php $sqlii=mysqli_query($conn,"select * from staff where salon_id='".$_SESSION['user_id']."'");
                        while($stnm=mysqli_fetch_array($sqlii)){?>
                        <option value="<?php echo $stnm['id'];?>"><?php echo $stnm['name'];?></option>

                        <?php }?>

                      </select>
                    </div>
                  </div>
                </div>

                <div class="col-sm-12 padder"><!-- 
                  <input type="" name="" class="form-control" placeholder="acaba en" value="acaba en <?php echo date('H:i a',$endTime);?>"> -->
                  <br>
                  <h4 class="timss">acaba en <?php echo date('H:i a',$endTime);?></h4>
                </div>
              </div>
            </div>

            <div class="col-sm-12 padder">
              <div class="add_service"> 
                <label>Nota</label>
                <div class="input-group">
                  <textarea name="note" class="form-control" placeholder="note"><?php echo $bokserv['note'];?></textarea>
                  <span class="input-group-addon">
                      <button class="save_bnt" type="submit" name="submit">Guardar</button>
                  </span>
                </div> 
              </div>
            </div>
            <div id="datart"></div>
          </form>
        </div>
      </div>



      <div class="overflow-h block_div" id="tab_block2" style="display: none;">
          <div class="block_user_wrappper">
            <div class="title_blog overflow-h ">
                <div class="col-sm-1 padder">
                    <div class="ban_icon">
                        <i class="fa fa-ban"></i>
                    </div>
                </div>
                 <div class="col-sm-11">
                    <div class="block_para">
                      <p>Haga que este intervalo de tiempo no esté disponible para reservas. También puede usar bloques para definir las horas de almuerzo o bloquear días laborables específicos.</p>

                    </div>                                
                </div>
            </div>
                <div class="block_usr_form title_blog overflow-h1 ">
                <div class="col-sm-12">
                          <form method="post" id="blockids" enctype="multipart/form-data">
<?php $blockk=mysqli_fetch_array(mysqli_query($conn,"select * from block_staff where salon_id='".$_SESSION['user_id']."' and staff_id='$staff_id'"));?>
                        <div class="dsdasd" style="margin-top: 56px;">
                  <div class="col-sm-3 padder-left" >
                    <div class="form-group input_box ">
                      <label>Fecha</label>
                      <input type="text" placeholder=" Date"  class="form-control clmsms" value="<?php echo $datess;?>"  class="Email" name="dates" id="datepickera1">
                    </div>
                  </div>
                  <div class="col-sm-3 padder-left">
                    <div class="form-group input_box ">
                      <label>Hora inicio</label>
                      <select class="form-control clmsms" name="start_time">
                       <option value="<?php echo $blockk['start_time'];?>"><?php echo $blockk['start_time'];?></option>
                        <option value="10:00 am">10:00 am</option>
                         <option value="11:00 am">11:00 am</option>
                         <option value="12:00 pm">12:00 pm</option>
                        <option value="01:00 pm">01:00 pm</option>
                        <option value="02:00 pm">02:00 pm</option>
                        <option value="03:00 pm">03:00 pm</option>
                       <option value="04:00 pm">04:00 pm</option>
                       <option value="05:00 pm">05:00 pm</option>
                       <option value="06:00 pm">06:00 pm</option>

                      </select>
                    </div>
                  </div>
                  <div class="col-sm-3 padder-left">
                    <div class="form-group input_box ">
                      <label>Hora fin</label>
                       <select class="form-control clmsms" name="end_time">
                       <option value="<?php echo $blockk['end_time'];?>"><?php echo $blockk['end_time'];?></option>
                        <option value="10:00 am">10:00 am</option>
                         <option value="11:00 am">11:00 am</option>
                         <option value="12:00 pm">12:00 pm</option>
                        <option value="01:00 pm">01:00 pm</option>
                        <option value="02:00 pm">02:00 pm</option>
                        <option value="03:00 pm">03:00 pm</option>
                       <option value="04:00 pm">04:00 pm</option>
                       <option value="05:00 pm">05:00 pm</option>
                       <option value="06:00 pm">06:00 pm</option>

                      </select>
                    </div>
                  </div>

                  <div class="col-sm-3 padder-left">
                    <div class="form-group input_box ">
                      <label>Miembro del equipo</label>
                      <select name="staff_id[]" multiple="multiple" class="form-control clmsms" id="msdddd2">
                        
                        <?php $sqlii=mysqli_query($conn,"select * from staff where salon_id='".$_SESSION['user_id']."'");
                        while($stnm=mysqli_fetch_array($sqlii)){

                          $dfgdfj = explode(",", $staff_id);
                      $sel = ''; 
                      for ($i=0; $i < count($dfgdfj); $i++) { 
                      if($stnm['id']==$dfgdfj[$i]){ $sel = 'selected'; $i = count($dfgdfj);}
                      }
                          ?>

                        <option value="<?php echo $stnm['id'];?>" <?php echo $sel;?>><?php echo $stnm['name'];?></option>
                        <?php }?>
                      </select>
                    </div>
                  </div>
                </div>  

            <div class="col-sm-12 padder">
              <div class="add_service"> 
                <label>Añadir nota</label>
                <div class="input-group">
                  <textarea name="notes" class="form-control" placeholder="note"><?php echo $blockk['notes'];?></textarea>
                  <span class="input-group-addon">
                      <button class="save_bnt" type="submit" name="submit">Guardar</button>
                  </span>
                </div> 
              </div>
            </div>  
            </form>     
              <div id="datarts"></div> 
                 
                </div>
                </div>
           
           
          </div>
      </div>  
      <div class="modal-footer">
        <!-- 
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        -->
      </div> 
    </div>
  </div>
</div>

<link rel="stylesheet" href="https://maestrosinfotech.com/Tybell/vendoradmin/PRO/multiple-select.css"/>
<script>

function toglesses(id){ 
    $('#tab_block1').hide(); 
    $('#tab_block2').hide(); 
    $('#'+id).toggle();   
}
 
</script> 

<script src="https://maestrosinfotech.com/Tybell/vendoradmin/PRO/multiple-select.js">  
</script>    

<script src="datepicker/pikaday.js"></script>
<script>
new Pikaday({
  field: document.getElementById('datepickera'),
  trigger: document.getElementById('datepicker-button'),
  minDate: new Date(2000, 0, 1),
  ariaLabel: 'Custom label',
  maxDate: new Date(2020, 12, 31),
  yearRange: [2010,2020]
});

new Pikaday({
  field: document.getElementById('datepickera1'),
  trigger: document.getElementById('datepicker-button'),
  minDate: new Date(2000, 0, 1),
  ariaLabel: 'Custom label',
  maxDate: new Date(2020, 12, 31),
  yearRange: [2010,2020]
});


$(function()
{
  $('#msdddd').change(function() {
  console.log($(this).val());
  }).multipleSelect({
  width: '100%'
  });
});

$(function()
{
  $('#msdddd2').change(function() {
  console.log($(this).val());
  }).multipleSelect({
  width: '100%'
  });
});


function search_client(val){
//alert(val);
 $("#form_abc1f_img").show();
 jQuery.ajax({
   url: "add_users.php",
   type: "POST",
  data : "val="+val,
   success: function(data){
   if(data ==0){
 $("#saeress1").hide();

}else{
   $("#saeress1").show();

    $("#form_abc1f_img").hide();

   $("#saeress1").html(data);
  //alert(data);
   

     }
 },
     error: function(){}          
    }); 
} 



$(document).ready(function (loginabc41) {
 $("#adddbooking").on('submit',(function(loginabc41) {
  $("#form_abc1_img").show();
  loginabc41.preventDefault();
  $.ajax({
   url: "return.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});



$(document).ready(function (loginabc41a) {
 $("#blockids").on('submit',(function(loginabc41a) {
  $("#form_abc1_img").show();
//  alert();
  loginabc41a.preventDefault();
  $.ajax({
   url: "blockstaff.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
     $("#form_abc1_img").hide();
   $("#datarts").show().html(data);
      },
     error: function(){}          
    });

 }));
});






function subcat(id)
{

$.ajax({
       type: "POST",
         url: "showservice.php",
            data: "cat="+id, 
          success: function(html)
            {    
            
              $("#msdddda").html(html);
                      
             }
        

            });
      
      }
      
 </script>

<!--  <script type="text/javascript">
   function togless(id){
    
    $('#appointmentdiv').hide();
    alert();
    $('#blockuser').hide();

    $('#'+id).toggle();
   }

     function togless2(id){
        $('#appoint').removeClass();
        $('#block').removeClass();
    $('#'+id).toggleClass('active_appoint');
   }
</script> -->


<style type="text/css">
  .ms-drop ul {
    overflow: auto;
    margin: 0;
    padding: 5px 8px;
    height: 110px;
    overflow: auto;
    max-height: unset !important;
}
.ms-drop ul
{

}
/* width */
.ms-drop ul::-webkit-scrollbar {
  width: 4px;
}

/* Track */
.ms-drop ul::-webkit-scrollbar-track {
  background: #f1f1f1; 
}

/* Handle */
.ms-drop ul::-webkit-scrollbar-thumb {
  background: #888; 
}

/* Handle on hover */
.ms-drop ul::-webkit-scrollbar-thumb:hover {
  background: #555; 
}

</style>










<style type="text/css">
  
  .vendoradmin_model .model_body_blog1 .title_blog .ms-choice
  {
    display: block;
    text-align: center;
    font-size: 16px;
    text-transform: capitalize;
    outline: none !important;
    box-shadow: none !important;
    text-align: left;
    width: auto;
    min-width: 125px;
    border-radius: 0;
    text-transform: capitalize;
    font-weight: 400;
    text-align: center;
    padding: 6px 0px;
    overflow: hidden;
    height: 21px;
    border-radius: 5px;
  }
  .vendoradmin_model .model_body_blog1 .title_blog .ms-choice> span
  {
    position: absolute !important;
    padding: 0;
    display: block;
    white-space: normal;
  }




.vendoradmin_model .modal-content {
    min-height: 80vh;
}





</style>




