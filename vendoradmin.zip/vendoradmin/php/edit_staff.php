<?php include('../../common/config.php');

  extract($_POST);

$strtotime=strtotime('now');

$profile_pic_path=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], "../img/".$profile_pic_path);

if(!empty($_FILES['image']['name'])){

$check= mysqli_query($conn,"update staff set name='$name', address='$address', mobile='$mobile', home_phone='$home_phone', email='$email', start_date='$start_date',schedule_from='$schedule_from',schedule_to='$schedule_to',responsibility='$responsibility',area='$area',role='$role',staff_functions='$staff_functions',salary='$salary',profile_pic_path='$profile_pic_path',strtotime='$strtotime' where id='$ids'");


}else{

$check= mysqli_query($conn,"update staff set name='$name', address='$address', mobile='$mobile', home_phone='$home_phone', email='$email', start_date='$start_date',schedule_from='$schedule_from',schedule_to='$schedule_to',responsibility='$responsibility',area='$area',role='$role',staff_functions='$staff_functions',salary='$salary',strtotime='$strtotime' where id='$ids'");


}



$startdate=implode(',', $start_time);
$endtime=implode(',', $end_time);




foreach ($day as $key => $value) {

$counts=mysqli_num_rows(mysqli_query($conn,"select * from staff_schedule where salon_id='".$_SESSION['user_id']."' and staff_id='$ids' and day='$value'"));


if($counts >0){
	mysqli_query($conn,"update staff_schedule set salon_id='".$_SESSION['user_id']."',staff_id='$ids',day='$value',start_time='$startdate',end_time='$endtime' where staff_id='$ids'");


}else{

mysqli_query($conn,"insert into staff_schedule set salon_id='".$_SESSION['user_id']."',staff_id='$ids',day='$value',start_time='$startdate',end_time='$endtime'");

}
}

$startdate1=implode(',', $start_time1);
$endtime1=implode(',', $end_time1);

$startdate2=implode(',', $start_time2);
$endtime2=implode(',', $end_time2);


$startdate3=implode(',', $start_time3);
$endtime3=implode(',', $end_time3);

$startdate4=implode(',', $start_time4);
$endtime4=implode(',', $end_time4);


$startdate5=implode(',', $start_time5);
$endtime5=implode(',', $end_time5);


$startdate6=implode(',', $start_time6);
$endtime6=implode(',', $end_time6);

$startdate7=implode(',', $start_time7);
$endtime7=implode(',', $end_time7);


$stff11=mysqli_query($conn,"select * from staff_schedule where staff_id ='".$ids."' and salon_id='".$_SESSION['user_id']."'");
while($stfnm=mysqli_fetch_array($stff11)){

if($stfnm['day']=='1'){

mysqli_query($conn,"update staff_schedule set start_time='$startdate1',end_time='$endtime1' where staff_id ='".$ids."' and salon_id='".$_SESSION['user_id']."' and day='1'");

}

else if($stfnm['day']=='2'){

mysqli_query($conn,"update staff_schedule set start_time='$startdate2',end_time='$endtime2' where staff_id ='".$ids."' and salon_id='".$_SESSION['user_id']."' and day='2'");

}


else if($stfnm['day']=='3'){

mysqli_query($conn,"update staff_schedule set start_time='$startdate3',end_time='$endtime3' where staff_id ='".$ids."' and salon_id='".$_SESSION['user_id']."' and day='3'");

}


else if($stfnm['day']=='4'){

mysqli_query($conn,"update staff_schedule set start_time='$startdate4',end_time='$endtime4' where staff_id ='".$ids."' and salon_id='".$_SESSION['user_id']."' and day='4'");

}

else if($stfnm['day']=='5'){

mysqli_query($conn,"update staff_schedule set start_time='$startdate5',end_time='$endtime5' where staff_id ='".$ids."' and salon_id='".$_SESSION['user_id']."' and day='5'");

}

else if($stfnm['day']=='6'){

mysqli_query($conn,"update staff_schedule set start_time='$startdate6',end_time='$endtime6' where staff_id ='".$ids."' and salon_id='".$_SESSION['user_id']."' and day='6'");

}

else if($stfnm['day']=='7'){

mysqli_query($conn,"update staff_schedule set start_time='$startdate7',end_time='$endtime7' where staff_id ='".$ids."' and salon_id='".$_SESSION['user_id']."' and day='7'");

}

}








 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> successfully.. Edited Staff</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="Staff.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 


?>