<?php include ('header.php');?>

 <link rel="stylesheet" href="datepicker/pikaday.css">

<div class="container-fluid">



<form method="post" id="addcustm" enctype="multipart/form-data">

  <div class="row page-titles">

        <div class="col-md-6 col-8 align-self-center">

            <h3 class="text-themecolor m-b-0 m-t-0">Gesti��n de cartera de servicios.



</h3>

            <ol class="breadcrumb">

                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>

                <li class="breadcrumb-item active">Gesti��n de cartera de servicios.

</li>

            </ol>

        </div>

        <div class="col-md-6 col-4 align-self-center">

            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->

        </div>

    </div>

  <div class="addsalon">

    <!-- <div class="salon_img_div" style="background: url('img/camera.jpg');">

      <input type="file" class="choosefile" name="image">

    </div> -->



<!-- 

      <div class="col-sm-6">

      <div class="form-group">

        <label>DNI*</label>

        <input type="text" class="form-control" placeholder="" name="DNI">

      </div>

    </div> -->



<div class="col-sm-6"  style="overflow: unset; ">

      <div class="form-group" style="overflow: unset; ">

        <label>Servicio*</label>

        <select type="text" class="form-control" placeholder="" name="category_id" required="required" onchange="getsubcat(this.value);">

        <option value="">Seleccionar Servicio</option>

        <?php $sqliii=mysqli_query($conn,"select * from category");

      while($stnm=mysqli_fetch_array($sqliii)){

        ?>



    <option value="<?php echo $stnm['id'];?>"><?php echo $stnm['name'];?></option>

<?php }?>

        </select>

      </div>

    </div>







<div class="col-sm-6"  style="overflow: unset; ">

      <div class="form-group" style="overflow: unset; ">

        <label>Tipo de Servicio</label>

        <select class="form-control" name="subcategory_id" id="change" required="required">

        <option value="">Tipo de Servicio</option>

       

        </select>

      </div>

    </div>







  

<div class="col-sm-12" style="padding: 0;">

    <div class="col-sm-6">

      <div class="form-group">

        <label>Nombre*</label>

        <input type="text" class="form-control" placeholder="" name="name" required="required">

      </div>

    </div>





    <div class="col-sm-6">

      <div class="form-group">

        <label>Precio</label>

        <input type="number" class="form-control" placeholder="" name="price" required="required">

      </div>

    </div>

    </div>





<div class="col-sm-12"  style="overflow: unset; ">

      <div class="form-group" style="overflow: unset; ">

        <label>Estilista*</label>

        <select type="text" class="form-control" placeholder="" name="stylist[]" multiple="multiple" id="msdddd" required="required">

        <option value="">Seleccionar personal</option>

        <?php $sqliii=mysqli_query($conn,"select * from staff where  salon_id='".$_SESSION['user_id']."'");

      while($stnm=mysqli_fetch_array($sqliii)){

        ?>



    <option value="<?php echo $stnm['id'];?>"><?php echo $stnm['name'];?></option>

<?php }?>

        </select>

      </div>

    </div>

  <div class="col-sm-6">

      <div class="form-group">

        <label>Descripci��n</label>

        <textarea type="text" class="form-control" placeholder="" name="description" ></textarea>

      </div>

    </div>





    <div class="col-sm-6">

      <div class="form-group">

        <label>Material usado</label>

        <textarea type="text" class="form-control" placeholder="" name="used_material" ></textarea>

      </div>

    </div>

    

    <div class="col-sm-12">



    <button class="addsalonbtn" name="submit" type="submit">A�0�9adir servicio

</button>

</div>

    

  </div>

  <div id="datart"></div>

  </form>

</div>

<?php include ('footer.php');?>

    <script src="datepicker/pikaday.js"></script>

<link rel="stylesheet" href="multiple-select.css"/>



 <script src="multiple-select.js"></script>

<script type="text/javascript">



    $(function() {

        $('#msdddd').change(function() {

            console.log($(this).val());

        }).multipleSelect({

            width: '100%'

        });

    });





$(document).ready(function (custm) {

 $("#addcustm").on('submit',(function(custm) {

     // alert();



  $("#form_abc1_img").show();

  custm.preventDefault();

  $.ajax({

   url: "php/add_service.php",

   type: "POST",

   data:  new FormData(this),

   contentType: false,

         cache: false,

   processData:false,

   success: function(data){

  // alert();

     $("#form_abc1_img").hide();

   $("#datart").show().html(data);

      },

     error: function(){}          

    });



 }));

});







  new Pikaday(

  {

    field: document.getElementById('dater'),

    trigger: document.getElementById('datepicker-button'),

    minDate: new Date(2000, 0, 1),

    ariaLabel: 'Custom label',

    maxDate: new Date(2020, 12, 31),

    yearRange: [2010,2020]



  });









  function getsubcat(id)



{

$.ajax({



       type: "POST",



         url: "php/subcategory.php",



            data: "cat="+id, 



          success: function(html)



            {     



              $("#change").html(html);



                      



             }



      



            });





      }





</script>





</script>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE&sensor=false&libraries=places"></script>



<script type="text/javascript">





  google.maps.event.addDomListener(window, 'load', function () {



  /*  var options = {



      componentRestrictions: {country: "in"}

    };*/

    var places = new google.maps.places.Autocomplete(document.getElementById('txtPlacesss'));



    google.maps.event.addListener(places, 'place_changed', function () {



      var place = places.getPlace();



      var address = place.formatted_address;



      var latitude = place.geometry.location.lat();



      var longitude = place.geometry.location.lng();



      var mesg = "Address: " + address;



      mesg += "\nLatitude: " + latitude;



      mesg += "\nLongitude: " + longitude;





      $("#latitude").val(latitude);

      $("#longitude").val(longitude);



    });



  });













</script> <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>

  <script>tinymce.init({ selector:'textarea' });</script>





  <style type="text/css">

      

.mce-notification-warning{



display: none;



}



  </style>