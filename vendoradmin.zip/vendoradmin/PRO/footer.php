
<!-- notification model -->



<div class="model_1-notofication">
    <div class="modal fade" id="notification" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header_blog">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                    <a href="" class="done-btn">Done</a>
                    <h2>Jane Deo on 29 Nov</h2>
                </div>
                <div class="">
                    <div class="model_body_blog1">
                        <div class="title_blog">
                            <div class="blog_2_title">

                                <h1>Jane Doe <span class="repeat">Repeat</span></h1>
                                <div class="content_blog_model">
                                    <div class="overflow-h">
                                        <span class="refersh_icon"><i class="fa fa-refresh"></i></span>
                                        <p class="model_para1">Congratulations, you've received a repeat cutomer via treatwell meaning you don't pay commission! Tap to dismiss</p>
                                    </div>

                                </div>
                            </div>
                            <p>Client Notes</p>

                        </div>
                        <div class="title_blog model_body_blog2">
                            <p><span style="color: #82BC5B;">Confirmed</span> &nbsp; <span style="color: red;">UNPAID </span> <span class="pull-right"><i class="fa fa-ellipsis-h"></i></span></p>
                            <h2>Hot Stone  Massage</h2>
                            <p>60 minutes</p>
                            <p>11:00 - 12:00(1 h)</p>
                            <p>Mrs. Owner</p>
                            <p>Booked on 28 November Via Dala3</p>
                            <p style="color: red;">$35</p>
                        </div>

                        <div class="addnext">
                            Add next service
                        </div>
                        <div class="title_blog model_body_blog2 order_div">
                            <h2>Dala Order #212282782</h2>
                            <p>Booked on 28/11/2019, 14:17</p>

                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>

        </div>
    </div>
</div>
 <!-- ////notification model -->




 <!-- **************************************** -->
 <!-- **************************************** -->



  <!-- Appointment model -->

<div class="model_1-notofication">
    <div class="modal fade" id="appointment" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header_blog">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>

                    <ul class="appointment_list">
                    	<li onclick="togless2('appoint')"><a href="javascript:;" onclick="togless('appointmentdiv')" id="appoint" class="active_appoint">Appointment</a></li>
                    	<li onclick="togless2('block')"><a href="javascript:;" onclick="togless('blockuser')" id="block">Block</a></li>
                    </ul>
                </div>
                <div class="overflow-h appointment_div" id="appointmentdiv" >
                    <div class="model_body_blog1">
                        <div class="title_blog">
                            <div class=" overflow-h">
                            	<p>Client</p>
                            	<div class="col-sm-4 padder">
                            		<div class="form-group input_box">
                            			<input type="text" placeholder="Search for Client" class="form-control" name="">
                            		</div>
                            	</div>
                            	<div class="col-sm-3 ">
                            		<div class="form-group input_box">
                            			<input type="text" placeholder="Phone"  class="form-control" name="">
                            		</div>
                            	</div>
                            	<div class="col-sm-4 padder">
                            		<div class="form-group input_box ">
                            			<input type="text" placeholder="Email"  class="form-control"  class="Email" name="">
                            		</div>
                            	</div>
                            	<div class="col-sm-1 padder">
                            		<a href="" class="pull-right edit" >
                            		<i class="fa fa-pencil-square"></i></a>
                            	</div>
                               
                            </div>
                            

                        </div>
                        <div class="title_blog overflow-h">
                            <div class="form-group input_box ">
                            	<select   class="form-control">
                            		<option>Service not Selected</option>
                            	</select>
                            </div>
                            <br>
                            <div class="col-sm-3 padder">
                            	<div class="form-group input_box ">
                            		<label>Date</label>
	                            	<input type="date" placeholder="Email"  class="form-control"  class="Email" name="">
	                            </div>
                            </div>
                            <div class="col-sm-3 padder">
                            	<div class="form-group input_box ">
                            		<label>Time</label>
                            		<select   class="form-control">
	                            		<option>11:45</option>
	                            	</select>
	                            </div>
                            </div>
                            <div class="col-sm-3 padder">
                            	<div class="form-group input_box ">
                            		<label>Duration</label>
                            		<select   class="form-control">
	                            		<option>1h</option>
	                            	</select>
	                            </div>
                            </div>
                             <div class="col-sm-3 padder">
                            	<div class="form-group input_box ">
                            		<label>Team member</label>
                            		<select   class="form-control">
	                            		<option>Jane 1</option>
	                            	</select>
	                            </div>
                            </div>
                            <br>
                            <div class="col-sm-12 padder">
                            	<div class="form-group input_box ">
                            		<input type="text" class="form-control" placeholder="ends on 12:45" name="">
	                            </div>
                            </div>
                            <br>
                            <a href="">Add note</a>
                            
                        </div>
                        <div class="col-sm-10">
                        	<div class="add_service">
                        		<button class="btn btn-default">+&nbsp;Add next service</button>
                        	</div>
                        </div>
                        <div class="col-sm-2 padder">
                        	<div class="save">
                        		 <button class="save_bnt">Save</button>
                        	</div>
                        </div>
                        

                    </div>
                </div>
                <div class="overflow-h block_div" id="blockuser" style="display: none;">
                    <div class="block_user_wrappper">
                        <div class="title_blog overflow-h ">
                            <div class="col-sm-1 padder">
                                <div class="ban_icon">
                                    <i class="fa fa-ban"></i>
                                </div>
                            </div>
                             <div class="col-sm-11">
                                <div class="block_para">
                                    <p>Make this time slot unavailable for  bookings. you can also use blocks for defining lunch hours or block specific weekdays.</p>

                                </div>                                
                            </div>
                        </div>
                            <div class="block_usr_form title_blog overflow-h ">
                                    <div class="form-group input_block_1 ">
                                        <label>Team members</label>
                                        <select class="form-control">
                                            <option>For all team members</option>
                                        </select>
                                    </div>
                                    <div class="form-group input_block_1">
                                        <label>Description</label>
                                        <input type="text" placeholder="" class="form-control" name="">
                                    </div>
                                    <div class="form-group input_block_1">
                                        <label>Repeat</label>
                                        <select class="form-control">
                                            <option>none</option>
                                        </select>
                                    </div>
                                    <div class="form-group input_block_1">
                                        <label>Start date</label>
                                        <input type="date" class="form-control"  name="">
                                        <br>
                                        <input type="time" class="form-control"  name="">
                                    </div>
                                     <div class="form-group input_block_1">
                                        <label>End date</label>
                                        <input type="date" class="form-control"  name="">
                                        <br>
                                        <input type="time" class="form-control"  name="">
                                    </div>                           
                        </div>
                        <div class="col-sm-10">
                            <div class="add_service">
                               
                            </div>
                        </div>
                        <div class="col-sm-2 padder">
                            <div class="save">
                                 <button class="save_bnt">Save</button>
                            </div>
                        </div>
                    </div>
                </div>
              
            </div>

        </div>
    </div>
</div>

  <!-- Appointment model -->

 <!-- **************************************** -->
 <!-- **************************************** -->


</div>
<script type="text/javascript">
   function togless(id){
    $('#appointmentdiv').hide();
    $('#blockuser').hide();
    $('#'+id).toggle();
   }
     function togless2(id){
        $('#appoint').removeClass();
        $('#block').removeClass();
    $('#'+id).toggleClass('active_appoint');
   }
</script>


</body>
</html>