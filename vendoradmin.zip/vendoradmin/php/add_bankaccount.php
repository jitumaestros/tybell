<?php include('../../common/config.php');

  extract($_POST);

$image=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], "../img/".$image);


$check= mysqli_query($conn,"INSERT INTO bank_account(bank_name, account_number, account_owner, icon, notes)VALUES ('$bank_name', '$account_number', '$account_owner', '$image', '$notes')");

 $insert_id= mysqli_insert_id($conn);
 
 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Cuenta bancaria agregada exitosamente</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="bank_account.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 


?>