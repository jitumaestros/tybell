<?php extract($_POST);          
   
echo "<script>window.location='dashboard.php?service=$service';</script>";
    ?>

