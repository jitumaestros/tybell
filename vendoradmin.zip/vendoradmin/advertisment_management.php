<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Advertising management</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Advertising management</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		<div class="salon_img_div" style="background: url('img/camera.jpg');">
			<input type="file" class="choosefile" name="">
		</div>
		
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Select advertising</label>
				<select class="form-control">
					<option>Select advertising</option>
					<option>advertising1</option>
					<option>advertising2</option>
					<option>advertising3</option>
				</select>
				
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Segment advertising</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Schedule ads</label>
				<input type="date" class="form-control" placeholder="" name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Analyze interaction and effectiveness</label>
				<input type="date" class="form-control" placeholder="" name="">
			</div>
		</div>
		

		
		
		
		
		
		
		
		
		
		<button class="addsalonbtn">Add Salon </button>
		

	</div>
</div>
<?php include ('footer.php');?>