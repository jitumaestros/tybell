<?php include ('header.php');
$edit=mysqli_fetch_array(mysqli_query($conn,"select * from bank_account where id='".$_GET['id']."'"));

?>
<div class="container-fluid">

<form method="post" id="addcustm" enctype="multipart/form-data">
<input type="hidden" name="ids" value="<?php echo $_GET['id'];?>">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Editar cuenta bancaria</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">Editar cuenta bancaria</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		<!-- <div class="salon_img_div" style="background: url('img/camera.jpg');">
			<input type="file" class="choosefile" name="image">
		</div> -->
		
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Nombre del banco*</label>
				<input type="text" class="form-control" placeholder="" name="bank_name" value="<?php echo $edit['bank_name'];?>">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Número de cuenta*</label>
				<input type="text" class="form-control" placeholder="" name="account_number"  value="<?php echo $edit['account_number'];?>">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Propietario de la cuenta*</label>
				<input type="text" class="form-control" placeholder="" name="account_owner"  value="<?php echo $edit['account_owner'];?>">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Icono</label>
				<input type="file" class="form-control" placeholder="" name="image" >
								<img src="img/<?php echo $edit['icon'];?>" width="100px">

			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Notas*</label>
				<input type="text" class="form-control" placeholder="" name="notes"  value="<?php echo $edit['notes'];?>">
			</div>
		</div>
	
		
		<button class="addsalonbtn" name="submit" type="submit">Añadir cliente</button>
		
	</div>
	<div id="datart"></div>
	</form>
</div>
<?php include ('footer.php');?>
<script type="text/javascript">
	


$(document).ready(function (custm) {
 $("#addcustm").on('submit',(function(custm) {
 	   	//alert();

  $("#form_abc1_img").show();
  custm.preventDefault();
  $.ajax({
   url: "php/edit_bankaccount.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert();
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});
</script>

