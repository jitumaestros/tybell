<?php include ('header.php');?>
<div class="team_member_blog">
	<div class="team-wrapper">
		<button class="btn btn-default">Active</button>
		<a href="team_member_from.php"><button class="addmenber">+ Add team member</button></a>
		<div class="show_team_memeber">
<?php $sqlii=mysqli_query($conn,"select * from staff where salon_id='".$_SESSION['user_id']."' order by id desc");
while($stff=mysqli_fetch_array($sqlii)){

?>
			<div class="usetr_blog">
				<a href="edit_team_member.php?id=<?php echo $stff['id'];?>" style="color: black">
				<div class="img_blog">
					<div class="team_member-img_blog">
						<img src="../img/<?php echo $stff['profile_pic_path'];?>">
					</div>
				</div>
				<div class="team_member_content">
					<span class="pull-right" style="color: #6BBE4A;"><i class="fa fa-circle"></i> &nbsp;Provides Services</span>
					<h2 class="team-name"><?php echo $stff['name'];?></h2>
					<p class="team-post"><?php echo $stff['job_title'];?></p>
</a>
					<?php if($stff['status']=='1'){?>
					<span class="btn btn-default"><?php echo $stff['permissions'];?></span>
					<span  class="addmenber pull-unset">Can log in</span>
					<?php }?>
				</div>
			</div>
			<?php }?>
		<!-- 	<div class="usetr_blog">
				
				<div class="img_blog">
					<div class="team_member-img_blog">
						<img src="img/images.jpg">
					</div>
				</div>
				<div class="team_member_content">
					<span class="pull-right" style="color: #6BBE4A;"><i class="fa fa-circle"></i> &nbsp;Provides Services</span>
					<h2 class="team-name">Mrs. Owner</h2>
					<p class="team-post">Director</p>
					<span class="btn btn-default">Owner</span>
					<span  class="addmenber pull-unset">Can log in</span>
				</div>
			</div> -->
		</div>
	</div>
</div>











<?php include ('footer.php');?>