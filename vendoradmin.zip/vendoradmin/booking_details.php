<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Detalles de la reserva.</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active"> Detalles de la reserva.</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
           <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		
		<div class="table-respnsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					
<!-- 					<th>Salon Name</th>
 -->					<th>Services Name</th>
					<th>Schedule date & Time</th>
					<th>Services Amount</th>
					<th>Total Amount</th>
					<th>Orden ref</th>
					<th>User name</th>
				  <th> User Email Address</th>
					<th>User Contact Number</th>

<!-- 					<th>User reservations</th>
 -->

				</thead>
				<tbody>

                 <?php
$n='1';

				$bokkd=mysqli_query($conn,"select * from bookings where id='".$_GET['id']."' order by id desc");

				while($bkkstatus=mysqli_fetch_array($bokkd)){

				$sln=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bkkstatus['salon_id']."'"));
				$servci1=explode(',', $bkkstatus['service_id']);

				$sernm='';

				foreach ($servci1 as $key => $valuse) {

					$serbn=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$valuse."'"));
					
//$price +=$serbn['price'];

					if($sernm==''){

						$sernm=$serbn['name'];

					}else{

						$sernm=$sernm.' & '.$serbn['name'];

					}
				}

$exc=explode(',',$bkkstatus['service_price']);

$user=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bkkstatus['user_id']."'"));
				?>
					<tr>
						<td><?php echo $sernm;?></td>
						<td><?php echo date('D M d Y', $bkkstatus['dates']);?>, <?php echo $bkkstatus['schedule_time'];?> </td>
						<td>£<?php echo $exc['0'];?> & <?php echo $exc['1'];?> </td>
						<td>£<?php echo $bkkstatus['total_amount'];?> </td>
						<td><?php echo $bkkstatus['order_ref'];?> </td>
						<td><?php echo $user['first_name'];?> <?php echo $user['last_name'];?></td>
						<td><?php echo $user['email'];?> </td>
						<td><?php echo $user['phone'];?> </td>

					</tr>
					<?php }?>

				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>