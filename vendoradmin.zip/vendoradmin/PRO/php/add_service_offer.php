<?php include('../../../common/config.php');

  extract($_POST);

$catid2=implode(',', $catid);
	$validation =Array(
		'catid2'=>$catid2
		
	);


	$validation_check=array_search(null, $validation);

	if($validation_check)
	{
		   echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Por favor seleccione la categoría</span>
</div></div>';
die;
	}

$strtotime=strtotime('now');

$offer_start_date1=strtotime($offer_start_date);

$offer_end_date1=strtotime($offer_end_date);

$start_date1=date('Y-m-d',$offer_start_date1);
$end_date1=date('Y-m-d',$offer_end_date1);



$catid1=explode(',', $catid2);

$discount_id=rand(100,999);
if($ship_rd=='0'){
foreach ($service_id as $key => $value) {

$check= mysqli_query($conn,"INSERT INTO promotion (salon_id, service_id, offer,strtotime,offer_start_date,offer_end_date,start_date,end_date,name,category_id,discount_id,discount_status)VALUES ('".$_SESSION['user_id']."', '$value', '$offer', '$strtotime','$offer_start_date1','$offer_end_date1','$start_date1','$end_date1','$name','$catid[$key]','$discount_id','$ship_rd')");

}
}else{

$impdta=implode(',', $day);
$offer1=implode(',', $dayweek1);
$offer2=implode(',', $dayweek2);
$offer3=implode(',', $dayweek3);

$dayweekcount1=implode(',', $weeknmmon);

$dayweekcount2=implode(',', $weeknm2nb);

$dayweekcount3=implode(',', $weeknm3dy);

$exv=explode(',', $dayweekcount1);




foreach ($service_id as $key => $value) {
	$days = $day[$key];

$check= mysqli_query($conn,"INSERT INTO promotion (salon_id, service_id,strtotime,name,category_id,discount_id,discount_status,day)VALUES ('".$_SESSION['user_id']."', '$value','$strtotime','$name','$catid[$key]','$discount_id','$ship_rd','$impdta')");

}


foreach ($day as $key => $values) {


	$check= mysqli_query($conn,"INSERT INTO Off_peak_time (discount_id, day,salon_id)VALUES ('".$discount_id."', '$values','".$_SESSION['user_id']."')");
}

$stff11=mysqli_query($conn,"select * from Off_peak_time where discount_id ='".$discount_id."'  and salon_id='".$_SESSION['user_id']."' ");
while($stfnm=mysqli_fetch_array($stff11)){

	if($stfnm['day']=='1'){
		
	$check= mysqli_query($conn,"update Off_peak_time set dayweekcount='$dayweekcount1',offer='$offer1' where  salon_id='".$_SESSION['user_id']."' and day='1' ");
}
else if($stfnm['day']=='2'){


	$check= mysqli_query($conn,"update Off_peak_time set dayweekcount='$dayweekcount2',offer='$offer2' where  salon_id='".$_SESSION['user_id']."' and day='2' ");


}
else if($stfnm['day']=='3'){

	$check= mysqli_query($conn,"update Off_peak_time set dayweekcount='$dayweekcount3',offer='$offer3' where  salon_id='".$_SESSION['user_id']."' and day='3' ");

}

}


}


 $insert_id= mysqli_insert_id($conn);

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Exitosamente .. Oferta de servicio añadido.</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="disount-page.php?service=service";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 

?>