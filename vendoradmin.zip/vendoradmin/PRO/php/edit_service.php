<?php include('../../../common/config.php');

  extract($_POST);

$strtotime=strtotime('now');
$stylist1=implode(',', $stylist);

$pric=implode(',', $sale_price);

$sale_price1=explode(',', $pric);

       $description1 = mysqli_real_escape_string($conn,$description);


$pric1=implode(',', $price);

$sale_price12=explode(',', $pric1);



if($offer!=''){

$check= mysqli_query($conn,"update service set name='$name', description='$description1', sale_price='".$sale_price1['0']."', used_material='$used_material', stylist='$stylist1', salon_id='".$_SESSION['user_id']."',category_id='$category_id',subcategory_id='$subcategory_id',offer='$offer',offer_status='1',price='".$sale_price12['0']."' where id='$ids'");

}else{

  $check= mysqli_query($conn,"update service set name='$name', description='$description1', sale_price='".$sale_price1['0']."', used_material='$used_material', stylist='$stylist1', salon_id='".$_SESSION['user_id']."',category_id='$category_id',subcategory_id='$subcategory_id',offer='$offer',price='".$sale_price12['0']."' where id='$ids'");

}





 $insert_id= mysqli_insert_id($conn);

$sercount=mysqli_num_rows(mysqli_query($conn,"select * from service_price_level where service_id='".$ids."' and salon_id='".$_SESSION['user_id']."'"));

if($sercount=='0'){

foreach ($name_price_vevel as $key => $value) {

 mysqli_query($conn,"INSERT INTO service_price_level (salon_id, service_id, name_price_vevel, duration, price, sale_price)VALUES ('".$_SESSION['user_id']."', '$ids', '$value', '$duration[$key]', '$price[$key]', '$sale_price[$key]')");

}

}else{

foreach ($peicelid as $key => $value) {

/* mysqli_query($conn,"INSERT INTO service_price_level (salon_id, service_id, name_price_vevel, duration, price, sale_price)VALUES ('".$_SESSION['user_id']."', '$ids', '$value', '$duration[$key]', '$price[$key]', '$sale_price[$key]')");
*/
mysqli_query($conn,"update service_price_level set name_price_vevel='$name_price_vevel[$key]',duration='$duration[$key]',price='$price[$key]',sale_price='$sale_price[$key]' where service_id='$ids' and id='$value'");

}

}


 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>servicio editado con éxito</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="service.php?service='.$service.'";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

	
}

 


?>