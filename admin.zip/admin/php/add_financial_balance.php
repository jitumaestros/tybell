<?php include('../../common/config.php');

 extract($_POST);

$check= mysqli_query($conn,"insert into financial_balance set title='$title', fee='$fee',salon_id='$salon_id'");

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>financial balance added successfully</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="financial_balance.php?salon_id='.$salon_id.'";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }

else{
	echo 'error';
}

 


?>