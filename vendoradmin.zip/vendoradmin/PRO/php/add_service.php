<?php include('../../../common/config.php');

  extract($_POST);

$strtotime=strtotime('now');
$stylist1=implode(',', $stylist);

$pric=implode(',', $sale_price);

$sale_price1=explode(',', $pric);

$pric1=implode(',', $price);

$sale_price12=explode(',', $pric1);

       $description1 = mysqli_real_escape_string($conn,$description);


$check= mysqli_query($conn,"INSERT INTO service (name, description, sale_price, used_material, stylist, salon_id,strtotime,category_id,subcategory_id,price)VALUES ('$name', '$description1', '".$sale_price1['0']."', '$used_material', '$stylist1', '".$_SESSION['user_id']."','$strtotime','$category_id','$subcategory_id','".$sale_price12['0']."')");

 $insert_id= mysqli_insert_id($conn);

foreach ($name_price_vevel as $key => $value) {


	
 mysqli_query($conn,"INSERT INTO service_price_level (salon_id, service_id, name_price_vevel, duration, price, sale_price,offer)VALUES ('".$_SESSION['user_id']."', '$insert_id', '$value', '$duration[$key]', '$price[$key]', '$sale_price[$key]','$offer')");

}



 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Exitosamente .. Servicio añadido.</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="service.php?service='.$service.'";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

	
}

 


?>