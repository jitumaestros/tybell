<?php include ('header.php');
$edit=mysqli_fetch_array(mysqli_query($conn,"select * from financial_balance where id='".$_GET['id']."'"));
?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Financial balance</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">Financial balance</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
         
        </div>
    </div>
    <form method="post" id="addcustm" enctype="multipart/form-data">
        <input type="hidden" name="salon_id" value="<?php echo $_GET['salon_id'];?>">

	<div class="addsalon">
		
	<div class="col-sm-12">
			<div class="form-group">
				<label>Title</label>
				<select type="text" class="form-control" name="title" required="required">
        <option value="">Select</option>
        <option value="1">Fee for New customers</option>
        <option value="2">Fee for Old Customers</option>
        </select>
			</div>
		</div>
			
<div class="col-sm-12">
			<div class="form-group">
				<label>Fee</label>
				<input type="text" class="form-control" name="fee" value="<?php echo $edit['fee'];?>" >
			</div>
		</div>
		
		<button class="addsalonbtn" type="submit" name="submit"> Save</button>
		
	</div>
	<div id="datart"></div>
</div>

<?php include ('footer.php');?>
<script type="text/javascript">
	
$(document).ready(function (custm) {
 $("#addcustm").on('submit',(function(custm) {
 	   //	alert();

  $("#form_abc1_img").show();
  custm.preventDefault();
  $.ajax({
   url: "php/add_financial_balance.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert(data);
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});
</script>


