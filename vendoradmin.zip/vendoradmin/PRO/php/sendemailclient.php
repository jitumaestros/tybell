
<style type="text/css">
    @media screen {
    @font-face {
      font-family: 'Lato';
      font-style: normal;
      font-weight: 400;
      src: local('Lato Regular'), local('Lato-Regular'), url(https://fonts.gstatic.com/s/lato/v11/qIIYRU-oROkIk8vfvxw6QvesZW2xOQ-xsNqO47m55DA.woff) format('woff');
    }
    
    @font-face {
      font-family: 'Lato';
      font-style: normal;
      font-weight: 700;
      src: local('Lato Bold'), local('Lato-Bold'), url(https://fonts.gstatic.com/s/lato/v11/qdgUG4U09HnJwhYI-uK18wLUuEpTyoUstqEm5AMlJo4.woff) format('woff');
    }
    
    @font-face {
      font-family: 'Lato';
      font-style: italic;
      font-weight: 400;
      src: local('Lato Italic'), local('Lato-Italic'), url(https://fonts.gstatic.com/s/lato/v11/RYyZNoeFgb0l7W3Vu1aSWOvvDin1pK8aKteLpeZ5c0A.woff) format('woff');
    }
    
    @font-face {
      font-family: 'Lato';
      font-style: italic;
      font-weight: 700;
      src: local('Lato Bold Italic'), local('Lato-BoldItalic'), url(https://fonts.gstatic.com/s/lato/v11/HkF_qI1x_noxlxhrhMQYELO3LdcAZYWl9Si6vvxL-qU.woff) format('woff');
    }
    }
    
    body, table, td, a { -webkit-text-size-adjust: 100%; -ms-text-size-adjust: 100%; }
    table, td { mso-table-lspace: 0pt; mso-table-rspace: 0pt; }
    img { -ms-interpolation-mode: bicubic; }

    img { border: 0; height: auto; line-height: 100%; outline: none; text-decoration: none; }
    table { border-collapse: collapse !important; }
    body { height: 100% !important; margin: 0 !important; padding: 0 !important; width: 100% !important; }

    a[x-apple-data-detectors] {
        color: inherit !important;
        text-decoration: none !important;
        font-size: inherit !important;
        font-family: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
    }

    div[style*="margin: 16px 0;"] { margin: 0 !important; }
</style>
<?php include('../../../common/config.php');

  extract($_POST);

$strtotime=strtotime('now');
$dobs=$datess.' '.$dob;

$check= mysqli_query($conn,"INSERT INTO send_email_client(salon_id, email, subject, venue_logo, title, description,booking_links,footer,strtotime)VALUES ('".$_SESSION['user_id']."', '$email', '".$subject."', '$venue_logo', '$title', '".$description."','$booking_links','$footer','$strtotime')");


 $insert_id= mysqli_insert_id($conn);

 if ($check) {


$messagetrrt.='<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td bgcolor="#E5376A" align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
                <tr>
                    <td align="center" valign="top" style="padding: 40px 10px 40px 10px;">
                       
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    <tr>
      <td bgcolor="#E5376A" align="center" style="padding: 0px 10px 0px 10px;">
          <table border="0" cellpadding="0" cellspacing="0" width="480" >
             <tr>
               <td bgcolor="#ffffff" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">
         <a href="" target="_blank">
                            <img alt="Logo" src="http://maestrosinfotech.com/Tybell/img/logo.png" width="100" height="100" style="display: block;  font-family: "Lato", Helvetica, Arial, sans-serif; color: #ffffff; font-size: 18px;" border="0">
                        </a>
                      </td>
                    </tr>
                  </table>';
     $messagetrrt.=' </td>
    </tr>
   
    <tr>
        <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
              <!-- COPY -->
              <tr>
                <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;" >
                  <h4 style="margin: 0;">Compose Mail</h4>
                  <p style="margin: 0;">Hola  </p>


                  <p style="margin: 0;">Subject:- '.$subject.'</p>
                   <p style="margin: 0;">Title:- '.$title.'</p>


                    <p style="margin: 0;">Message Body :-'.$description.'</p>

                      <p style="margin: 0;">Booking button links to :-'.$booking_links.'</p>

                      <p style="margin: 0;">'.$footer.'</p>

                </td>
              </tr>
             
                  
            </table>
        </td>
    </tr>';

     $messagetrrt.='<tr>
        <td bgcolor="#f4f4f4" align="center" style="padding: 30px 10px 0px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
                <tr>
                  <td bgcolor="#f4aec3" align="center" style="padding: 30px 30px 30px 30px; border-radius: 4px 4px 4px 4px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;" >
                    <h2 style="font-size: 20px; font-weight: 400; color: #111111; margin: 0;">Necesitas más ayuda?</h2>
                    <p style="margin: 0;"><a href="" style="color: #E5376A;">Nosotras son aquí, listo para hablar</a></p>
                  </td>
                </tr>
            </table>
        </td>
    </tr>
   
</table>';

     maildss($email,$fullname, $subject,$messagetrrt,'');







   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Enviar al correo electrónico del cliente</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="Clientes.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

	
}

 


?>