<?php include('../../common/config.php');

extract($_POST);

$vide=mysqli_query($conn,"delete from likes where user_id ='".$_SESSION['user_id']."' and post_id='$id' and status='1' and comment_id='$comment_id'");
 $dislikescounts=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$id."' and status='1' and comment_id='$comment_id'"));

if($vide){



    ?>
				<a href="javascript:;" onclick="dislikevdeo('<?php echo $id;?>','<?php echo $_SESSION['user_id'];?>','<?php echo $comment_id;?>');"><i class="fa fa-thumbs-o-down" aria-hidden="true" style="font-size: 18px"></i></a>
 <?php echo $dislikescounts;?>

<?php   }else{

echo '<div class="alert alert-danger"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong > Error..</strong></div>'; 

}
?>