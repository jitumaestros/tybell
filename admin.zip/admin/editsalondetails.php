<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Edit Salon Details</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Edit Salon Details</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		<div class="salon_img_div" style="background: url('img/capello-salon-naranpura-ahmedabad-beauty-spas-1ynrr6n.jpg');">
			<input type="file" class="choosefile" name="">
			
		</div>
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Vendor Name</label>
				<input type="text" class="form-control" placeholder="" name="" value="Lorem Ipsum">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Name</label>
				<input type="text" class="form-control" placeholder="" name="" value="Lorem Ipsum">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Address</label>
				<input type="text" class="form-control" placeholder="" name="" value="Lorem Ipsum is simply dummy text">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Mobile Number</label>
				<input type="text" class="form-control" placeholder="" name="" value="1532565t">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Email Address</label>
				<input type="text" class="form-control" placeholder="" name="" value="abc@gmail.com">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Started Date</label>
				<input type="date" class="form-control" name="" value="11/02/2016">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Open Time</label>
				<input type="time" class="form-control"  name="" value="11:00">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon Close Time</label>
				<input type="time" class="form-control" name="" value="10:00">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>Short Description in salon</label>
				<textarea class="form-control">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.
				</textarea>
			</div>
		</div>


		
		
		
		
		
		
		
		
		
		<button class="addsalonbtn">Save</button>
		

	</div>
</div>
<?php include ('footer.php');?>