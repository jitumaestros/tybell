<?php include ('header.php');?>
<div class="container-fluid">

<form method="post" id="addcustm" enctype="multipart/form-data">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Añadir cliente</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">Añadir cliente</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		<div class="salon_img_div" style="background: url('img/camera.jpg');">
			<input type="file" class="choosefile" name="image">
		</div>
		
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Nombre del cliente*</label>
				<input type="text" class="form-control" placeholder="" name="firstname">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Apellido del cliente*</label>
				<input type="text" class="form-control" placeholder="" name="lastname">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>DNI*</label>
				<input type="text" class="form-control" placeholder="" name="DNI">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Dirección del cliente</label>
				<input type="text" class="form-control" placeholder="" name="address" id="txtPlacesss">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Número de teléfono móvil*</label>
				<input type="text" class="form-control" placeholder="" name="mobile_number">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Teléfono de casa</label>
				<input type="text" class="form-control" placeholder="" name="home_phone">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Dirección de correo electrónico del cliente*</label>
				<input type="email" class="form-control" placeholder="" name="email_address">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Primera visita del cliente*</label>
				<input type="text" class="form-control" placeholder="" name="first_customer_visit">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Última visita del cliente (Por defecto el día de registro)</label>
				<input type="text" class="form-control" placeholder="" name="last_customer_visit">
			</div>
		</div>
		<!-- <div class="col-sm-6">
			<div class="form-group">
				<label>Customer Photo </label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div> -->
		
		<!-- <div class="col-sm-6">
			<div class="form-group">
				<label>Customer Email Address</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Customer Started Date</label>
				<input type="date" class="form-control" name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Customer Open Time</label>
				<input type="time" class="form-control"  name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Customer Close Time</label>
				<input type="time" class="form-control" name="">
			</div>
		</div> -->
		<!-- <div class="col-sm-12">
			<div class="form-group">
				<label>Short Description in salon</label>
				<textarea class="form-control">
					
				</textarea>
			</div>
		</div>
 -->
		
		<button class="addsalonbtn" name="submit" type="submit">Añadir cliente</button>
		
	</div>
	<div id="datart"></div>
	</form>
</div>
<?php include ('footer.php');?>
<script type="text/javascript">
	


$(document).ready(function (custm) {
 $("#addcustm").on('submit',(function(custm) {
 	   	//alert();

  $("#form_abc1_img").show();
  custm.preventDefault();
  $.ajax({
   url: "php/add_customer.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert();
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});
</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE&sensor=false&libraries=places"></script>

<script type="text/javascript">


  google.maps.event.addDomListener(window, 'load', function () {

  /*  var options = {

      componentRestrictions: {country: "in"}
    };*/
    var places = new google.maps.places.Autocomplete(document.getElementById('txtPlacesss'));

    google.maps.event.addListener(places, 'place_changed', function () {

      var place = places.getPlace();

      var address = place.formatted_address;

      var latitude = place.geometry.location.lat();

      var longitude = place.geometry.location.lng();

      var mesg = "Address: " + address;

      mesg += "\nLatitude: " + latitude;

      mesg += "\nLongitude: " + longitude;


      $("#latitude").val(latitude);
      $("#longitude").val(longitude);

    });

  });






</script>