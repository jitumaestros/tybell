<?php include('../../common/config.php');

  extract($_POST);

$image=$_FILES['image']['name'];
if(!empty($_FILES['image']['name'])){
move_uploaded_file($_FILES['image']['tmp_name'], "../img/".$image);


$check= mysqli_query($conn,"update customer  set firstname='$firstname', lastname='$lastname', DNI='$DNI', address='$address', mobile_number='$mobile_number', home_phone='$home_phone',email_address='$email_address',first_customer_visit='$first_customer_visit',last_customer_visit='$last_customer_visit',image='$image' where id='".$ids."' ");
}else{


$check= mysqli_query($conn,"update customer  set firstname='$firstname', lastname='$lastname', DNI='$DNI', address='$address', mobile_number='$mobile_number', home_phone='$home_phone',email_address='$email_address',first_customer_visit='$first_customer_visit',last_customer_visit='$last_customer_visit' where id='".$ids."' ");

}
 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> successfully.. Edited customer</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="removecustomer.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 


?>