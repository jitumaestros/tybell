<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Analysis of consumption of services</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Analysis of consumption of services</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		
		<div class="col-sm-12">
			<h3>Type of service</h3>
			<div class="form-group">
				
				<select class="form-control">
					<option>Type of service1</option>
					<option>Type of service2</option>
					<option>Type of service3</option>
					<option>Type of service4</option>
					<option>Type of service5</option>
					<option>Type of service6</option>
					<option>Type of service7</option>
					<option>Type of service8</option>
				</select>
			</div>
		</div>
		<div class="col-sm-12 padder">
			<div class="col-sm-12">
				<h3>Schedule</h3>
			</div>
			
			<div class="col-sm-6">
				<div class="form-group">
					<label>Time</label>
					<input type="time" class="form-control"  name="">
				</div>
			</div>
			<div class="col-sm-6">
				<div class="form-group">
					<label>Date</label>
					<input type="date" class="form-control"  name="" >
				</div>
			</div>
		</div>
		<div class="col-sm-12">
			<h3>Location</h3>
			<div class="form-group">
				
				<input type="text" class="form-control" placeholder="" name="" >
			</div>
		</div>
		<div class="col-sm-12">
			<h3>Price range</h3>
				<section class="range-slider">
				  <span class="rangeValues"></span>
				  <input value="500" min="500" max="50000" step="500" type="range">
				  <input value="50000" min="500" max="50000" step="500" type="range">
				</section>
		</div>
		<div class="col-sm-12">
			<h3>By stylist</h3>
			<div class="form-group">
				
				<select class="form-control">
					<option>Stylist1</option>
					<option>Stylist1</option>
					<option>Stylist1</option>
					<option>Stylist1</option>
					<option>Stylist1</option>					
					
				</select>
			</div>
		</div>
		<div class="col-sm-12">
			<h3>By room</h3>
			<div class="form-group">
				
				<select class="form-control">
					<option>Room1</option>
					<option>Room1</option>
					<option>Room1</option>
					<option>Room1</option>
					<option>Room1</option>
					
				</select>
			</div>
		</div>

		


		
		
		
		
		
		
		
		
		
		<button class="addsalonbtn">Save</button>
		

	</div>
</div>

<script type="text/javascript">
	function getVals(){
  // Get slider values
  var parent = this.parentNode;
  var slides = parent.getElementsByTagName("input");
    var slide1 = parseFloat( slides[0].value );
    var slide2 = parseFloat( slides[1].value );
  // Neither slider will clip the other, so make sure we determine which is larger
  if( slide1 > slide2 ){ var tmp = slide2; slide2 = slide1; slide1 = tmp; }
  
  var displayElement = parent.getElementsByClassName("rangeValues")[0];
      displayElement.innerHTML = "$ " + slide1 + "k - $" + slide2 + "k";
}

window.onload = function(){
  // Initialize Sliders
  var sliderSections = document.getElementsByClassName("range-slider");
      for( var x = 0; x < sliderSections.length; x++ ){
        var sliders = sliderSections[x].getElementsByTagName("input");
        for( var y = 0; y < sliders.length; y++ ){
          if( sliders[y].type ==="range" ){
            sliders[y].oninput = getVals;
            // Manually trigger event first time to display values
            sliders[y].oninput();
          }
        }
      }
}
</script>
<?php include ('footer.php');?>