<?php include('../../common/config.php');

extract($_POST);

$vide=mysqli_query($conn,"insert into likes set user_id ='".$_SESSION['user_id']."',post_id='".$id."', status='1', comment_id='$comment_id'");
 $dislikescounts=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$id."' and status='1' and comment_id='$comment_id'"));

if($vide){



    ?>
<a style="color:#065FD4;" href="javascript:;" onclick="undislikevdeo('<?php echo $id;?>','<?php echo $_SESSION['user_id'];?>','<?php echo $comment_id;?>');"><i class="fa fa-thumbs-down" aria-hidden="true"></i>
	<?php echo $dislikescounts;?> 
</a>
  

<?php /*echo '<div class="alert alert-success"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong > Added to Liked videos.</strong></div>';*/  }else{

echo '<div class="alert alert-danger"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong > Error..</strong></div>'; 

}
?>