<?php include('../../common/config.php');

  extract($_POST);

$strtotime=strtotime('now');
$stylist1=implode(',', $stylist);
$check= mysqli_query($conn,"INSERT INTO service (name, description, price, used_material, stylist, salon_id,strtotime,category_id,subcategory_id)VALUES ('$name', '$description', '$price', '$used_material', '$stylist1', '".$_SESSION['user_id']."','$strtotime','$category_id','$subcategory_id')");
 $insert_id= mysqli_insert_id($conn);

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Exitosamente .. Servicio añadido.</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="service.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 


?>