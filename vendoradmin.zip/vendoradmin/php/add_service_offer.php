<?php include('../../common/config.php');

  extract($_POST);

$strtotime=strtotime('now');

$offer_start_date1=strtotime($offer_start_date);

$offer_end_date1=strtotime($offer_end_date);

$start_date1=date('Y-m-d',$offer_start_date1);
$end_date1=date('Y-m-d',$offer_end_date1);


$check= mysqli_query($conn,"INSERT INTO promotion (salon_id, service_id, offer,strtotime,offer_start_date,offer_end_date,start_date,end_date)VALUES ('".$_SESSION['user_id']."', '$service_id', '$offer', '$strtotime','$offer_start_date1','$offer_end_date1','$start_date1','$end_date1')");
 $insert_id= mysqli_insert_id($conn);

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Exitosamente .. Oferta de servicio añadido.</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="offer_service.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 


?>