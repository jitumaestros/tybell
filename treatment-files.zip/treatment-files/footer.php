<footer>

    <div class="footer-content">

        <div class="container">

           



            <nav class="footer-menu row">

                <div class="col-sm-3">

                    <span class="heading-title">Navigation</span>

                    <div class="menu-navigation-container">

                        <ul  class="menu">

                            <li  class="menu-item "><a href="">Editor’s picks</a></li>

                            <li class="menu-item"><a href="">Don’t try this at home</a></li>

                            <li  class="menu-item "><a href="">Beauty board</a></li>

                            <li class="menu-item"><a href="">tybell</a></li>

                        </ul>

                    </div>

                </div>

                <div class="col-sm-3">

                    <span class="heading-title">Discover</span>

                    <div class="menu-discover-container">

                        <ul  class="menu">

                            <li  class="menu-item"><a href="">Hair</a></li>

                            <li class="menu-item"><a href="">Hair removal</a></li>

                            <li  class="menu-item"><a href="">Massage</a></li>

                            <li class="menu-item"><a href="">Nails</a></li>

                            <li class="menu-item"><a href="">Face</a></li>

                            <li class="menu-item"><a href="">Body</a></li>

                            <li class="menu-item"><a href="">Spa</a></li>

                            <li  class="menu-item"><a href="">tybell gift cards</a></li>

                        </ul>

                    </div>

                </div>

                <div class="col-sm-3">

                    <span class="heading-title">Company</span>

                    <div class="menu-company-container">

                        <ul id="menu-company" class="menu">

                            <li class="menu-item"><a href="">About </a></li>

                            <li  class="menu-item"><a href="">Legal</a></li>

                            <li  class="menu-item "><a href="">Disclaimer</a></li>

                        </ul>

                    </div>

                </div>

                <div class="col-sm-3">

                    <span class="heading-title">Social</span>

                    <ul class="social">

                        <li class="menu-item">

                            <a class="facebook" href="">Facebook</a>

                        </li>

                        <li class="menu-item">

                            <a class="instagram" href="">Instagram</a>

                        </li class="menu-item">

                        <li class="menu-item">

                            <a class="pinterest" href="">Pinterest</a>

                        </li>

                        <li class="menu-item">

                            <a class="twitter" href="">Twitter</a>

                        </li>

                    </ul>

                </div>

            </nav>

        </div>

    </div>



    <div class="terms-and-conditions">

        <div class="container">

            <span>© 2019 Maestros Infotech</span>

            <a class="logo" href=""></a>

            <a class="go-top" href="javascript:void(0)"></a>

        </div>

    </div>

</footer>



</body>



</html>