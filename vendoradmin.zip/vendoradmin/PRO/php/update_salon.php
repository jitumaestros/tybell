<?php include('../../../common/config.php');
extract($_POST);

$strtotime=strtotime('now');



if($_FILES['images']['name']){
$r= mt_rand();
$filess = "";


foreach ($_FILES['images']['name'] as $key => $value) {

 
  $file_name=str_replace(' ', '_', $_FILES["images"]["name"][$key]);
  $filess .= $file_name.",";
      
                $file_tmp=$_FILES["images"]["tmp_name"][$key];
  move_uploaded_file($file_tmp, "../../../image/".$file_name);


}
}

/*$filessa = substr($filess,0,-1);

if(!empty($_FILES['images']['name'])){
$check= mysqli_query($conn,"update users set business_name='$business_name', prime_type='$prime_type', adress='".$adress."',latitude='$latitude',longitude='$longitude',postcode='$postcode',country='$country',salon_pic='$filessa' where id='".$_SESSION['user_id']."'");

}
else{
*/

if($_FILES['file']['name']){
$r= mt_rand();
$filess = "";
foreach ($_FILES['file']['name'] as $key => $value) {

 
  $file_name=str_replace(' ', '_', $_FILES["file"]["name"][$key]);
  $filess .= $file_name.",";
      
                $file_tmp=$_FILES["file"]["tmp_name"][$key];
  move_uploaded_file($file_tmp, "../../../image/".$file_name);


}
}
$filessa = substr($filess,0,-1);

if(($filessa!='')){


$check= mysqli_query($conn,"update users set business_name='$business_name', adress='".$adress."',latitude='$latitude',longitude='$longitude',postcode='$postcode',country='$country',salon_pic='$filessa' where id='".$_SESSION['user_id']."'");
}else{
$check= mysqli_query($conn,"update users set business_name='$business_name',adress='".$adress."',latitude='$latitude',longitude='$longitude',postcode='$postcode',country='$country' where id='".$_SESSION['user_id']."'");

}
/*}
*/

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Detalles del lugar editados con éxito</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="setting.php?setting=setting";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

	
}

 


?>