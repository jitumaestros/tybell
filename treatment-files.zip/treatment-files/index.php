<?php include ('header.php');
$blog=mysqli_fetch_array(mysqli_query($conn,"select * from blog_home"));
?>
<style type="text/css">
.para-span p {
    display: -webkit-box;
    max-width: 100%;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden;
    text-overflow: ellipsis;
          font-size: 16px;
    max-height: unset !IMPORTANT;
}
span.para-span {
    height: 100px;
    overflow: hidden;
    display: block;
}
</style>
<div class="top_div">
	<div class="container">
		<div class="blog_cocntainer">
			<div class="top-article ">

			    <div class="top-article ">
			        <a href="">
			            <div class="article-image ">
			                <div class="page-title-top editors-pick">
			                    <div class="post_category_name">Editor's picks</div>
			                </div>
			                <div class="thumbnail_landscape"><img alt=""  src="../image/<?php echo $blog['image'];?>"></div>
			               
			            </div>
			            <div class="light-gray-box">
			                <span class="title"><?php echo $blog['title'];?></span>
			                <span class="date"><i><?php echo date('d-m-Y',$blog['dates']);?></i></span>
			                <span class="para-span"><p class="is-truncated" style="overflow-wrap: break-word;"><?php echo $blog['description'];?> </p></span>
			                <a href="blog_deatils.php?id=<?php echo $blog['id'];?>"><span class="read-more">Leer más</span>
			            </div>
			        </a>
			    </div>
			</div>
		</div>
	</div>
</div>


<div class="blog_container_blog">
	<div class="container">
		<div class="blog_sectuion">
			<?php $sqliii=mysqli_query($conn,"select * from publication");
			while($pub=mysqli_fetch_array($sqliii)){

			?>
			<div class="col-sm-4">
				<div class="article-item item_default">
	                <div class="blog_thumb" style="min-height: 360px;">
	                    <div class="page-title-top editors-pick">
	                        <div class="post_category_name">Editor's picks</div>
	                    </div>
	                    <img src="../image/<?php echo $pub['image'];?>">
	                 </div>
	                <div class="article-content dotdot">
	                    <span class="title"><?php echo $pub['title'];?></span>
	                    <span class="date"><i><?php echo date('d-m-Y',$pub['dates']);?></i></span>
	                  <span class="para-span"> <p class="is-truncated" style="overflow-wrap: break-word;"><?php echo $pub['description'];?> </p></span> 
			                <a href="blog_deatils.php?id=<?php echo $pub['id'];?>"><span class="read-more">Leer más</span>
	                </div>
	            </div>
			</div>
			<?php }?>

		</div>
	</div>
</div>
<?php include ('footer.php');?>