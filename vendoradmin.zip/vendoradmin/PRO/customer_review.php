<?php include ('header.php');
$feedbckcnt=mysqli_num_rows(mysqli_query($conn,"select * from feedback where salon_id='".$_SESSION['user_id']."'"));

  $rating = mysqli_fetch_array(mysqli_query($conn,"SELECT  AVG(rating) as rating FROM feedback where salon_id='".$_SESSION['user_id']."' "));

   $reviewss= (float)$rating['rating'].''; 

if($feedbckcnt=='0'){
?>

<div class="customer_review_main">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="customer_review_block">
					<div class="customer_inner">
						<img src="img/cust_review.jpg" class="cmg">
						<h2>No hay comentarios todavía</h2>	
						<p> Los lugares con 10 o más críticas positivas tienden a vender 5 veces más reservas, por lo que le hemos dado 10 correos electrónicos de revisión para enviar a sus clientes existentes para ayudarlo a obtener esas primeras críticas.<a href="#">
						Aprende más </a> </p>

						<button class="btn_get"  data-toggle="modal" data-target="#myModal"> Obtenga más reseñas</button>
					</div>

				</div>
			</div>
		</div>
	</div>
</div>
<?php }else{?>

<div class="customerreview">
  <div class="cutomerblog">
    <div class="stafreview">

      <div class="stafreive">
        <h1><?php echo round($reviewss,'1');?> </h1>
        <ul>
        <?php 
          $userdd=explode('.',round($reviewss,'1'));

             $seekerdid=$userdd[0];

             $schedid=$userdd[1];

             for($i=0;$i<$seekerdid; $i++){


              echo '<li><i class="fa fa-star"></i></li>';

            }    
            if($schedid!=''){
              echo '<i class="fa fa-star-half-o" aria-hidden="true" style="color:#CFB973;font-size:25px;"></i>&nbsp;';
            }?>
        </ul>
      </div>
        
        <p>Basado en <?php echo $feedbckcnt;?> opiniones <a href="Javascript:;" data-toggle="modal" data-target="#myModal"> Obtenga más reseñas</a></p>
    </div>
    <?php $sqlii=mysqli_query($conn,"select * from feedback where salon_id='".$_SESSION['user_id']."'");
while($fedbcknm=mysqli_fetch_array($sqlii)){

  $users=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$fedbcknm['user_id']."'"));
  $reviews=$fedbcknm['rating'].''; 

    ?>
    <div class="stafreview">
      <div class="reiewblog">
          <div class="stafreive-2">
            <ul>
            <?PHP 
             $userdd=explode('.',$reviews);

             $seekerdid=$userdd[0];

             $schedid=$userdd[1];

             for($i=0;$i<$seekerdid; $i++){


              echo '<li><i class="fa fa-star"></i></li>';

            }    
            if($schedid!=''){
              echo '<i class="fa fa-star-half-o" aria-hidden="true" style="color:#CFB973;"></i>&nbsp;';
            }?>
          </ul>
          <p><b><?php echo $users['first_name'].' '.$users['last_name'];?></b></p>
        </div>
        
        <p><?php echo $fedbcknm['feedback'];?></p>
        <p><?php echo date('d-m-Y',$fedbcknm['strtotime']);?> <a href="">Respond</a></p>
      </div>
    </div>
    <?php }?>

  </div>
</div>
<?php }?>

<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog cust_reviw_model">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Pide tus primeras opiniones </h4>
      </div>
      <div class="modal-body">
        <p>
          Para ayudar a comenzar las cosas. Podemos alentar a sus clientes actuales a revisar su sede en Tybell. Estas revisiones aumentarán la calificación de su lugar al instante.</p>
        <p>
          Simplemente ingrese las direcciones de correo electrónico de algunos de sus clientes más leales a continuación y haga clic.<a href="#">Enviar </a>
        </p>
        <?php $emailcounts=mysqli_num_rows(mysqli_query($conn,"select * from feedbackemail where salon_id ='".$_SESSION['user_id']."'"));
$reviewscouts='10'-$emailcounts;
        ?>
        <h4>Te quedan <?php if($emailcounts >0){  echo $reviewscouts;}else {echo "10";}?> correos electrónicos de solicitud </h4>
<form method="post" id="sendemail">
        <input type="hidden" name="ids" value="<?php echo $_SESSION['user_id']; ?>">


        <div class="form-group">
          <div class="col-sm-2">
            <label> Email</label>
          </div>
          <div class="col-sm-8">
            <select type="text" name="email" class="form-control" required="required">
            <option value="">All emails in the list</option>
            <?php $sqliid=mysqli_query($conn,"select * from users where role='0'");
while($usnm=mysqli_fetch_array($sqliid)){
            ?>
            <option value="<?php echo $usnm['email'];?>"><?php echo $usnm['email'];?></option>
            <?php }?>
            </select>
          </div>

          <div class="col-sm-2">
            <button class="btn btn-send"  name="submit" type="submit"> Enviar</button>
          </div>
        </div>


      </div>  
      <div class="modal-footer">
        <button type="button" class="btn cancel" data-dismiss="modal">Cancelar</button>
      </div>
      </form>

      <div id="datart"></div>

    </div>

  </div>
</div>

<?php include ('footer.php');?>
<script>

$(document).ready(function (addsendeail) {
 $("#sendemail").on('submit',(function(addsendeail) {
  $("#form_abc1_img").show();
  addsendeail.preventDefault();
  $.ajax({
   url: "php/feedbackemail.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});
</script>
