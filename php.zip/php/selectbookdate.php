<?php include('../common/config.php');

extract($_POST);
if($staffid==''){
	echo '<div class="alert alert-danger"  style="">
	<button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
	<strong >Por favor seleccione el personal </strong></div>';

}elseif(($bookdate=='') or ($open_time=='')){
	echo '<div class="alert alert-danger"  style="">
	<button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
	<strong >Por favor seleccione el horario </strong></div>';

}else{

	echo $_SESSION['book_date']=$bookdate;
	echo "<br>";
	echo $_SESSION['book_time']=$open_time;

	echo $_SESSION['staffid']=$staffid;
	echo "<script>window.location='checkout_2.php?salon_id=$salon_id&id=$service_lavel';</script>";
}
?>