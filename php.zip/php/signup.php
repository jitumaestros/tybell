<?php include('../common/config.php');

  extract($_POST);

  $select = mysqli_query($conn,"SELECT * FROM users where email='$email'");
 $checkuser= mysqli_num_rows($select);

if ($checkuser >0) {
	echo '<div class="col-sm-12"><div class="alert alert-danger ">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    Email  Already Registered
  </div></div>';
}
else{



 $check= mysqli_query($conn,"INSERT INTO users (first_name, last_name, email, password, gender, postcode,contact_number)VALUES ('$fname', '$lname', '$email', '$password', '$gender', '$post','$contact_number')");
 $insert_id= mysqli_insert_id($conn);
$_SESSION['user_id']=$insert_id;
 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Registration successfully..</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="myaccount.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 }


?>