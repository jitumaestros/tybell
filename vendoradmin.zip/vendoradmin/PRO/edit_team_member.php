<?php include ('header.php');
$edit=mysqli_fetch_array(mysqli_query($conn,"select * from staff where id='".$_GET['id']."'"));
?>
  <div class="team_member_from">
		<div class="">  			
			<div class="team_wrapper">
				<div class="tem_add_title">
					Team Member
				</div>
				<form method="post" id="addteamem" enctype="multipart/form-data">
				<input type="hidden" name="ids" value="<?php echo $_GET['id'];?>">
				<div id="getpermiss"></div>

				<div class="col-sm-6">
					<div class="top_team">
						
							<div class="left_tem_img">
								<div class="img_blog_team">
									<img src="../img/<?php echo $edit['profile_pic_path'];?>" id="blah">
									<input type="file" class="choose" name="image" id="imgInp" >
								</div>
							</div>
							<div class="form_div_blog1">
								<div class="form-group add-team-input">
									<input type="text" class="form-control" placeholder="First and last name" name="name"  required="required" value="<?php echo $edit['name'];?>">
								
										<input type="checkbox" name=""> &nbsp; Provides treatments & services
									
									
								</div>
							</div>
							
					</div>
					<div class="team_from_add">
						<div class="form-group">
							<label><i>Pricing Level</i></label>
							<select class="form-control" name="pricing_level">
								<option value="Default">Default</option>
							</select>
						</div>
						<div class="form-group">
							<label><i>Job title</i></label>
							<input type="text" class="form-control" name="job_title" value="<?php echo $edit['job_title'];?>" required="required">'
						</div>
						<div class="form-group">
							<label><i>Phone</i></label>
							<input type="number" class="form-control" name="mobile"  required="required" value="<?php echo $edit['mobile'];?>">
						</div>
						<div class="form-group">
							<label><i>Gender</i></label>
							<select class="form-control" name="gender">
							<option value="<?php echo $edit['gender'];?>"><?php echo $edit['gender'];?></option>
							<option value="Male">Male</option>
							<option value="FeMale">FeMale</option>

								<option value="Other / prefer not to disclose">Other / prefer not to disclose</option>
							</select>
						</div>
						<div class="form-group">
							<label>Email Address</label>
							<input type="text" class="form-control" name="email" value="<?php echo $edit['email'];?>">
								<div class="ckechoinpu">
							<input type="checkbox" name="status" value="1" <?php if($edit['status']=='1'){ echo "checked";} ?>> &nbsp; Can log in to Dala3 Connect</div>
						</div>
						<div class="form-group">
							<label><i>Permissions</i></label>
							<select class="form-control" name="permissions">
							<option value="<?php echo $edit['permissions'];?>"><?php echo $edit['permissions'];?></option>
								<option value="Stylist/Therapist">Stylist/Therapist</option>
								<option value="Custom">Custom</option>
								<option value="Owner">Owner</option>

							</select>
							<a href="javascript:;" class="ckechoinpu" data-toggle="modal" data-target="#Customise11">Customise Permissions</a>
						</div>
					</div>
					<div class="baout_team">
						<div class="form-group">
							<label><i>About</i></label>
							<textarea class="form-control" cols="4" rows="4" name="about"><?php echo $edit['about'];?></textarea>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="right_option_blog">
						<div class="right_copunt-blog2">
							<div class="form-group">
								<p><b>What services can be booked for this employee online?</b></p>
								<input type="checkbox" name="" value="" onclick="allchecked('1');"> &nbsp;All services
							</div>

					<?php $r = rand();
									$stffc=$edit['category_id'];

							 $sqlii=mysqli_query($conn,"select * from category");
							while($catnm=mysqli_fetch_array($sqlii)){
 $dfgdfjc = explode(",", $stffc);
                $selz = ''; 
             for ($i=0; $i < count($dfgdfjc); $i++) { 
             	if($catnm['id']==$dfgdfjc[$i]){ $selz = 'checked'; $i = count($dfgdfjc);}
             }


							?>
							<div class="form-group">
								<p><b><input type="checkbox" style="opacity: 0;" name="category_id[]" value="<?php echo $catnm['id']?>" class="checkboxall checkboxalldm<?php echo $catnm['id'];?>"  <?php echo $selz;?>><?php echo $catnm['name']?></b> 

								&nbsp;&nbsp; <a href="javascript:;" class="checkboxall" onclick="checkedinside('<?php echo $catnm['id'];?>');">Selectall</a> &nbsp;&nbsp; <a href="javascript:;" class="checkboxall"  onclick="uncheckedinside('<?php echo $catnm['id'];?>');" >Deselectall</a></p>

								<?php $sub=mysqli_query($conn,"select * from subcategory where category_id='".$catnm['id']."'");
									$stff=$edit['subcategory_id'];

							while($subnm=mysqli_fetch_array($sub)){
        
            $dfgdfj = explode(",", $stff);
                $sel = ''; 
             for ($i=0; $i < count($dfgdfj); $i++) { 
             	if($subnm['id']==$dfgdfj[$i]){ $sel = 'checked'; $i = count($dfgdfj);}
             }


							 ?>
								<p><input type="checkbox" name="subcategory_id[]" class="checkboxall checkboxalld<?php echo $catnm['id'];?>" value="<?php echo $subnm['id'];?>"  onclick="checkedinsidecat('<?php echo $catnm['id'];?>');"  <?php echo $sel;?>> &nbsp;<?php echo $subnm['name'];?></p>

								<?php }?>
								
							</div>
							<?php }?>
						
						</div>

					</div>
					<button  class="save_btn" name="submit" type="submit" style="background:#6BBE4A; border:1px solid #6BBE4A;color: #fff;">Save</button>

				</div>
				<div id="getdata"></div>
				</form>
			</div>
		</div>
  </div>
  <!-- Modal -->


  <div class="modal fade" id="Customise11" role="dialog" >
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-body1 overflow-h">
        	<div class="tem_add_title">
					Team Member
			</div>
        	 <div class="right_option_blog1">
        	 <form method="post" id="addpermi" enctype="multipart/form-data">
        	 	<div class="col-sm-6">
        	 		<div class="right_copunt-blog2">
        	 <?php 
        	  $gen1=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='View list of bookings'"));
                  
        	 $gen2=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Manage venue details'"));
        	  $gen3=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='View Finance deatils'"));
                  
        	 $gen4=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='View Sales report'"));
        	  $gen5=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Can refound transactions'"));
                  
        	 $gen6=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Can edit service prices in checkout'"));
        	  
           $menu1=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='View menu'"));
                  
        	 $menu2=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Edit menu'"));
        	  
  
           $clients1=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='View Clinet list'"));
                  
        	 $clients2=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='View/ edit client contact details'"));


        	  $calendar1=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Manage own calendar'"));
                  
        	 $calendar2=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='View Others calendar'"));

        	  $calendar3=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Manage Others calendar'"));
                  
        	 $calendar4=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Can delete appointments'"));

           
 $hotl1=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Manage Spa Day inventory'"));

        	  $hotl2=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Manage Overnight inventory'"));
                  

        	 $staff1=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Add therapists'"));
                  
        	 		$staff2=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='".$_GET['id']."' and name='Change user permissions'"));
        	 		?>
						
						<div class="form-group">
							<p><b>General</b></p>
							<p><input type="checkbox" name="name[]" value="View list of bookings" <?php if($gen1 >0){echo "Checked";}?>> &nbsp;View list of bookings</p>
							<p><input type="checkbox" name="name[]" value="Manage venue details" <?php if($gen2 >0){echo "Checked";}?>> &nbsp;Manage venue details</p>
							<p><input type="checkbox" name="name[]" value="View Finance deatils" <?php if($gen3 >0){echo "Checked";}?>> &nbsp;View Finance deatils</p>
							<p><input type="checkbox" name="name[]" value="View Sales report" <?php if($gen4 >0){echo "Checked";}?>> &nbsp;View Sales report</p>
							<p><input type="checkbox" name="name[]" value="Can refound transactions" <?php if($gen5 >0){echo "Checked";}?>> &nbsp;Can refound transactions</p>
							<p><input type="checkbox" name="name[]" value="Can edit service prices in checkout" <?php if($gen6 >0){echo "Checked";}?>> &nbsp;Can edit service prices in checkout</p>
						</div>
						<div class="form-group">
							<p><b>Menu</b></p>
							<p><input type="checkbox" name="name[]" value="View menu" <?php if($menu1 >0){echo "Checked";}?>> &nbsp;View menu</p>
							<p><input type="checkbox" name="name[]" value="Edit menu" <?php if($menu2 >0){echo "Checked";}?>> &nbsp;Edit menu</p>
							
						</div>
						<div class="form-group">
							<p><b>Clients</b></p>
							<p><input type="checkbox" name="name[]" value="View Clinet list" <?php if($clients1 >0){echo "Checked";}?>> &nbsp;View Clinet list</p>
							<p><input type="checkbox" name="name[]"  value="View/ edit client contact details" <?php if($clients2 >0){echo "Checked";}?>> &nbsp;View/ edit client contact details</p>
							
						</div>
						
						
					</div>
        	 	</div>
				<div class="col-sm-6">
					<div class="right_copunt-blog2">
						
						<div class="form-group">
							<p><b>Calendar</b></p>
							<p><input type="checkbox" name="name[]"  value="Manage own calendar" <?php if($calendar1 >0){echo "Checked";}?>> &nbsp;Manage own calendar</p>
							<p><input type="checkbox" name="name[]"  value="View Others calendar" <?php if($calendar2 >0){echo "Checked";}?>> &nbsp;View Others' calendar</p>
							<p><input type="checkbox" name="name[]"  value="Manage Others calendar" <?php if($calendar3 >0){echo "Checked";}?>> &nbsp;Manage Others' calendar</p>
							<p><input type="checkbox" name="name[]"  value="Can delete appointments" <?php if($calendar4 >0){echo "Checked";}?>> &nbsp;Can delete appointments</p>
							
						</div>
						<div class="form-group">
							<p><b>Hotel/Spa</b></p>
							<p><input type="checkbox" name="name[]"  value="Manage Spa Day inventory"  <?php if($hotl1 >0){echo "Checked";}?>> &nbsp;Manage Spa Day inventory</p>
							<p><input type="checkbox" name="name[]"  value="Manage Overnight inventory"  <?php if($hotl2 >0){echo "Checked";}?>> &nbsp;Manage Overnight inventory</p>					
						</div>
						<div class="form-group">
							<p><b>Staff</b></p>
							<p><input type="checkbox" name="name[]"  value="Add therapists" <?php if($staff1 >0){echo "Checked";}?>>  &nbsp;Add therapists</p>
							<p><input type="checkbox" name="name[]"  value="Change user permissions" <?php if($staff2 >0){echo "Checked";}?>> &nbsp;Change user permissions</p>
							
						</div>
						
						
					</div>
				</div>
			</div>
			 <div class="col-sm-12 padder">
	        	<div class="modal-footer">
	        		 	<button  class="save_btn" name="submit" type="submit"  style="background:#6BBE4A; border:1px solid #6BBE4A;color: #fff;" >Save</button>

		          	<button class="save_btn" style="background: #FFFFFF; border:1px solid #ddd;color: #333;" data-dismiss="modal">Close</button> 
		         
		        </div>
	        </div>
	        </form>
        </div>
       
      </div>
      
    </div>
  </div>
  
<?php include ('footer.php');?>

<script type="text/javascript">

$(document).ready(function(){

    $("#clickchecks").click(function(){

     if (!$(this).is(':checked')) {

        $(".checkboxall").prop('checked', false);

        
    }else{
      $(".checkboxall").prop('checked', true);
      
  }
})


})
function checkedinside(id){
    
  $(".checkboxalld"+id).prop('checked', true);
    $(".checkboxall"+id).prop('checked', true);

      $(".checkboxalldm"+id).prop('checked', true);

}


function uncheckedinside(id){    
  $(".checkboxalld"+id).prop('checked', false);
      $(".checkboxall"+id).prop('checked', false);
          $(".checkboxalldm"+id).prop('checked', false);


}
function checkedinsidecat(id){
    
    $(".checkboxalldm"+id).prop('checked', true);

  
}

function allchecked(id){
    
    $(".checkboxall").prop('checked', true);

  
}



</script>

<script type="text/javascript">
	

$(document).ready(function (addseroffr) {
 $("#addpermi").on('submit',(function(addseroffr) {
 	   //	alert();

  $("#form_abc1_img").show();
  addseroffr.preventDefault();
  $.ajax({
   url: "php/addperission.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   //	alert(data);

     $("#form_abc1_img").hide();
   $("#getpermiss").show().html(data);


          $('#Customise11').removeClass('in');
                $('#Customise11').attr("aria-hidden","true");
                $('#Customise11').css("display", "none");
                $('.modal-backdrop').remove();
                $('body').removeClass('modal-open');

      },
     error: function(){}          
    });

 }));
});




$(document).ready(function (addteam) {
 $("#addteamem").on('submit',(function(addteam) {
 	   	//alert();

  $("#form_abc1_img").show();
  addteam.preventDefault();
  $.ajax({
   url: "php/edit_team_member.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
  // 	alert(data);
     $("#form_abc1_img").hide();
   $("#getdata").show().html(data);
      },
     error: function(){}          
    });

 }));
});

</script><script type="text/javascript">
   function readURL(input)
   {
      if (input.files && input.files[0]) {
       var reader = new FileReader();
       reader.onload = function(e) {
          $('#blah').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
   }
   }
   
   $("#imgInp").change(function() {
   readURL(this);
   });
   
   
</script>