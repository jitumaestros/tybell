<?php include('../../common/config.php');
extract($_POST);

$catnm=mysqli_fetch_array(mysqli_query($conn,"select * from category where id='".$id."'"));
?>
<div class="modal fade" id="myModalsd" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
       <form method="post" id="editcategory">

        <div class="modal-body padder">
        	
        	<div class="model-body-content">
        		<div class="form-group">
        			<label>Edit Menu group name</label>
        			<input type="hidden" name="service" value="service">
        			<input type="hidden" name="ids" value="<?php echo $catnm['id'];?>">

        			<input type="text" class="form-control" name="name" required="required" value="<?php echo $catnm['name'];?>">
        		</div>
        	</div>
        </div>
        <div class="modal-footer myfooer-2">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button class="save-btn pull-right" name="submit" tybe="submit">Save</button>
          <div id="datartf"></div>
        </div>
        </form>
      </div>
      
    </div>
  </div>
  <script type="text/javascript">
    
  $(document).ready(function (actsdct) {

    $("#editcategory").on('submit',(function(actsdct) {
      $("#form_abc1_img").show();
    
      actsdct.preventDefault();
      $.ajax({
        url: "php/editcategory.php",
        type: "POST",
        data:  new FormData(this),
        contentType: false,
        cache: false,
        processData:false,
        success: function(data){
    
      $("#form_abc1_img").hide();
      $("#datartf").show().html(data);
    },
    error: function(){}          
  });
    }));
  });


  </script>