<!DOCTYPE html>
<html lang="en">
<head>
  <title>Tybell</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>
<style type="text/css">
  body{
    font-family: MuseoSansR;
  }
  .login_page-wrapper {
    width: 400px;
    margin: 0 auto;

}
.login_page-blog {
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}
.input-box{
  
}
.input-box .form-control {
    background: transparent;
    border: 0;
    border-radius: 0px;
    box-shadow: none;
    border-bottom: 1px solid #E23669;
    height: unset;
    padding: 15px 0;
    font-size: 18px;
    color: #fff;
}
.input-box .form-control::placeholder{
  color: #fff;
}
@font-face {
  font-family: MuseoSansR;
  src: url('MuseoSans/MuseoSans_300[2].otf');
}
.login_page-wrapper {
    width: 500px;
    margin: 0 auto;
  /*  background: rgba(0, 0, 0, 0.52);
    padding: 35px 35px;
    box-shadow: 1px 1px 26px rgba(194, 190, 190, 0.35);*/
    border-radius: 20px;
}
.lgo-img {
    width: 100%;
    max-width: 140px;
    margin: 0 auto;
    display: block;
    margin-bottom: 25px;
}
.submit-btn {
    background: linear-gradient(#f087a6, #841941);
    border: 0;
    color: #fff;
    margin: 15px auto;
    display: block;
    padding: 11px 35px;
    font-size: 18px;
    width: 100%;
    margin-bottom: 0;
    margin-top: 30px;
    transition: 0.5s;
    border-radius: 29px;
    outline: none;
    transition: 0.3s;
}
 .submit-btn:hover{
 background: linear-gradient(#E43669, #f087a6);
  color: #fff;
 }
 .input-box .form-control {
    background: transparent;
    border: 0;
    border-radius: 0px;
    box-shadow: none;
    border-bottom: 0px solid #E23669;
    height: unset;
    padding: 15px 24px;
    font-size: 18px;
    color: #fff;
    box-shadow: inset 8px 10px 35px #cfc3c3;
    border-radius: 47px;
}
</style>
<body style="background: url(img/loginbackground.jpeg) ;background-size: cover;">
<div class="login_page-blog">
  <div class="container">

  <div class="login_page-wrapper">
    <img src="img/logo.png" class="lgo-img">
    <div class="form-group input-box">
     
      <input type="email" class="form-control" id="email" placeholder="Email" name="email">
    </div>
    <div class="form-group input-box">
      
      <input type="password" class="form-control" id="pwd" placeholder="Password" name="pwd">
    </div>
    <div class="checkbox">
      <label style="color: #fff;"><input type="checkbox" name="remember"> Remember me</label>
    </div>
    <button type="submit" class="btn submit-btn">Submit</button>
  </div>
    

</div>
</div>


</body>
</html>
