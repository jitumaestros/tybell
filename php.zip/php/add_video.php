<?php include('../common/config.php');
extract($_POST);

$image=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], "../image/".$image);
mysqli_query($conn,"insert into videos set video ='$image'");
?>

 