<?php include ('header.php');
$totalsamnts='';
 $mnt=date('m');
$slnq=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and month='$mnt' "); 
while($rows=mysqli_fetch_array($slnq)){

$user_id=$rows['user_id'];
$usercount=mysqli_num_rows(mysqli_query($conn,"select * from bookings where user_id='".$rows['user_id']."'"));

$financ1=mysqli_fetch_array(mysqli_query($conn,"select * from financial_balance where id='1'"));

$financ2=mysqli_fetch_array(mysqli_query($conn,"select * from financial_balance where id='2'"));

if($usercount=='1'){
$fee=$financ1['fee'];

}else{
$fee=$financ2['fee'];

} 

   $totals=$rows['total_amount']*$fee/100;

     $totalsamntd=$rows['total_amount']-$totals;

if($rows['payment_status']=='1'){ 
	 $totals1=$totals;

}

if($rows['payment_status']=='0'){ 

	 $prices=$totalsamntd;

}
$totalsamnts =$prices-$totals1;
}
?>
	<div class="finance_wrapper">
		<div class="finanace_blog">
			<h1>Balance del Mes: +<?php echo $totalsamnts; ?></h1>
			<table class="table  table-bordered table-hover">
				<thead>
					<tr>
						<th>Reserva</th>
						<th>Fecha</th>
						<th>Monto cobrado</th>
						<th>Fee %</th>
						<th>Medio de Pago</th>
						<th>Fee Tybell</th>
						<th>Ingreso Salon</th>
						<th>Balance</th>
					</tr>
				</thead>
				<tbody>
				<?php $mnt=date('m');
				 $slnq=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and month='$mnt' "); 
				while($rows=mysqli_fetch_array($slnq)){

$user_id=$rows['user_id'];
$usercount=mysqli_num_rows(mysqli_query($conn,"select * from bookings where user_id='".$rows['user_id']."'"));

/*$financ1=mysqli_fetch_array(mysqli_query($conn,"select * from financial_balance where id='1'"));

$financ2=mysqli_fetch_array(mysqli_query($conn,"select * from financial_balance where id='2'"));

if($usercount=='1'){
$fee=$financ1['fee'];

}else{
$fee=$financ2['fee'];

} */


$financ1=mysqli_fetch_array(mysqli_query($conn,"select * from financial_balance where salon_id='".$_SESSION['user_id']."' and title='1'"));

$financ2=mysqli_fetch_array(mysqli_query($conn,"select * from financial_balance where salon_id='".$_SESSION['user_id']."' and title='2'"));

if($usercount=='1'){
$fee=$financ1['fee'];

}else{
$fee=$financ2['fee'];

} 

   $totals=$rows['total_amount']*$fee/100;
    $totalsamnt=$rows['total_amount']-$totals;

?>
					<tr>
						<td><?php echo $rows['order_ref'];?></td>
						<td><?php echo $rows['schedule_date'];?></td>
						<td>$<?php echo $rows['total_amount'];?></td>
						<td><?php echo $fee;?>%</td>
						<td><?php if($rows['payment_status']=='1'){ echo "CASH";}else{echo "CREDIT/DEBIT CARD";}?></td>
						<td><?php echo $totals;?></td>
						<td><?php if($rows['payment_status']=='1'){ echo $rows['total_amount'];}else{echo "-";}?></td>
						<td><?php if($rows['payment_status']=='1'){ echo '-'.$totals;}else{echo $totalsamnt;}?></td>
					</tr>
					<?php }?>
				</tbody>
			</table>
		</div>
	</div>
<?php include ('footer.php');?>