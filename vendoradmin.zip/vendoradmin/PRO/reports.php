<?php include ('header.php');
    $totalbook=mysqli_num_rows(mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and booking_status!='2'"));
    $totalpric='';

    $dddd=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and booking_status!='2'");
    while($totalpricef=mysqli_fetch_array($dddd)){
    $totalpric +=$totalpricef['total_amount'];

    }

    $img=explode('.', $users['salon_pic']);

    $feedbckcnt=mysqli_num_rows(mysqli_query($conn,"select * from feedback where salon_id='".$_SESSION['user_id']."'"));


    $rating = mysqli_fetch_array(mysqli_query($conn,"SELECT  AVG(rating) as rating FROM feedback where salon_id='".$_SESSION['user_id']."' "));
    echo $reviewss= (float)$rating['rating'].''; 

?>

<div class="dashboard_review_main">
	<div class="container-fluid">
		<div class="row">
			<div class="col-sm-12">
				<div class="dashboard_review_top_block">
					<div class="col-sm-12 padder">
						<div class="spa_block">
							<img src="../../image/<?php echo $img['0'];?>">
							<div class="details stafreview">
								<h3><?php echo $users['business_name'];?> </h3>
								<?php if($feedbckcnt=='0'){?>
								<p> <i class="fa fa-clock-o"></i> pending review</p>
								<?php }else{?>
                                <div class="stafreive">
                                    <h1><?php echo round($reviewss,'1');?> </h1>
                                    <ul>
                                        <?php 
                                        $userdd=explode('.',round($reviewss,'1'));

                                        $seekerdid=$userdd[0];

                                        $schedid=$userdd[1];

                                        for($i=0;$i<$seekerdid; $i++){

                                        echo '<li><i class="fa fa-star"></i></li>';

                                        }    
                                        if($schedid!=''){
                                        echo '<i class="fa fa-star-half-o" aria-hidden="true" style="color:#CFB973;font-size:25px;"></i>&nbsp;';
                                        } }?>
                                    </ul>
                                </div>
							</div>
						</div>
					</div>
				</div>
			</div>



			<div class="col-sm-12">
				<div class="col-sm-12 padder-left">
					<div class="sales_moth_block">
                        
                        <div class="dropdown cma">
                            <h2> Sales this month 
                                <button class="btn_bl dropdown-toggle" type="button" data-toggle="dropdown" id="btn_bl" onclick="mybtnl()">
                                    <i class="fa fa-angle-right"></i>
                                </button>
                            </h2>
                            <ul class="dropdown-menu " id="menshowl">
                                <li><a href="javascript:;" onclick="changedreport('1');">Reporte de ventas diarias</a></li>
                                <li><a href="javascript:;" onclick="changedreport('2');">Reporte de Ventas Mensuales</a></li>
                                <li><a href="javascript:;" onclick="changedreport('3');">Adquisición Cliente </a></li>
                                <li><a href="javascript:;" onclick="changedreport('4');">Reporte de Ventas Por Servicio </a></li>
                            </ul>
                        </div> 

                        <!-- <select onchange="changedreport(this.value);">
                            <option value="">Select</option> 
                            <option value="1">Reporte de ventas diarias </option>
                            <option value="2"> Reporte de Ventas Mensuales </option>
                            <option value="3">Adquisición Cliente </option>
                            <option value="4">Reporte de Ventas Por Servicio </option>
                        </select> -->

                        <br>
						<div class="counting ">
							<div class="details">
								<p>Total Booking</p>
								<h3><?php echo $totalbook;?></h3>
							</div>

							<div class="details">
								<p>total ttv</p>
								<h3>$ <?php echo $totalpric;?></h3>
							</div>
						</div>

                        <div id="showdis1" style="height: 0; overflow:hidden;">
    						<div class="data_flow_cahrt" >
    							<div id="chartContainer" style="height: 300px; width: 100%;"></div>
    							<div class="hide_data"> </div>
    						</div>
                        </div>

                        <div id="showdis2" style="height: 0; overflow:hidden;"> 
                            <div class="data_flow_cahrt">
                                <div id="chartContainer1" style="height: 300px; width: 100%;"></div>
                                <div class="hide_data"> </div>
                            </div>
                        </div>

                         <div id="showdis4" style="height: 0; overflow:hidden;">

                <div class="col-sm-12 ">
                    <div class="service_bock">
                    <div id="chartContainer2" style="height: 300px; width: 100%;"></div>
        
                </div>
             </div>
             </div>

					</div>
				</div>
	
				</div>
              <div class="col-sm-12" id="showdis1a" style="display: none;">
                    <div class="service_bock">
                        <h2> Services</h2>                       
                        <table class="table">
                            <tr>
                                <th>Dates </th>
                                <th>QTY</th>
                                <th>Sales</th>
                            </tr>
<?php 
$datess=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' group by schedule_date ");
 
    while($salesa=mysqli_fetch_array($datess)){

            $countss=''; 
            $countss1='';
            $sqliids=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and schedule_date='".$salesa['schedule_date']."'");
            
            while ($salesss=mysqli_fetch_array($sqliids)){

             $countss +=$salesss['total_amount'];
              
$explodes=explode(',',$salesss['service_id']);

foreach ($explodes as $key => $values) {
    $mss=mysqli_num_rows(mysqli_query($conn,"select * from service where id='$values'"));
           $countss1 +=$mss;

           }

            }
      ?>
                            <tr>
                                <td> <?php echo $salesa['schedule_date'];?>  </td>
                                <td>  <?php echo $countss1;?></td>
                                <td>  $ <?php echo $countss;?></td>
                            </tr>
                            <?php }?>

                        </table>
                    </div>
               </div>
                        
              <div class="col-sm-12 " id="showdis2a" style="display: none" >
                    <div class="service_bock">
                        <table class="table">
                            <tr>
                                <th>Month   </th>
                                <th>QTY</th>
                                <th>Sales   </th>
                            </tr>
<?php 
$datess1=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' group by month ");
 
    while($salesa1=mysqli_fetch_array($datess1)){

            $countss1=''; 
            $countss11='';
            $sqliids1=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and month='".$salesa1['month']."'");
            
            while ($salesss1=mysqli_fetch_array($sqliids1)){

             $countss1 +=$salesss1['total_amount'];
              
$explodes1=explode(',',$salesss1['service_id']);

foreach ($explodes1 as $key => $values1) {
    $mss1=mysqli_num_rows(mysqli_query($conn,"select * from service where id='$values1'"));
           $countss11 +=$mss1;

           }

            }

             $ndate1=strtotime($salesa1['schedule_date']);
            $day1=date('d',$ndate1);

            $month1=date('m',$ndate1);

            $year1=date('Y',$ndate1);

            $fnal1=$year1.'-'.$month1.'-'.$day1;
            $ff=strtotime($fnal1);
            $fnlk1=date('M',$ff);
      ?>
                            <tr>
                                <td> <?php echo $fnlk1;?>  </td>
                                <td>  <?php echo $countss11;?></td>
                                <td>  $ <?php echo $countss1;?></td>
                            </tr>
                            <?php }?>

                        </table>
                    </div>
               </div>

                       


          <div class="col-sm-12 " id="showdis4a" style="display: none;">
                    <div class="service_bock">
                        <table class="table">
                            <tr>
                                <th>Service   </th>
                                <th>QTY</th>
                                <th>Sales   </th>
                            </tr>
<?php 
$sqliis=mysqli_query($conn,"select * from requested_service where salon_id='".$_SESSION['user_id']."' group by service_id");

while($reservice=mysqli_fetch_array($sqliis)){
$countss2='';
    $servicecount=mysqli_num_rows(mysqli_query($conn,"select * from requested_service where service_id='".$reservice['service_id']."'")); 

    $service=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$reservice['service_id']."'"));

 $sqliida2=mysqli_query($conn,"select * from requested_service where salon_id='".$_SESSION['user_id']."' and service_id='".$reservice['service_id']."'");
            
            while ($saless2d=mysqli_fetch_array($sqliida2)){

        $servicesss=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$saless2d['service_id']."'"));


                $countss2+=$servicesss['price'];

            }
            ?>
                            <tr>
                                <td>  <?php echo $service['name'];?> </td>
                                <td> <?php echo $servicecount;?></td>
                                <td> $ <?php echo $countss2;?></td>
                            </tr>
                            <?php }?>

                        </table>
                    </div>
               </div>

			</div>
		</div>
	</div>
</div>

<?php include ('footer.php');?>
<?php 
$dates=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' group by schedule_date ");

$dates1=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' group by month ");

$dates2=mysqli_query($conn,"select * from  requested_service where salon_id='".$_SESSION['user_id']."' group by service_id ");


?>

<script type="text/javascript">
window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
    {
      title:{
        text: "Daily Sales Report"
    },
    axisX:{
        title: "timeline",
    },
    axisY: {
        title: "Downloads"
    },
    data: [
    {        
        type: "line",
        dataPoints: [

        <?php 
          while($sales=mysqli_fetch_array($dates)){

            $countss='';

            $sqliid=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and schedule_date='".$sales['schedule_date']."'");
            
            while ($saless=mysqli_fetch_array($sqliid)){

                $countss +=$saless['total_amount'];

            }

     $ndate=strtotime($sales['schedule_date']);
            $day=date('d',$ndate);

            $month=date('m',$ndate);

            $year=date('Y',$ndate);

            $fnal=$year.'-'.$month.'-'.$day;
            $fnlk=date('M',$ndate);

            ?>
            //array
            { label: "<?php echo $fnal;?>",  y: <?php echo $countss;?>  },
        
        <?php }?>

        ]
    }
    ]
});

 chart.render();


var chart = new CanvasJS.Chart("chartContainer1",
    {
      title:{
        text: "Monthly Sales Report"
    },
    axisX:{
        title: "timeline",
    },
    axisY: {
        title: "Downloads"
    },
    data: [
    {        
        type: "line",
        dataPoints: [

        <?php 
          while($sales1=mysqli_fetch_array($dates1)){

            $countss1='';
            $sqliid1=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and month='".$sales1['month']."'");
            
            while ($saless1=mysqli_fetch_array($sqliid1)){

                $countss1 +=$saless1['total_amount'];

            }

     $ndate1=strtotime($sales1['schedule_date']);
            $day1=date('d',$ndate1);

            $month1=date('m',$ndate1);

            $year1=date('Y',$ndate1);

            $fnal1=$year1.'-'.$month1.'-'.$day1;
            $ff=strtotime($fnal1);
            $fnlk1=date('M',$ff);

            ?>
            //array
            { label: "<?php echo $fnlk1;?>",  y: <?php echo $countss1;?>  },
        
        <?php }?>

        ]
    }
    ]
});

 chart.render();



var chart = new CanvasJS.Chart("chartContainer2",
    {
      title:{
        text: "Sales Report by Service"
    },
    axisX:{
        title: "timeline",
    },
    axisY: {
        title: "Downloads"
    },
    data: [
    {        
        type: "line",
        dataPoints: [

        <?php 
          while($sales2=mysqli_fetch_array($dates2)){

            $countss2='';

        $service=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$sales2['service_id']."'"));

            $sqliid2=mysqli_query($conn,"select * from requested_service where salon_id='".$_SESSION['user_id']."' and service_id='".$sales2['service_id']."'");
            
            while ($saless2=mysqli_fetch_array($sqliid2)){

        $services=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$saless2['service_id']."'"));


                $countss2+=$services['price'];

            }

    

            ?>
            //array
            { label: "<?php echo $service['name'];?>",  y: <?php echo $countss2;?>  },
        
        <?php }?>

        ]
    }
    ]
});

 chart.render();
 

}
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</head>
<body>
<!-- <div id="chartContainer" style="height: 300px; width: 100%;">
</div> -->


<script type="text/javascript">
    
 
/*$(document).ready(function(){
  $("#btn_bl").click(function(){
    $("#menshowl").toggle();
    $("#menshowl").css("display","block");
    alert();
  });
});*/

function mybtnl() {
  var x = document.getElementById("menshowl");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}







</script>
<style type="text/css">
	.dashboard_review_main .service_bock table th {
    text-transform: uppercase;
    color: #9E9E9E;
    font-weight: 400;
    font-size: 14px;
    background: #F2F3F2;
    color: black;
}
</style>

<script type="text/javascript">
    function changedreport(id){

if(id=='1'){
    
             $("#showdis1a").show();
              $("#showdis1").css("height","300px");
              $("#showdis2").css("height","0px");
              $("#showdis3").css("height","0px");
              $("#showdis4").css("height","0px");

            $("#showdis2a").show(hide);

            $("#showdis3a").hide();
            $("#showdis4a").hide();


    }
    else if(id=='2'){
       
            $("#showdis2a").show();
            $("#showdis1a").hide();
            $("#showdis3a").hide();
            $("#showdis4a").hide();

            /*$("#showdis2").css("height","300px");
            $("#showdis2").css("display","block");
            $("#showdis1").hide();
            $("#showdis3").hide();
            $("#showdis4").hide();*/

            $("#showdis1").css("height","00px");
            $("#showdis2").css("height","300px");
            $("#showdis3").css("height","0px");
            $("#showdis4").css("height","0px");


    }
    else if(id=='4'){

        $("#showdis1").css("height","00px");
            $("#showdis2").css("height","0px");
            $("#showdis3").css("height","0px");
            $("#showdis4").css("height","300px");

              $("#showdis4a").show();
             $("#showdis2a").hide();
               $("#showdis1a").hide();
            $("#showdis3a").hide();


    }
    else{
           $("#showdis1").css("height","00px");
            $("#showdis2").css("height","0px");
            $("#showdis3").css("height","300px");
            $("#showdis4").css("height","0px");


              $("#showdis3a").show();
           $("#showdis2a").hide();
              $("#showdis1a").hide();
              $("#showdis4a").hide();

    }

}
</script>







