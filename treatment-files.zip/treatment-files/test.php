<html>
<head>
  <title>Your Website Title</title>
    <!-- You can use Open Graph tags to customize link previews.
    Learn more: https://developers.facebook.com/docs/sharing/webmasters -->
  <meta property="og:url"           content="https://maestrosinfotech.com/Tybell/treatment-files/blog_deatils.php?id=2" />
  <meta property="og:type"          content="website" />
  <meta property="og:title"         content="dsdsdsds" />
  <meta property="og:description"   content="ddddddddddddddddddddd" />
  <meta property="og:image"         content="https://maestrosinfotech.com/Tybell/image/mum-hero.jpg" />
</head>
<body>

  <!-- Load Facebook SDK for JavaScript -->
  <div id="fb-root"></div>
  <script>(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s); js.id = id;
    js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
    fjs.parentNode.insertBefore(js, fjs);
  }(document, 'script', 'facebook-jssdk'));</script>

  <!-- Your share button code -->
  <div class="fb-share-button" 
    data-href="https://maestrosinfotech.com/Tybell/treatment-files/blog_deatils.php?id=2" 
    data-layout="button_count">
  </div>

</body>
</html>