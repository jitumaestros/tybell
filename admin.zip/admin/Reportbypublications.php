<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Blog management</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Blog management</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
				
		<div id="chartContainer" style="height: 300px; width: 100%;"></div>
	</div>
	<!-- <div class="addsalon">
				
		<div class="col-sm-12 col-md-6 col-lg-4 col-xl-3">
                <div class="thumbnail card">
                    <img src="assets/images/course-3.jpg" alt="" class="img-fluid">
                    <div class="caption  body">
                        <h3>Magento Programmer Course</h3>
                        <p>First Year, MBA</p>
                        <p>Price: <strong class="col-blush">$315.60</strong> Time: <strong class="col-green">9 months</strong></p>
                        <p>Prof.: Prof. <strong>Will Smith</strong></p>
                        <p>Students: <strong class="col-green">115</strong></p>
                        <a href="courses-info.html" class="btn  btn-raised btn-info waves-effect" role="button">Read more</a>
                    </div>
                </div>
            </div>
	</div>
	<div class="addsalon">
				
		
	</div>
	
 -->
</div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
window.onload = function() {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Report by publications"
	},
	data: [{
		type: "pie",
		startAngle: 240,
		yValueFormatString: "##0.00\"%\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: 60.25, label: "Like"},
			{y: 20.50, label: "Comment"},
			
			{y: 20.25, label: "Repost"},
			
		]
	}]
});
chart.render();

}
</script>
<?php include ('footer.php');?>