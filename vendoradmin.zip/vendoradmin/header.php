<?php include('../common/config.php');

if($_SESSION['user_id']==''){

echo "<script>window.location='../login.php';</script>";

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
   <!--  <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png"> -->
    <title>Tybell</title>
    <!-- Bootstrap Core CSS -->
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- You can change the theme colors from here -->
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">

<script src="https://unpkg.com/ionicons@4.5.5/dist/ionicons.js"></script>
</head>

<body class="fix-header fix-sidebar card-no-border">
   
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    
    <div id="main-wrapper">
     
        <header class="topbar">
            <nav class="navbar top-navbar navbar-toggleable-sm navbar-light">
               
                <div class="navbar-header">
                    <a class="navbar-brand" href="index.php">
                        <!-- Logo icon -->
                        <b>
                            
                         Tybell
                        </b>
                      
                        <span>
                           
                        </span>
                    </a>
                </div>
                
                <div class="navbar-collapse">
                   
                    <ul class="navbar-nav mr-auto mt-md-0 ">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <li class="nav-item hidden-sm-down">
                            <form class="app-search p-l-20">
                                <input type="text" class="form-control" placeholder="Search for..."> <a class="srh-btn"><i class="ti-search"></i></a>
                            </form>
                        </li>
                    </ul>
                   
                    <ul class="navbar-nav my-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/images/users/1.jpg" alt="user" class="profile-pic m-r-5" />Markarn Doe</a>
                        </li >
                        <li class="nav-item dropdown">
                            <a href="" class="nav-link dropdown-toggle text-muted waves-effect waves-dark " style="color: #fff;"><ion-icon name="power"></ion-icon></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul ><!--id="sidebarnav"-->
                    <li class="active">
                            <a href="PRO/index.php" class="waves-effect"><i class="fa fa-clock-o m-r-10" aria-hidden="true"></i>Bookings</a>
                        </li>
                        <li class="active">
                            <a href="dashboard.php" class="waves-effect"><i class="fa fa-clock-o m-r-10" aria-hidden="true"></i>Dashboard</a>
                        </li>
                         <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="cut"></ion-icon></i>Customer Management  <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="Addcustomer.php">Add customers</a></li>
                                <li><a href="removecustomer.php">Remove customers</a></li>
<!--                                 <li><a href="editscustomerdetails.php">Modify customers</a></li>
 -->                              </ul>
                        </li>
                        
                     
                         
                         <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="briefcase"></ion-icon></i>Payment management  <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="#">Registration of payments</a></li>
                                <li><a href="balance_paid.php">Balances to be paid</a></li>
                                <li><a href="bank_account.php">Registro de cuentas bancarias</a></li>
                              
                              </ul>
                        </li>
                         <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="people"></ion-icon></i>Gestión de cartera de servicios. <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="add_service.php">Añadir servicios</a></li>
                                <li><a href="service.php">Quitar servicios</a></li>
<!--                                 <li><a href="#">Edit services</a></li>
 -->                                <li><a href="booking.php">Gestión de reservas.</a></li>
                              </ul>
                        </li>

                        

                        <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="people"></ion-icon></i>Gestión de personal <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="add_staff.php">Añadir personal</a></li>
                                <li><a href="Staff.php">Quitar personal</a></li>
<!--                                 <li><a href="#">Edit staff</a></li>
 -->                               
                              </ul>
                        </li>
                         <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="people"></ion-icon></i>Gestión de promociones <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="offer_service.php">Definir ofertas</a></li>
                               
                              </ul>
                        </li>
                        <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="people"></ion-icon></i>Financial management <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="#">Control of income / expenses</a></li>
                               
                              </ul>
                        </li>
                        <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="people"></ion-icon></i>Trend management<span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="#">Follow-up of interaction with your customers</a></li>
                                <li><a href="requested_service.php">Most requested services</a></li>
                                <li><a href="#">Target customers</a></li>
                                <li><a href="#">Characteristics of the market</a></li>
                               
                              </ul>
                        </li>

                    </ul>
                   
                </nav>
            </div>
         
        </aside>
       
        <div class="page-wrapper">