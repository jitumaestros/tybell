<?php include ('header.php');

$stff=mysqli_fetch_array(mysqli_query($conn,"select * from staff where id='".$_GET['id']."'"));

?>





 <link rel="stylesheet" href="datepicker/pikaday.css">
<div class="container-fluid">

<form method="post" id="addcustm" enctype="multipart/form-data">
<input type="hidden" name="ids" value="<?php echo $_GET['id'];?>">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Editar personal
</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">Editar personal</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
<?php if($stff['profile_pic_path']==''){?>
		<div class="salon_img_div" style="background: url('img/camera.jpg');">
		<?php }else{ ?>

		<div class="salon_img_div" style="background: url('img/<?php echo $stff['profile_pic_path'];?>');">

			<?php }?>			<input type="file" class="choosefile" name="image">
		</div>

<!-- 
			<div class="col-sm-6">
			<div class="form-group">
				<label>DNI*</label>
				<input type="text" class="form-control" placeholder="" name="DNI">
			</div>
		</div> -->
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Nombre*</label>
				<input type="text" class="form-control" placeholder="" name="name" value="<?php echo $stff['name'];?>">
			</div>
		</div>


<div class="col-sm-6">
			<div class="form-group">
				<label>Dirección</label>
				<input type="text" class="form-control" placeholder="" name="address" id="txtPlacesss" value="<?php echo $stff['address'];?>">
			</div>
		</div>

		
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Número de teléfono móvil*</label>
				<input type="number" class="form-control" placeholder="" name="mobile" value="<?php echo $stff['mobile'];?>">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Teléfono de casa</label>
				<input type="number" class="form-control" placeholder="" name="home_phone" value="<?php echo $stff['home_phone'];?>">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Email*</label>
				<input type="email" class="form-control" placeholder="" name="email" value="<?php echo $stff['email'];?>">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Fecha de inicio*</label>
				<input type="text" class="form-control" placeholder="" name="start_date" id="dater" value="<?php echo $stff['start_date'];?>">
			</div>
		</div>
		<div class="form-group">
			<label>Disponibilidad</label><br>
  <?php 
  $schedules1=mysqli_fetch_array(mysqli_query($conn,"select * from staff_schedule where day='1' and staff_id='".$_GET['id']."'"));
  $schedules2=mysqli_fetch_array(mysqli_query($conn,"select * from staff_schedule where day='2' and staff_id='".$_GET['id']."'"));
  $schedules3=mysqli_fetch_array(mysqli_query($conn,"select * from staff_schedule where day='3' and staff_id='".$_GET['id']."'"));
  $schedules4=mysqli_fetch_array(mysqli_query($conn,"select * from staff_schedule where day='4' and staff_id='".$_GET['id']."'"));
  $schedules5=mysqli_fetch_array(mysqli_query($conn,"select * from staff_schedule where day='5' and staff_id='".$_GET['id']."'"));
  $schedules6=mysqli_fetch_array(mysqli_query($conn,"select * from staff_schedule where day='6' and staff_id='".$_GET['id']."'"));
  $schedules7=mysqli_fetch_array(mysqli_query($conn,"select * from staff_schedule where day='7' and staff_id='".$_GET['id']."'"));

$sxehex=explode(',',$schedules1['start_time']);
$end_times=explode(',',$schedules1['end_time']);



$sxehex2=explode(',',$schedules2['start_time']);
$end_times2=explode(',',$schedules2['end_time']);


$sxehex3=explode(',',$schedules3['start_time']);
$end_times3=explode(',',$schedules3['end_time']);


$sxehex4=explode(',',$schedules4['start_time']);
$end_times4=explode(',',$schedules4['end_time']);

$sxehex5=explode(',',$schedules5['start_time']);
$end_times5=explode(',',$schedules5['end_time']);

$sxehex6=explode(',',$schedules6['start_time']);
$end_times6=explode(',',$schedules6['end_time']);

$sxehex7=explode(',',$schedules7['start_time']);
$end_times7=explode(',',$schedules7['end_time']);
   ?>

   <style type="text/css">
   	.input-box-2 {
    display: flex;
    align-items: flex-start;
    justify-content: flex-start;
}

.input-box-3 {
    display: flex;
    align-items: center;
    justify-content: space-evenly;
}

.input-box-3 input {
    width: 41% !important;
    margin-bottom: 15px !important;
}
.wid-100{
	width: 100%;
}
   </style>

            <div class="input-new-box">
	

			<div class="inoput-box input-box-2">

				<label><input type="checkbox" value="1" name="day[]" <?php if($schedules1['day']=='1'){ echo "checked";}?>>  &nbsp; Monday</label>
				<div class="wid-100">
				<?php foreach ($sxehex as $key => $value) { ?>
				
				<div class="input-box-3" id="dfgdfg1">
					
				
				<input type="text" class="form-control" name="start_time1[]" placeholder="Start Time" value="<?php echo $value;?>">
				
				<span>To</span>
				<input type="text" class="form-control" name="end_time1[]" placeholder="End Time"  value="<?php echo $end_times[$key];?>">

				<a href="javascript:;" onclick="addscheddiv('1')">+</a>
 				<a href="javascript:;" onclick="remove('1')">-</a>
 				</div>
 				


<?php }?>
</div>
			</div>

			<span id="scheduledatesdiv1" ></span>
			</div>


       <div class="input-new-box">
	
			<div class="inoput-box">

				<label><input type="checkbox" value="2" name="day[]" <?php if($schedules2['day']=='2'){ echo "checked";}?>>  &nbsp;Tuesday</label>
				
				<div class="wid-100">
				<?php foreach ($sxehex2 as $key => $value2) { ?>

				<div class="input-box-3" id="dfgdfg22">

				<input type="text" class="form-control" name="start_time2[]" placeholder="Start Time" value="<?php echo $value2;?>">
				<span>To</span>
				<input type="text" class="form-control" name="end_time2[]" placeholder="End Time" value="<?php echo $end_times2[$key];?>">



				<a href="javascript:;" onclick="addscheddiv2('2')">+</a>
 				<a href="javascript:;" onclick="remove2('2')">-</a>
</div>
<?php }?>

			</div></div>
			<span id="scheduledatesdiv2" ></span>
			</div>
			


			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="3" name="day[]" <?php if($schedules3['day']=='3'){ echo "checked";}?>>  &nbsp; Wednesday</label>
				<div class="wid-100">
				<?php foreach ($sxehex3 as $key => $value3) { ?>

				<div class="input-box-3" id="dfgdfg33">

				<input type="text" class="form-control" name="start_time3[]" placeholder="Start Time" value="<?php echo $value3;?>">
				<span>To</span>
				<input type="text" class="form-control" name="end_time3[]" placeholder="End Time" value="<?php echo $end_times3[$key];?>">



				<a href="javascript:;" onclick="addscheddiv3('3')">+</a>
 				<a href="javascript:;" onclick="remove3('3')">-</a>
 				</div>

<?php }?>
			</div></div>

			<span id="scheduledatesdiv3" ></span>
			</div>
        

			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="4" name="day[]" <?php if($schedules4['day']=='4'){ echo "checked";}?>>  &nbsp; Thursday</label>
				
                 <div class="wid-100">
				<?php foreach ($sxehex4 as $key => $value4) { ?>

				<div class="input-box-3" id="dfgdfg44">

				<input type="text" class="form-control" name="start_time4[]" placeholder="Start Time" value="<?php echo $value4;?>">
				<span>To</span>
				<input type="text" class="form-control" name="end_time4[]" placeholder="End Time" value="<?php echo $end_times4[$key];?>">



				<a href="javascript:;" onclick="addscheddiv4('4')">+</a>
 				<a href="javascript:;" onclick="remove4('4')">-</a>
</div>
<?php }?>

	</div>
			</div>
			<span id="scheduledatesdiv4" ></span>
			</div>
		

			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="5" name="day[]" <?php if($schedules5['day']=='5'){ echo "checked";}?>>  &nbsp; Friday</label>
				  <div class="wid-100">
				<?php foreach ($sxehex5 as $key => $value5) { ?>

				<div class="input-box-3" id="dfgdfg55">

				<input type="text" class="form-control" name="start_time5[]" placeholder="Start Time" value="<?php echo $value5;?>">
				<span>To</span>
				<input type="text" class="form-control" name="end_time5[]" placeholder="End Time" value="<?php echo $end_times5[$key];?>">



				<a href="javascript:;" onclick="addscheddiv5('5')">+</a>
 				<a href="javascript:;" onclick="remove5('5')">-</a>
</div>
<?php }?>

			</div>
			</div>
			<span id="scheduledatesdiv5" ></span>
			</div>


			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="6" name="day[]" <?php if($schedules6['day']=='6'){ echo "checked";}?>>  &nbsp;Saturday</label>
				<div class="wid-100">
				<?php foreach ($sxehex6 as $key => $value6) { ?>

				<div class="input-box-3" id="dfgdfg66">

				<input type="text" class="form-control" name="start_time6[]" placeholder="Start Time" value="<?php echo $value6;?>">
				<span>To</span>
				<input type="text" class="form-control" name="end_time6[]" placeholder="End Time" value="<?php echo $end_times6[$key];?>">



				<a href="javascript:;" onclick="addscheddiv6('6')">+</a>
 				<a href="javascript:;" onclick="remove6('6')">-</a>
</div>
<?php }?>

	</div>
			</div>
			<span id="scheduledatesdiv6" ></span>
			</div>
		

			<div class="input-new-box">
	
			<div class="inoput-box">

				<label><input type="checkbox" value="7" name="day[]" <?php if($schedules7['day']=='7'){ echo "checked";}?>>  &nbsp; Sunday</label>
				
              <div class="wid-100">
				<?php foreach ($sxehex7 as $key => $value7) { ?>

				<div class="input-box-3" id="dfgdfg77">
				<input type="text" class="form-control" name="start_time7[]" placeholder="Start Time" value="<?php echo $value7;?>">

				<span>To</span>
				<input type="text" class="form-control" name="end_time7[]" placeholder="End Time" value="<?php echo $end_times7[$key];?>">



				<a href="javascript:;" onclick="addscheddiv7('7')">+</a>
 				<a href="javascript:;" onclick="remove7('7')">-</a>

</div>
<?php }?></div>	
			</div>
			<span id="scheduledatesdiv7" ></span>
             </div>
				


		
		</div>

<!-- 
		<div class="col-sm-6">
			<div class="form-group">
				<label>Roles</label><br>
				<div class="row">
				<div class="col-sm-4">
					<label>
						<input type="radio" class="" placeholder="" name="role" value="Staff" <?php if($stff[
						'role']=='Staff'){ echo "checked";}?>>Staff
					</label>
				</div>

				<div class="col-sm-4">
				<input type="radio" class="" placeholder="" name="role" value="Administrator" <?php if($stff[
						'role']=='Administrator'){ echo "checked";}?>>Administrator
				</div>
			</div>
			</div>
		</div>
 -->


		<!-- <div class="col-sm-12">
			<div class="form-group">
				<label>Short Description in salon</label>
				<textarea class="form-control">
					
				</textarea>
			</div>
		</div>
 -->
		
		<button class="addsalonbtn" name="submit" type="submit">Editar personal
</button>
		
	</div>
	<div id="datart"></div>
	</form>
</div>
<?php include ('footer.php');?>
    <script src="datepicker/pikaday.js"></script>

<script type="text/javascript">
	
$(document).ready(function (custm) {
 $("#addcustm").on('submit',(function(custm) {
 	   	//alert();

  $("#form_abc1_img").show();
  custm.preventDefault();
  $.ajax({
   url: "php/edit_staff.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert();
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});



  new Pikaday(
  {
    field: document.getElementById('dater'),
    trigger: document.getElementById('datepicker-button'),
    minDate: new Date(2000, 0, 1),
    ariaLabel: 'Custom label',
    maxDate: new Date(2020, 12, 31),
    yearRange: [2010,2020]

  });
</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE&sensor=false&libraries=places"></script>

<script type="text/javascript">


  google.maps.event.addDomListener(window, 'load', function () {

  /*  var options = {

      componentRestrictions: {country: "in"}
    };*/
    var places = new google.maps.places.Autocomplete(document.getElementById('txtPlacesss'));

    google.maps.event.addListener(places, 'place_changed', function () {

      var place = places.getPlace();

      var address = place.formatted_address;

      var latitude = place.geometry.location.lat();

      var longitude = place.geometry.location.lng();

      var mesg = "Address: " + address;

      mesg += "\nLatitude: " + latitude;

      mesg += "\nLongitude: " + longitude;


      $("#latitude").val(latitude);
      $("#longitude").val(longitude);

    });

  });






</script>

<script type="text/javascript">
	var no=1;
	function addscheddiv(id){
    var no1= no++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg'+no1+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label> <div class="wid-100"><div class="input-box-3"><input type="text" class="form-control" name="start_time1[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time1[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv('+id+')">+</a><a href="javascript:;" onclick="remove('+no1+')">-</a></div></div></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}



var noa=2;
	function addscheddiv2(id){
    var no2= noa++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg2'+no2+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><div class="wid-100"><div class="input-box-3"><input type="text" class="form-control" name="start_time2[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time2[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv('+id+')">+</a><a href="javascript:;" onclick="remove2('+no2+')">-</a></div><div></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}


var noa3=3;
	function addscheddiv3(id){
    var no3= noa3++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg3'+no3+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><div class="wid-100"><div class="input-box-3"><input type="text" class="form-control" name="start_time3[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time3[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv('+id+')">+</a><a href="javascript:;" onclick="remove3('+no3+')">-</a></div><div></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}



var noa4=4;
	function addscheddiv4(id){
    var no4= noa4++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg4'+no4+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><div class="wid-100"><div class="input-box-3"><input type="text" class="form-control" name="start_time4[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time4[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv4('+id+')">+</a><a href="javascript:;" onclick="remove4('+no4+')">-</a></div><div></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}


var noa5=5;
	function addscheddiv5(id){
    var no5= noa5++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg5'+no5+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><div class="wid-100"><div class="input-box-3"><input type="text" class="form-control" name="start_time5[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time5[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv5('+id+')">+</a><a href="javascript:;" onclick="remove5('+no5+')">-</a></div><div></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}

var noa6=6;
	function addscheddiv6(id){
    var no6= noa6++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg6'+no6+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><div class="wid-100"><div class="input-box-3"><input type="text" class="form-control" name="start_time6[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time6[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv6('+id+')">+</a><a href="javascript:;" onclick="remove6('+no6+')">-</a></div><div></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}


var noa7=7;
	function addscheddiv7(id){
    var no7= noa7++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg7'+no7+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><div class="wid-100"><div class="input-box-3"><input type="text" class="form-control" name="start_time7[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time7[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv7('+id+')">+</a><a href="javascript:;" onclick="remove7('+no7+')">-</a></div><div></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}




	function remove(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg"+id).hide();
}





function remove2(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg2"+id).hide();
}

function remove3(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg3"+id).hide();
}

function remove4(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg4"+id).hide();
}

function remove5(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg5"+id).hide();
}

function remove6(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg6"+id).hide();
}

function remove7(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg7"+id).hide();
}






</script>