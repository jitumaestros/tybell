<?php include('../../common/config.php');
          extract($_POST);?>
                                      <p class="user-Nasm"> Servicio </p>

   <select  class="form-control" name="service_id[]" >
   <?php 
                     $cat = mysqli_query($conn,"select * from service where salon_id='".$_SESSION['user_id']."' and  category_id='$cat'");

            while($row = mysqli_fetch_array($cat)){ 

            $dfgdfj = explode(",", $service_id);
                $sel = ''; 
             for ($i=0; $i < count($dfgdfj); $i++) { 
              if($row['id']==$dfgdfj[$i]){ $sel = 'selected'; $i = count($dfgdfj);}
             }

              ?>
 <option value="<?php echo $row['id'];?>" <?php echo $sel;?>><?php echo $row['name'];?></option>
          <?php   } ?>  
                              </select>

                              <link rel="stylesheet" href="https://maestrosinfotech.com/Tybell/vendoradmin/PRO/multiple-select.css"/>

 <script src="https://maestrosinfotech.com/Tybell/vendoradmin/PRO/multiple-select.js"></script>    
 <script src="datepicker/pikaday.js"></script>
    <script>


    $(function() {

        $('#msdddd').change(function() {

            console.log($(this).val());

        }).multipleSelect({

            width: '100%'

        });

    });

    </script>