<?php include('../../common/config.php');

  extract($_POST);
?>
<option>Tipo de Servicio</option>
        <?php 

	  $sqli=mysqli_query($conn,"SELECT * FROM `subcategory` WHERE `category_id`='$cat'");
while($city_details=mysqli_fetch_array($sqli)){?>
	
	<option value="<?php echo $city_details['id']; ?>"><?php echo $city_details['name']; ?></option>

			  
	 <?php  }  ?>  
               

