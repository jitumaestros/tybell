<?php include('../../common/config.php');
extract($_POST);

$strtotime=strtotime('now');

$image=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], "../image/".$image);

$category_id1=implode(',', $category_id);
$subcategory_id1=implode(',', $subcategory_id);



$check= mysqli_query($conn,"INSERT INTO staff (name, mobile, email,status,strtotime,salon_id,pricing_level,job_title,gender,permissions,about,category_id,subcategory_id,image)VALUES ('$name', '$mobile', '".$email."','$status','$strtotime','".$_SESSION['user_id']."','$pricing_level','$job_title','$gender','$permissions','$about','$category_id1','$subcategory_id1','$image')");

 $insert_id= mysqli_insert_id($conn);
$ex=explode(',', $permission_name);

foreach ($ex as $key => $value) {
  # code...

 mysqli_query($conn,"insert into staff_permission set name='$value',staff_id='$insert_id'");
}

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Team member added successfully</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="team_member.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

	
}

 


?>