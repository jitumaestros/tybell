<?php include ('header.php');

?>
  <div class="team_member_from">
		<div class="">  			
			<div class="team_wrapper">
				<div class="tem_add_title">
					Team Member
				</div>
				<form method="post" id="addteamem" enctype="multipart/form-data">
				<div id="getpermiss"></div>

				<div class="col-sm-6">
					<div class="top_team">
						
							<div class="left_tem_img">
								<div class="img_blog_team">
									<img src="img/dummy_icon.png" id="blah">
									<input type="file" class="choose" name="image" id="imgInp" required="required">
								</div>
							</div>
							<div class="form_div_blog1">
								<div class="form-group add-team-input">
									<input type="text" class="form-control" placeholder="First and last name" name="name"  required="required">
								
										<input type="checkbox" name=""> &nbsp; Provides treatments & services
									
									
								</div>
							</div>
							
					</div>
					<div class="team_from_add">
						<div class="form-group">
							<label><i>Pricing Level</i></label>
							<select class="form-control" name="pricing_level">
								<option value="Default">Default</option>
							</select>
						</div>
						<div class="form-group">
							<label><i>Job title</i></label>
							<input type="text" class="form-control" name="job_title"  required="required">
						</div>
						<div class="form-group">
							<label><i>Phone</i></label>
							<input type="number" class="form-control" name="mobile"  required="required">
						</div>
						<div class="form-group">
							<label><i>Gender</i></label>
							<select class="form-control" name="gender">
							<option value="Male">Male</option>
							<option value="FeMale">FeMale</option>

								<option value="Other / prefer not to disclose">Other / prefer not to disclose</option>
							</select>
						</div>
						<div class="form-group">
							<label>Email Address</label>
							<input type="text" class="form-control" name="email">
								<div class="ckechoinpu">
							<input type="checkbox" name="status" value="1"> &nbsp; Can log in to Dala3 Connect</div>
						</div>
						<div class="form-group">
							<label><i>Permissions</i></label>
							<select class="form-control" name="permissions">
								<option value="Stylist/Therapist">Stylist/Therapist</option>
								<option value="Custom">Custom</option>
								<option value="Owner">Owner</option>

							</select>
							<a href="javascript:;" class="ckechoinpu" data-toggle="modal" data-target="#Customise11">Customise Permissions</a>
						</div>
					</div>
					<div class="baout_team">
						<div class="form-group">
							<label><i>About</i></label>
							<textarea class="form-control" cols="4" rows="4" name="about"></textarea>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="right_option_blog">
						<div class="right_copunt-blog2">
							<div class="form-group">
								<p><b>What services can be booked for this employee online?</b></p>
								<input type="checkbox" name="" value="" onclick="allchecked('1');"> &nbsp;All services
							</div>

					<?php $r = rand();

							 $sqlii=mysqli_query($conn,"select * from category");
							while($catnm=mysqli_fetch_array($sqlii)){


							?>
							<div class="form-group">
								<p><b><input type="checkbox" style="opacity: 0;" name="category_id[]" value="<?php echo $catnm['id']?>" class="checkboxall checkboxalldm<?php echo $catnm['id'];?>"><?php echo $catnm['name']?></b> 

								&nbsp;&nbsp; <a href="javascript:;" class="checkboxall" onclick="checkedinside('<?php echo $catnm['id'];?>');">Selectall</a> &nbsp;&nbsp; <a href="javascript:;" class="checkboxall"  onclick="uncheckedinside('<?php echo $catnm['id'];?>');">Deselectall</a></p>

								<?php $sub=mysqli_query($conn,"select * from subcategory where category_id='".$catnm['id']."'");
							while($subnm=mysqli_fetch_array($sub)){
							 ?>
								<p><input type="checkbox" name="subcategory_id[]" class="checkboxall checkboxalld<?php echo $catnm['id'];?>" value="<?php echo $subnm['id'];?>"  onclick="checkedinsidecat('<?php echo $catnm['id'];?>');"> &nbsp;<?php echo $subnm['name'];?></p>

								<?php }?>
								
							</div>
							<?php }?>
						
						</div>

					</div>
					<button  class="save_btn" name="submit" type="submit" style="background:#6BBE4A; border:1px solid #6BBE4A;color: #fff;">Save</button>

				</div>
				<div id="getdata"></div>
				</form>
			</div>
		</div>
  </div>
  <!-- Modal -->


  <div class="modal fade" id="Customise11" role="dialog" >
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-body1 overflow-h">
        	<div class="tem_add_title">
					Team Member
			</div>
        	 <div class="right_option_blog1">
        	 <form method="post" id="addpermi" enctype="multipart/form-data">
        	 	<div class="col-sm-6">
        	 		<div class="right_copunt-blog2">
						
						<div class="form-group">
							<p><b>General</b></p>
							<p><input type="checkbox" name="name[]" value="View list of bookings"> &nbsp;View list of bookings</p>
							<p><input type="checkbox" name="name[]" value="Manage venue details"> &nbsp;Manage venue details</p>
							<p><input type="checkbox" name="name[]" value="View Finance deatils"> &nbsp;View Finance deatils</p>
							<p><input type="checkbox" name="name[]" value="View Sales report"> &nbsp;View Sales report</p>
							<p><input type="checkbox" name="name[]" value="Can refound transactions"> &nbsp;Can refound transactions</p>
							<p><input type="checkbox" name="name[]" value="Can edit service prices in checkout"> &nbsp;Can edit service prices in checkout</p>
						</div>
						<div class="form-group">
							<p><b>Menu</b></p>
							<p><input type="checkbox" name="name[]" value="View menu"> &nbsp;View menu</p>
							<p><input type="checkbox" name="name[]" value="Edit menu"> &nbsp;Edit menu</p>
							
						</div>
						<div class="form-group">
							<p><b>Clients</b></p>
							<p><input type="checkbox" name="name[]" value="View Clinet list"> &nbsp;View Clinet list</p>
							<p><input type="checkbox" name="name[]"  value="View/ edit client contact details"> &nbsp;View/ edit client contact details</p>
							
						</div>
						
						
					</div>
        	 	</div>
				<div class="col-sm-6">
					<div class="right_copunt-blog2">
						
						<div class="form-group">
							<p><b>Calendar</b></p>
							<p><input type="checkbox" name="name[]"  value="Manage own calendar"> &nbsp;Manage own calendar</p>
							<p><input type="checkbox" name="name[]"  value="View Others' calendar"> &nbsp;View Others' calendar</p>
							<p><input type="checkbox" name="name[]"  value="Manage Others' calendar"> &nbsp;Manage Others' calendar</p>
							<p><input type="checkbox" name="name[]"  value="Can delete appointments"> &nbsp;Can delete appointments</p>
							
						</div>
						<div class="form-group">
							<p><b>Hotel/Spa</b></p>
							<p><input type="checkbox" name="name[]"  value="Manage Spa Day inventory"> &nbsp;Manage Spa Day inventory</p>
							<p><input type="checkbox" name="name[]"  value="Manage Overnight inventory"> &nbsp;Manage Overnight inventory</p>					
						</div>
						<div class="form-group">
							<p><b>Staff</b></p>
							<p><input type="checkbox" name="name[]"  value="Add therapists">  &nbsp;Add therapists</p>
							<p><input type="checkbox" name="name[]"  value="Change user permissions"> &nbsp;Change user permissions</p>
							
						</div>
						
						
					</div>
				</div>
			</div>
			 <div class="col-sm-12 padder">
	        	<div class="modal-footer">
	        		 	<button  class="save_btn" name="submit" type="submit"  style="background:#6BBE4A; border:1px solid #6BBE4A;color: #fff;" >Save</button>

		          	<button class="save_btn" style="background: #FFFFFF; border:1px solid #ddd;color: #333;" data-dismiss="modal">Close</button> 
		         
		        </div>
	        </div>
	        </form>
        </div>
       
      </div>
      
    </div>
  </div>
  
<?php include ('footer.php');?>

<script type="text/javascript">

$(document).ready(function(){

    $("#clickchecks").click(function(){

     if (!$(this).is(':checked')) {

        $(".checkboxall").prop('checked', false);

        
    }else{
      $(".checkboxall").prop('checked', true);
      
  }
})


})
function checkedinside(id){
    
  $(".checkboxalld"+id).prop('checked', true);
    $(".checkboxall"+id).prop('checked', true);
    $(".checkboxalldm"+id).prop('checked', true);

  
}


function uncheckedinside(id){    
  $(".checkboxalld"+id).prop('checked', false);
      $(".checkboxall"+id).prop('checked', false);
    $(".checkboxalldm"+id).prop('checked', false);

}
function checkedinsidecat(id){
    
    $(".checkboxalldm"+id).prop('checked', true);

  
}

function allchecked(id){
    
    $(".checkboxall").prop('checked', true);

  
}



</script>

<script type="text/javascript">
	

$(document).ready(function (addseroffr) {
 $("#addpermi").on('submit',(function(addseroffr) {
 	   //	alert();

  $("#form_abc1_img").show();
  addseroffr.preventDefault();
  $.ajax({
   url: "php/addperission.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   //	alert(data);

     $("#form_abc1_img").hide();
   $("#getpermiss").show().html(data);


          $('#Customise11').removeClass('in');
                $('#Customise11').attr("aria-hidden","true");
                $('#Customise11').css("display", "none");
                $('.modal-backdrop').remove();
                $('body').removeClass('modal-open');

      },
     error: function(){}          
    });

 }));
});




$(document).ready(function (addteam) {
 $("#addteamem").on('submit',(function(addteam) {
 	   	//alert();

  $("#form_abc1_img").show();
  addteam.preventDefault();
  $.ajax({
   url: "php/add_team_member.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
  // 	alert(data);
     $("#form_abc1_img").hide();
   $("#getdata").show().html(data);
      },
     error: function(){}          
    });

 }));
});

</script><script type="text/javascript">
   function readURL(input)
   {
      if (input.files && input.files[0]) {
       var reader = new FileReader();
       reader.onload = function(e) {
          $('#blah').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
   }
   }
   
   $("#imgInp").change(function() {
   readURL(this);
   });
   
   
</script>