<?php include ('header.php');?>
 <link rel="stylesheet" href="datepicker/pikaday.css">
<div class="container-fluid">

<form method="post" id="addcustm" enctype="multipart/form-data">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Añadir personal
</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">Añadir personal</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		<div class="salon_img_div" style="background: url('img/camera.jpg');">
			<input type="file" class="choosefile" name="image">
		</div>

<!-- 
			<div class="col-sm-6">
			<div class="form-group">
				<label>DNI*</label>
				<input type="text" class="form-control" placeholder="" name="DNI">
			</div>
		</div> -->
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Nombre*</label>
				<input type="text" class="form-control" placeholder="" name="name">
			</div>
		</div>


<div class="col-sm-6">
			<div class="form-group">
				<label>Dirección</label>
				<input type="text" class="form-control" placeholder="" name="address" id="txtPlacesss">
			</div>
		</div>

		
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Número de teléfono móvil*</label>
				<input type="text" class="form-control" placeholder="" name="mobile">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Teléfono de casa</label>
				<input type="text" class="form-control" placeholder="" name="home_phone">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Email*</label>
				<input type="email" class="form-control" placeholder="" name="email">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Fecha de inicio*</label>
				<input type="text" class="form-control" placeholder="" name="start_date" id="dater">
			</div>
		</div>
		<!-- <div class="col-sm-6">
			<div class="form-group">
				<label>Horario de trabajo de</label>
                <?php echo  gettimeselecr('schedule_from','');?>   
			</div>
		</div>
		 <div class="col-sm-6">
			<div class="form-group">
				<label>Horario de trabajo para</label>
                <?php echo  gettimeselecr('schedule_to','');?> 
			</div>
		</div> -->
		
		
			<div class="form-group">
			<label>Disponibilidad</label><br>
  

            <div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="1" name="day[]">  &nbsp; Monday</label>
				

				<input type="text" class="form-control" name="start_time1[]" placeholder="Start Time">
				
				<span>To</span>
				<input type="text" class="form-control" name="end_time1[]" placeholder="End Time">



				<a href="javascript:;" onclick="addscheddiv('1')">+</a>
 				<a href="javascript:;" style="visibility: hidden;">-</a>


			</div>
			<span id="scheduledatesdiv1" ></span>
			</div>


       <div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="2" name="day[]">  &nbsp;Tuesday</label>
				

				<input type="text" class="form-control" name="start_time2[]" placeholder="Start Time">
				<span>To</span>
				<input type="text" class="form-control" name="end_time2[]" placeholder="End Time">



				<a href="javascript:;" onclick="addscheddiv2('2')">+</a>
 				<a href="javascript:;" style="visibility: hidden;">-</a>


			</div>
			<span id="scheduledatesdiv2" ></span>
			</div>

			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="3" name="day[]">  &nbsp; Wednesday</label>
				

				<input type="text" class="form-control" name="start_time3[]" placeholder="Start Time">
				<span>To</span>
				<input type="text" class="form-control" name="end_time3[]" placeholder="End Time">



				<a href="javascript:;" onclick="addscheddiv3('3')">+</a>
 				<a href="javascript:;" style="visibility: hidden;">-</a>


			</div>
			<span id="scheduledatesdiv3" ></span>
			</div>

			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="4" name="day[]">  &nbsp; Thursday</label>
				

				<input type="text" class="form-control" name="start_time4[]" placeholder="Start Time">
				<span>To</span>
				<input type="text" class="form-control" name="end_time4[]" placeholder="End Time">



				<a href="javascript:;" onclick="addscheddiv4('4')">+</a>
 				<a href="javascript:;" style="visibility: hidden;">-</a>


			</div>
			<span id="scheduledatesdiv4" ></span>
			</div>

			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="5" name="day[]">  &nbsp; Friday</label>
				

				<input type="text" class="form-control" name="start_time5[]" placeholder="Start Time">
				<span>To</span>
				<input type="text" class="form-control" name="end_time5[]" placeholder="End Time">



				<a href="javascript:;" onclick="addscheddiv5('5')">+</a>
 				<a href="javascript:;" style="visibility: hidden;">-</a>


			</div>
			<span id="scheduledatesdiv5" ></span>
			</div>

			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="6" name="day[]">  &nbsp;Saturday</label>
				

				<input type="text" class="form-control" name="start_time6[]" placeholder="Start Time">
				<span>To</span>
				<input type="text" class="form-control" name="end_time6[]" placeholder="End Time">



				<a href="javascript:;" onclick="addscheddiv6('6')">+</a>
 				<a href="javascript:;" style="visibility: hidden;">-</a>


			</div>
			<span id="scheduledatesdiv6" ></span>
			</div>
			<div class="input-new-box">
	

			<div class="inoput-box">

				<label><input type="checkbox" value="7" name="day[]">  &nbsp; Sunday</label>
				

				<input type="text" class="form-control" name="start_time7[]" placeholder="Start Time">

				<span>To</span>
				<input type="text" class="form-control" name="end_time7[]" placeholder="End Time">



				<a href="javascript:;" onclick="addscheddiv7('7')">+</a>
 				<a href="javascript:;" style="visibility: hidden;">-</a>


			</div>
			<span id="scheduledatesdiv7" ></span>
			</div>
			




		
		</div>


	<!-- 	<div class="col-sm-6">
			<div class="form-group">
				<label>Roles</label><br>
				<div class="row">
				<div class="col-sm-4">
					<label>
						<input type="checkbox" class="" placeholder="" name="role" value="Staff">Staff
					</label>
				</div>

				<div class="col-sm-4">
				<input type="checkbox" class="" placeholder="" name="role" value="Administrator">Administrator
				</div>
			</div>
			</div>
		</div> -->

		
		<button class="addsalonbtn" name="submit" type="submit">Añadir personal
</button>
		
	</div>
	<div id="datart"></div>
	</form>
</div>


<?php include ('footer.php');?>
    <script src="datepicker/pikaday.js"></script>

<script type="text/javascript">
	
$(document).ready(function (custm) {
 $("#addcustm").on('submit',(function(custm) {
 	   	//alert();

  $("#form_abc1_img").show();
  custm.preventDefault();
  $.ajax({
   url: "php/add_staff.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert();
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});



  new Pikaday(
  {
    field: document.getElementById('dater'),
    trigger: document.getElementById('datepicker-button'),
    minDate: new Date(2000, 0, 1),
    ariaLabel: 'Custom label',
    maxDate: new Date(2020, 12, 31),
    yearRange: [2010,2020]

  });
</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE&sensor=false&libraries=places"></script>

<script type="text/javascript">


  google.maps.event.addDomListener(window, 'load', function () {

  /*  var options = {

      componentRestrictions: {country: "in"}
    };*/
    var places = new google.maps.places.Autocomplete(document.getElementById('txtPlacesss'));

    google.maps.event.addListener(places, 'place_changed', function () {

      var place = places.getPlace();

      var address = place.formatted_address;

      var latitude = place.geometry.location.lat();

      var longitude = place.geometry.location.lng();

      var mesg = "Address: " + address;

      mesg += "\nLatitude: " + latitude;

      mesg += "\nLongitude: " + longitude;


      $("#latitude").val(latitude);
      $("#longitude").val(longitude);

    });

  });



</script>
<script type="text/javascript">
	var no=1;
	function addscheddiv(id){
    var no1= no++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg'+no1+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><input type="text" class="form-control" name="start_time1[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time1[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv('+id+')">+</a><a href="javascript:;" onclick="remove('+no1+')">-</a></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}



var noa=2;
	function addscheddiv2(id){
    var no2= noa++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg2'+no2+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><input type="text" class="form-control" name="start_time2[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time2[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv('+id+')">+</a><a href="javascript:;" onclick="remove2('+no2+')">-</a></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}


var noa3=3;
	function addscheddiv3(id){
    var no3= noa3++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg3'+no3+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><input type="text" class="form-control" name="start_time3[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time3[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv('+id+')">+</a><a href="javascript:;" onclick="remove3('+no3+')">-</a></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}



var noa4=4;
	function addscheddiv4(id){
    var no4= noa4++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg4'+no4+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><input type="text" class="form-control" name="start_time4[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time4[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv4('+id+')">+</a><a href="javascript:;" onclick="remove4('+no4+')">-</a></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}


var noa5=5;
	function addscheddiv5(id){
    var no5= noa5++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg5'+no5+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><input type="text" class="form-control" name="start_time5[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time5[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv5('+id+')">+</a><a href="javascript:;" onclick="remove5('+no5+')">-</a></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}

var noa6=6;
	function addscheddiv6(id){
    var no6= noa6++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg6'+no6+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><input type="text" class="form-control" name="start_time6[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time6[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv6('+id+')">+</a><a href="javascript:;" onclick="remove6('+no6+')">-</a></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}


var noa7=7;
	function addscheddiv7(id){
    var no7= noa7++;
		var ids = Math.floor(Math.random() * 20)+''; 

		var dd = "'ss"+ids+"'";


		var ddgrade = "'price_gadings"+id+"'";


		var dfdf ='<div id="dfgdfg7'+no7+'">	<div class="inoput-box"><label><input type="checkbox" value="<?php echo $daynm['id'];?>" style="display:none;">  &nbsp; <?php echo $daynm['day'];?></label><input type="text" class="form-control" name="start_time7[]" placeholder="Start Time"><span>To</span><input type="text" class="form-control" name="end_time7[]" placeholder="End Time"><a href="javascript:;" onclick="addscheddiv7('+id+')">+</a><a href="javascript:;" onclick="remove7('+no7+')">-</a></div><div>';


		$("#scheduledatesdiv"+id).append(dfdf);


	}




	function remove(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg"+id).hide();
}





function remove2(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg2"+id).hide();
}

function remove3(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg3"+id).hide();
}

function remove4(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg4"+id).hide();
}

function remove5(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg5"+id).hide();
}

function remove6(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg6"+id).hide();
}

function remove7(id){
	//alert(id);
	$("#"+id).html('');
	$("#dfgdfg7"+id).hide();
}






</script>