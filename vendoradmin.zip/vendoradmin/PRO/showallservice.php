<?php include('../../common/config.php');

			$sqlii=mysqli_query($conn,"select * from category ORDER BY RAND()");
			while($catnm=mysqli_fetch_array($sqlii))
			{
			$counts=mysqli_num_rows(mysqli_query($conn,"select * from service where category_id='".$catnm['id']."' and salon_id='".$_SESSION['user_id']."'"));
			if($counts >0){
		?>
		<div class="main-show-services">
			<div class="show-servive-header-2">
				<div class="col-sm-6 padder">
					<div class="show-services-blog-left">
						<ul>
							<li><a href="javascript:;" onclick="showservices('1');"><i class="fa fa-bars"></i></a></li>
							<li><a href=""><?php echo $catnm['name'];?></a></li>
						</ul>
					</div>
				</div>
				<div class="col-sm-6 padder">
					<div class="right-header-blo2">
						<ul class="list-button"> 
							<li><a onclick="return confirm('¿Estás seguro de que quieres eliminar?');" href="?deleteid=<?php echo $catnm['id'];?>"><i class="fa fa-trash-o" aria-hidden="true" style="color: red"></i> &nbsp;Eliminate</a></li>


							<li><a href="javascript:;" onclick="showgroup('<?php echo $catnm['id'];?>')";><i class="fa fa-pencil" aria-hidden="true"></i> &nbsp;Editar</a></li>



							<li><a href="addanotherservices.php?catid=<?php echo $catnm['id'];?>&service=service"><i class="fa fa-plus"></i> &nbsp;Anadir nuevo servicio</a></li>
						</ul>
					</div>
				</div>
			</div>


			<?php
				$sqliis=mysqli_query($conn,"select * from service where category_id='".$catnm['id']."' and salon_id='".$_SESSION['user_id']."' order by id asc ");
				while($sernm=mysqli_fetch_array($sqliis)){
				$srvlacount=mysqli_num_rows(mysqli_query($conn,"select * from service_price_level where service_id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."'"));

$discouns=mysqli_num_rows(mysqli_query($conn,"select * from promotion where salon_id='".$_SESSION['user_id']."' and service_id='".$sernm['id']."'"));



			?>
			<div class="services--blog-1">				
				<div class="show-services--1">
					<div class="table-responsive">
						 <table class="table">
						 	<tbody>
						 		<tr>
						 			<?php 
						 			if($srvlacount >0){	 ?>
							 		<td style="width: 55%;">
							 			<div class="tab-1">
							 				<i class="fa fa-scissors"></i> 
							 				&nbsp;
							 				<span><b><?php echo $sernm['name'];?></b></span>
							 				<?php if($discouns >0){?>
							 				<span class="dis"><b><i class="fa fa-percent iconss" aria-hidden="true"  style=""></i>&nbsp;&nbsp;&nbsp;Descuento en  pelo</b></span>
							 				<?php }?>

							 			</div>
							 		</td>
							 		<td style="width: 40%;">
							 			
							 		</td>
							 		<td>
                  <td><a href="edit_service.php?id=<?php echo $sernm['id'];?>&service=service"> <i class="fa fa-pencil"></i>  </a></td>
							 		</td>
							 		<?php }else{?>
	                               <td style="width: 55%;">
							 			<div class="tab-1">
							 				<i class="fa fa-scissors"></i> 
							 				&nbsp;
							 				<span><b><?php echo $sernm['name'];?></b></span>
							 				<?php if($discouns >0){?>
							 				<span class="dis"><b><i class="fa fa-percent iconss" aria-hidden="true" ></i>&nbsp;&nbsp;&nbsp;Descuento en  pelo</b></span>
							 				<?php }?>
							 			</div>
							 		</td>
							 		<td style="width: 40%;">
							 			<?php echo $sernm['duration'];?>
							 		</td>
							 		<td>
							 		$<?php echo $sernm['price'];?>	
							 		</td>
							 		<td><a href="edit_service.php?id=<?php echo $sernm['id'];?>&service=service"> <i class="fa fa-pencil"></i>  </a></td>

							 			<?php }?>
							 	</tr>
								<?php 
									$sqliids=mysqli_query($conn,"select * from service_price_level where service_id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' ");
									while($servinm=mysqli_fetch_array($sqliids)){ 
								?>
							 	<tr>
							 		<td style="width: 55%;">
							 			<div class="tab-1" style="    padding-left: 40px;">
							 				
							 				<p><?php echo $servinm['name_price_vevel'];?></p>
							 			</div>
							 		</td>
							 		<td style="width: 40%;">
							 			<p><?php echo $servinm['duration'];?></p>
							 		</td>
							 		<td>
							 			<p class="strm"><?php if($servinm['price'] >$servinm['sale_price']){?> <span>$<DEL><?php echo $servinm['price'];?></DEL></span><?php }?>$<?php echo $servinm['sale_price'];?></p>
							 		</td>
							 	</tr>
							 	<?php }?>
						 	</tbody>							 	
						 </table>
					</div>
				</div>					
			</div>
			<?php }?>
		</div>

		 

		<?php }}
		?>
		<script type="text/javascript">
			
function showservices(id){

$.ajax({
       type: "POST",
         url: "showallservice.php",
            data: "id="+id, 
          success: function(html)
            {     

              $("#0").html(html);
                 
             }
        

            });

}


		</script>