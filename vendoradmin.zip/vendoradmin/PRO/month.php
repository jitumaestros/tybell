<!DOCTYPE HTML>
<html>
<head>  
  <script type="text/javascript">
  window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
    {

      title:{
        text: "Formatting Date"
      },
      axisX:{  
//Try Changing to MMMM
              valueFormatString: "MMM"
      },

      axisY: {
              valueFormatString: "0.0#"
      },
      
      data: [
      {        
        type: "line",
        lineThickness: 2,
        dataPoints: [
        { x: new Date(2000,0), y: 0.65 },
        { x: new Date(2000,1), y: -0.8 },
        { x: new Date(2000,2), y: -0.9 },
        { x: new Date(2000,3), y: -0.25 },
        { x: new Date(2000,4), y: -0.01 },
        { x: new Date(2000,5), y: -0.27 },
        { x: new Date(2000,6), y: 0.24 },
        { x: new Date(2000,7), y: 0.06 },
        { x: new Date(2000,8), y: 1.37 },
        { x: new Date(2000,9), y: -1.35 },
        { x: new Date(2000,10), y: -0.72 }
        ]
      }    
      ]
    });

chart.render();
}
</script>
  <script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</head>
<body>
  <div id="chartContainer" style="height: 300px; width: 100%;">
  </div>
</body>
</html>