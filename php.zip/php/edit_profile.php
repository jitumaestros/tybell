<?php include('../common/config.php');

extract($_POST);

$image=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'],"../img/".$image);



if(!empty($_FILES['image']['name'])){

$sqlii=mysqli_query($conn,"update users set first_name='$first_name',last_name='$last_name',gender='$gender', image='$image' where id='".$_SESSION['user_id']."'");
}else{

$sqlii=mysqli_query($conn,"update users set first_name='$first_name',last_name='$last_name',gender='$gender' where id='".$_SESSION['user_id']."'");

}
if($sqlii){

echo '<div class="alert alert-success"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong >  Successfully updated profile.</strong></div>';

}else{
echo '<div class="alert alert-danger"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong>Failed!!</strong></div>';

}


?>