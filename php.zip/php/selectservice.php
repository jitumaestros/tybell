<?php include('../common/config.php');
extract($_POST);

$m='1';
$tu='2';
$wed='3';
$th='4';
$fri='5';
$st='6';
$t=date('d-m-Y');
$dayy= date("D",strtotime($t));
if($dayy=='Mon'){
  $daycount=$m;
}elseif($dayy=='Tue'){
  $daycount=$tu;
}elseif($dayy=='Wed'){
  $daycount=$wed;
}elseif($dayy=='Thu'){
  $daycount=$th;
}elseif($dayy=='Fri'){
  $daycount=$fri;
}elseif($dayy=='Sat'){
  $daycount=$st;
}
$date= date('H:i'); 
              /*echo $date= '11:00'; 
              */
              $mor='12:00';
              $afet='17:00';
              if(($date >=$mor) && ($date <=$afet)){
                $days='2';
              }elseif($date <=$mor){
                $days='1';
              }else{
                $days='3';
              }
              $days;

              $price='';
              $pricelavel='';

               $ff = implode(',', $serviceid);
            

              //$_SESSION['serviceid']=$ff;

              $ddd=array_unique($ff);

              $n='0';
              foreach (array_unique($serviceid) as $key => $valuse) {

               $sernm=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$valuse."'"));

               $spriclavel=mysqli_fetch_array(mysqli_query($conn,"select * from service_price_level where service_id='".$serbn['id']."' order by id asc"));



               $spriclavelf=mysqli_num_rows(mysqli_query($conn,"select * from service_price_level where salon_id='".$slonid."' and service_id='".$sernm['id']."' order by id asc"));

/*              echo "select * from service_price_level where salon_id='".$slonid."' and id='$serviceidserpricl' and service_id='".$valuse."'";
*/


$offercount=mysqli_num_rows(mysqli_query($conn,"select * from promotion where service_id='".$sernm['id']."' and salon_id='".$slonid."' and status='0' and discount_status='1'"));
$offerx=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where service_id='".$sernm['id']."' and salon_id='".$slonid."' and status='0' and discount_status='1'"));
$offer=mysqli_fetch_array(mysqli_query($conn,"select * from Off_peak_time where salon_id='".$slonid."' and discount_id='".$offerx['discount_id']."' and day='$days' and FIND_IN_SET('$daycount', dayweekcount)"));



$todays=date('Y-m-d');

$servicdis=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$sernm['id']."' and salon_id='".$slonid."' and offer_status='1'"));

$servicdiscount=mysqli_num_rows(mysqli_query($conn,"select * from service where id='".$sernm['id']."' and salon_id='".$slonid."' and offer_status='1'"));

$offercount1co=mysqli_num_rows(mysqli_query($conn,"select * from promotion where service_id='".$sernm['id']."' and salon_id='".$slonid."' and status='0' and discount_status='0' and start_date <='$todays' and end_date >='$todays'"));



$offercount1=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where service_id='".$sernm['id']."' and salon_id='".$slonid."' and status='0' and discount_status='0' and start_date <='$todays' and end_date >='$todays'"));

if($servicdiscount >0){

  $dis=$spriclavel['sale_price']*$servicdis['offer']/100;
  $price +=$spriclavel['sale_price']-$dis;

}
elseif($offercount >0){


  $prrr=explode(',', $offer['dayweekcount']);
  $ofrd=explode(',', $offer['offer']);
  $day1=$prrr['0'];
  $day2=$prrr['1'];
  $day3=$prrr['2'];
  $day4=$prrr['3'];
  $day5=$prrr['4'];
  $day6=$prrr['5'];
  $offer1=$ofrd['0'];
  $offer2=$ofrd['1'];
  $offer3=$ofrd['2'];
  $offer4=$ofrd['3'];
  $offer5=$ofrd['4'];
  $offer6=$ofrd['5'];

  if($daycount=='1'){
    $offerper=$offer1;
  }elseif($daycount=='2'){
    $offerper=$offer2;
  }elseif($daycount=='3'){
    $offerper=$offer3;
  }elseif($daycount=='4'){
    $offerper=$offer4;
  }elseif($daycount=='5'){
    $offerper=$offer5;
  }elseif($daycount=='6'){
    $offerper=$offer6;
  }
  $totalprice=$sernm['sale_price']*$offerper/100;
  $price +=$sernm['sale_price']-$totalprice;


  $n1++;

  $pricelavel +=$spriclavel['sale_price'];

}elseif($offercount1co >0){

 $totalprice=$spriclavel['sale_price']*$offercount1['offer']/100;
 $price +=$spriclavel['sale_price']-$totalprice;

}else{

  $price +=$spriclavel['sale_price'];
}



}

$spriclaveld=mysqli_fetch_array(mysqli_query($conn,"select * from service_price_level where salon_id='".$slonid."' and id='$serviceidserpricl' order by id asc"));


 $offercounts=mysqli_num_rows(mysqli_query($conn,"select * from promotion where service_id='".$spriclaveld['service_id']."' and salon_id='".$slonid."' and status='0' and discount_status='1' and FIND_IN_SET('$days', day)"));

                $offerx=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where service_id='".$spriclaveld['service_id']."' and salon_id='".$slonid."' and status='0' and discount_status='1'"));


                $offerf=mysqli_fetch_array(mysqli_query($conn,"select * from Off_peak_time where salon_id='".$slonid."' and discount_id='".$offerx['discount_id']."' and day='$days' and FIND_IN_SET('$daycount', dayweekcount)"));

                $todays=date('Y-m-d');

                $servicdis=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$spriclaveld['service_id']."' and salon_id='".$slonid."' and offer_status='1'"));

                $servicdiscount=mysqli_num_rows(mysqli_query($conn,"select * from service where id='".$spriclaveld['service_id']."' and salon_id='".$slonid."' and offer_status='1'"));

                $offercount1co=mysqli_num_rows(mysqli_query($conn,"select * from promotion where service_id='".$spriclaveld['service_id']."' and salon_id='".$slonid."' and status='0' and discount_status='0' and start_date <='$todays' and end_date >='$todays'"));



                $offercount1=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where service_id='".$spriclaveld['service_id']."' and salon_id='".$slonid."' and status='0' and discount_status='0' and start_date <='$todays' and end_date >='$todays'"));

                $offercount=mysqli_num_rows(mysqli_query($conn,"select * from promotion where service_id='".$spriclaveld['service_id']."' and salon_id='".$slonid."' and status='0' and discount_status='1'"));


                if($servicdiscount >0){

                  $dis=$spriclaveld['sale_price']*$servicdis['offer']/100;
                  $totals=$spriclaveld['sale_price']-$dis;

                }
                elseif($offercount >0){
                  $m='1';
                  $tu='2';
                  $wed='3';
                  $th='4';
                  $fri='5';
                  $st='6';
                  $t=date('d-m-Y');
                  $dayy= date("D",strtotime($t));
                  if($dayy=='Mon'){
                    $daycount=$m;
                  }elseif($dayy=='Tue'){
                    $daycount=$tu;
                  }elseif($dayy=='Wed'){
                    $daycount=$wed;
                  }elseif($dayy=='Thu'){
                    $daycount=$th;
                  }elseif($dayy=='Fri'){
                    $daycount=$fri;
                  }elseif($dayy=='Sat'){
                    $daycount=$st;
                  }
                  $date= date('H:i'); 
              /*echo $date= '11:00'; 
              */
              $mor='12:00';
              $afet='17:00';
              if(($date >=$mor) && ($date <=$afet)){
                $days='2';
              }elseif($date <=$mor){
                $days='1';
              }else{
                $days='3';
              }
              $days;

              $offerx=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where service_id='".$spriclaveld['service_id']."' and salon_id='".$slonid."' and status='0' and discount_status='1'"));
              $offer=mysqli_fetch_array(mysqli_query($conn,"select * from Off_peak_time where salon_id='".$slonid."' and discount_id='".$offerx['discount_id']."' and day='$days' and FIND_IN_SET('$daycount', dayweekcount)"));

              $prrr=explode(',', $offer['dayweekcount']);
              $ofrd=explode(',', $offer['offer']);
              $day1=$prrr['0'];
              $day2=$prrr['1'];
              $day3=$prrr['2'];
              $day4=$prrr['3'];
              $day5=$prrr['4'];
              $day6=$prrr['5'];
              $offer1=$ofrd['0'];
              $offer2=$ofrd['1'];
              $offer3=$ofrd['2'];
              $offer4=$ofrd['3'];
              $offer5=$ofrd['4'];
              $offer6=$ofrd['5'];
              if($daycount=='1'){
                $offerper=$offer1;
              }elseif($daycount=='2'){
                $offerper=$offer2;
              }elseif($daycount=='3'){
                $offerper=$offer3;
              }elseif($daycount=='4'){
                $offerper=$offer4;
              }elseif($daycount=='5'){
                $offerper=$offer5;
              }elseif($daycount=='6'){
                $offerper=$offer6;
              }
              $totalprice=$spriclaveld['sale_price']*$offerper/100;
              $totals=$spriclaveld['sale_price']-$totalprice;
            }elseif($offercount1co >0){

             $totalprice=$spriclaveld['sale_price']*$offercount1['offer']/100;
             $totals=$spriclaveld['sale_price']-$totalprice;

           }else{
            $totals=$spriclaveld['sale_price'];
          } 

?>


<div class="set mysetus">

 <a href="javascript:;" class="name-ser">

  Service from $ <?php echo $price+$totals;?></a>

  <a href="checkout_1.php?salon_id=<?php echo $slonid;?>&service_lavel=<?php echo $serviceidserpricl;?>&dates=<?php echo $_SESSION['dates'];?>&fromtime=<?php echo $fromtime;?>&totime=<?php echo $totime;?>&serviceid=<?php echo $ff;?>"><button type="checkbox" class="chossetime" style="width: unset;">Choose Time</button> </a>



</div>

