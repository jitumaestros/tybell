<?php include ('header.php'); ?>
<!-- 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>


<div class="add_client_bloc_main">
  <div class="container-fluid">
    <div class="row">
      <div class="col -sm-12">
        <div class="add_client_Model">  
          <div class="mian_head">
            Client
          </div>
          <div class="body_block">
          <form method="post" id="addclient" enctype="multipart/form-data"> 
            <div class="col-sm-12">
              <div class="form-group">
                <div class="col-sm-5 padder">
                  <label> Nombre</label>
                </div>
                <div class="col-sm-7">
                  <input type="text" name="first_name" class="form-control">
                </div>
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <div class="col-sm-5 padder">
                  <label> Nombre de telefono </label>
                </div>
                <div class="col-sm-7">
                  <input type="text" name="phone" class="form-control">
                </div>
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <div class="col-sm-5 padder">
                  <label> correo electronico </label>
                </div>
                <div class="col-sm-7">
                  <input type="email" name="email" class="form-control">
                </div>
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <div class="col-sm-5 padder">

                </div>
                <div class="col-sm-7">
                  <p class="pres-t">
                    Comunicación de marketing <br>
                    <label class="saloon_check"> 
                       Confirmo pue he obtenido el consentimiento especifico, informado, otorgado libremente y activo de este cliente para recibir invitaciones para volver a reservar y otros correos electrónicos de marketing de mi salón y tengo un registro de este consentimiento.
                      <input type="checkbox" checked="checked">
                      <span class="checkmark"></span>
                    </label>
                  </p>
                </div>
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <div class="col-sm-5 padder">
                  <label> Genero </label>
                </div>
                <div class="col-sm-7">
                  <select class="form-control gent_selet" name="gender">
                      <option value="1"> Mujer</option>
                     <option value="2"> Hombre</option>

                  </select>
                </div>
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <div class="col-sm-5 padder">
                  <label> Compleanos </label>
                </div>
                <div class="col-sm-7 padder">
                  <div class="col-sm-4">
                    <select class="form-control gent_selet" name="dob">
                        <option value="enero"> enero </option>
                        <option value="febrero"> febrero </option>

                        <option value="marzo"> marzo </option>

                        <option value="abril"> abril </option>

                        <option value="Mayo"> Mayo </option>

                        <option value="junio"> junio </option>

                        <option value="July"> July </option>
                          <option value="agosto"> agosto </option>

                        <option value="septiembre"> septiembre </option>

                        <option value="octubre"> octubre </option>

                        <option value="noviembre"> noviembre </option>

                       <option value="diciembre"> diciembre </option>

                    </select>
                  </div>
                  <div class="col-sm-3 padder">
                    <input type="text" name="" class="form-control" name="datess">
                  </div>
                  <div class="col-sm-4">
                    <a href="#"> Elija ano </a>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-sm-12">
              <div class="form-group">
                <div class="col-sm-5 padder">
                  <label> notas </label>
                </div>
                <div class="col-sm-7">
                  <textarea placeholder="" cols="4" class="form-control text_area" name="notes"></textarea>
                </div>
              </div>
            </div>
          </div>              
          <div class="col-sm-12">
            <div class="form-group btn_block">
              <div class="col-sm-6 padder">
                <div class="text-left">
                  <button class="cancel"> Cancelar </button>
                </div>
              </div>
              <div class="col-sm-6 padder">
                <div class="text-right">
                  <button class="btn Guardar_button" name="submit" name="submit"><i class="fa fa-check"></i>  Guardar </button>
                </div>
              </div>
            </div>
          </div>
         </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="datart"></div>

<?php include ('footer.php');?>
<script type="text/javascript">

  $(document).ready(function (addclients) {
 $("#addclient").on('submit',(function(addclients) {
  $("#form_abc1_img").show();
  addclients.preventDefault();
  $.ajax({
   url: "php/add_client.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});


</script>

 
