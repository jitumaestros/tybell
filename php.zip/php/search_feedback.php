<?php include('../common/config.php');
extract($_POST);

$sfd=mysqli_query($conn,"select * from feedback where salon_id='".$slnid."' order by id desc");

   while($feednm=mysqli_fetch_array($sfd)){

    $user=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$feednm['user_id']."'"));

$totalrating=$feednm['rating']+$feednm['ambience']+$feednm['staff']+$feednm['cleanliness'];


$time1a = $feednm['strtotime'];


$time2a =strtotime('now');


$diffdhg = $time2a-$time1a;
date("d H:i:s",$diffdhg);
$days = $diffdhg / 86400;
$day_explode = explode(".", $days);
$d = $day_explode[0];


$hours = '.'.$day_explode[1].'';
$hour = $hours * 24;
$hourr = explode(".", $hour);
$h = $hourr[0];

$minute = '.'.$hourr[1].'';
$minutes = $minute * 60;
$minute = explode(".", $minutes);
$m = $minute[0];

$seconds = '.'.$minute[1].'';
$second = $seconds * 60;
$s = round($second);



if($h==1){

  $hr=$h.' hour';
}

else{

  $hr=$h.' hours';

}





$hour =$da *24+$ha;

$day =$d;

$month =$d/30;

$week =$d/7;
$weeks =round($week, 1);


if($weeks==1){

  $weeksdss=$weeks.' Week';
}

else{

  $weeksdss=$weeks.' Weeks';

}


if($day==1){

  $dayd=$day.' day';
}

else{

  $dayd=$day.' days';

}





$monthd =round($month, 1);

if($day >='30'){

  $duratingD=$monthd.' Months';

}

else if($day >= '7'){

  $duratingD=$weeksdss;

}


else if($day > '0'){
  $duratingD=$dayd;

}



else if($h > '0'){
  $duratingD=$hr;

}





else{

  $duratingD=$m.' Min';

}

foreach ($rating as $key => $values) {
 
?>

<div class="review_1 border_bottom">

 <ul class="stare_list pull-unset star_list2">

  <li class="pull-unset" style="color: #CCBB66;"><a href="" style="color: #CCBB66;">

    <?php 
    $total= $totalrating/4;
 
  if($total==$values){

    $userdd=explode('.',$total);

    $seekerdid=$userdd[0];

    $schedid=$userdd[1];

    for($i=0;$i<$seekerdid; $i++){


      echo '<i class="fa fa-star" style="color:#CCBB66;font-size:16px;padding: 7px;"></i>';

    }    
    if($schedid!=''){
      echo '<i class="fa fa-star-half-o" aria-hidden="true"  style="color:#CCBB66;font-size:16px;padding: 7px;"></i>&nbsp;';
    }

    ?>

  </a> </li>

</ul>

<p class="review_para"><?php echo $feednm['feedback'];?></p>

<p>

  <span><?php echo $user['first_name'].' '.$user['last_name'];?></span>

  <span style="color: #B3B3B3;"> <i class="fa fa-check-circle-o"></i> <?php echo $duratingD;?> ago</span>

  <span style="color: #D9D9D9;">Report</span>                   

</p>
</div>
<?php }  }}?>
