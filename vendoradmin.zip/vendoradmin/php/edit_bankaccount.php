<?php include('../../common/config.php');

  extract($_POST);

$image=$_FILES['image']['name'];
if(!empty($_FILES['image']['name'])){

move_uploaded_file($_FILES['image']['tmp_name'], "../img/".$image);

$check= mysqli_query($conn,"update bank_account set bank_name='$bank_name', account_number='$account_number', account_owner='$account_owner', icon='$image', notes='$notes' where id='$ids'");

}else{

$check= mysqli_query($conn,"update bank_account set bank_name='$bank_name', account_number='$account_number', account_owner='$account_owner', notes='$notes' where id='$ids'");


}


 $insert_id= mysqli_insert_id($conn);
 
 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Cuenta bancaria correctamente editada</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="bank_account.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 


?>