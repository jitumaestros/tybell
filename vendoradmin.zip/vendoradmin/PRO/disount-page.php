<?php include('header.php');
$discouns=mysqli_num_rows(mysqli_query($conn,"select * from promotion where salon_id='".$_SESSION['user_id']."'"));
?>
<div class="discount-page-blog">
<?php if($discouns ==0){?>
	<div class="disount-blog-1">
		<img src="img/discount.png">
		<h2>No hay descuentos todavia</h2>
		<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>

		<a href="discountpage_2.php?service=<?php echo $_GET['service'];?>" class="disnou-btn">Anadirdes descuento</a>

	</div><?php }else{?>


	<div class="discount_block"> 
		<div class="row">
			<div class="col-sm-9">
				<div class="left_blokc align-left">
					<h2> Descuentos </h2>   
				</div>
			</div>
			<div class="col-sm-3">
				<div class="left_blokc align-right">
					<a href="discountpage_2.php?service=service"><button class="btn btn-add">Añadir descuento </button> </a>  
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-sm-9">
				<div class="left_blokc align-left">
					<label> Descuento </label>   
					
				</div>
			</div>
			<div class="col-sm-3">
				<div class="left_blokc align-right">
					<label> Estado </label> 
				</div>
			</div>
		</div>

		<?php $sqliii=mysqli_query($conn,"select * from promotion where salon_id='".$_SESSION['user_id']."' group by discount_id order by strtotime desc");
while($rowss=mysqli_fetch_array($sqliii)){
$discounts=mysqli_num_rows(mysqli_query($conn,"select * from promotion where discount_id='".$rowss['discount_id']."'"));
$offr=mysqli_fetch_array(mysqli_query($conn,"select * from Off_peak_time where discount_id='".$rowss['discount_id']."'"));
$osfer=explode(',', $offr['offer']);
		?>
		<div class="row">
			<div class="col-sm-9">
				<div class="left_blokc align-left">
					<label> <p> <?php echo $rowss['name'];?>  </p>   </label> 
 <p> <?php if($rowss['discount_status']=='0'){ echo $rowss['offer'];?>% descuento de última hora<?php }else{ echo "Hasta";  echo " "; echo $osfer['0'];?>% de descuento en temporada baja <?php }?> -Aplicado a <?php echo $discounts;?> servicios activos</p>

				</div>
			</div>
			<div class="col-sm-3">
				<div class="left_blokc align-right">

							<p><a href="edit_discountservice.php?discount_id=<?php echo $rowss['discount_id'];?>&service=service" ><button style="background: gray; color: #fff; padding: 4px 9px; border-radius: 5px;font-size: 13px;"><i class="fa fa-pencil" aria-hidden="true"></i> &nbsp;Editar</button></a></p>

					<?php if($rowss['status']=='0'){ ?>
						<button class="btn btn-add2"> <?php echo "Active";?></button>  <?php }else{ ?><button class="btn btn-add1"> <?php echo "Inactive";} ?>    
				</div>
			</div>
		</div>
		<?php }?>

</div>

<?php }?>

</div>


<style type="text/css">
	.discount_block .left_blokc .btn-add2 {
    border-radius: 14px;
    min-width: 80px;
    padding: 10px 12px;
    outline: none !important;
    background: #6BBE4A;
}
.discount_block {
    display: block;
    width: 100%;
    padding: 4px 20px;
    background: white;
}
.discount_block .left_blokc {
    display: block;
}


.discount_block .left_blokc.align-left {
    text-align: left;
}

.discount_block .left_blokc.align-right {
    text-align: right;
}

.discount_block .left_blokc label {
    font-size: 14px;
    display: block;
    text-transform: capitalize;
    padding: 10px 0;
}


.discount_block .left_blokc .btn-add1 {
    border-radius: 14px;
    min-width: 80px;
    padding: 10px 12px;
    outline: none !important;
}

.discount_block .left_blokc .btn-add {
    border: 1px solid #6BBE4A;
    background: #6BBE4A;
    outline: none !important;
    color: white;
    text-transform: capitalize;
    min-width: 120px;
    padding: 8px 8px;
    font-size: 14px;
    font-weight: 700;
    border-radius: 0;
}

.discount_block .row {
    display: block;
    margin: 0;
    border-bottom: 1px solid #ddd;
    padding: 6px 0;
}


  

 .discount_block .left_blokc h2 {
    margin: 0;
    font-size: 20px;
    font-weight: 700;
    line-height: 31px;
}



</style>







<?php include('footer.php');?>