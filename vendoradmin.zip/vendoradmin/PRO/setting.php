<?php include ('header.php'); 
$users=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$_SESSION['user_id']."'"));
$img=explode(',',$users['salon_pic']);
?>
<style type="text/css">
	.uipload button {
		width: 100%;
		padding: 7px 0;
		background: #34A8B0;
		border: 0;
		color: #fff;
		font-size: 16px;
		border-radius: 0px;
	}
	.uipload {
		width: 100%;
		position: relative;
	}
</style>
<div class="upload_list">
	<div class="venuedesyla-blog-2">
		<ul class="nav nav-tabs">
			<li class="active"><a href="javascript:;" class="step" onclick="togless('tab_block1')">Venue Details</a></li>
			<li><a href="javascript:;" class="step" onclick="togless('tab_block2')">Opening Hours </a></li>
			    <!-- <li><a href="javascript:;" class="step" onclick="togless('tab_block3')"> Policies </a></li>
			    <li><a href="javascript:;" class="step" onclick="togless('tab_block4')">Resources</a></li> -->
			</ul>


			<div class="tab-content">

				<div class="tab-pane" id="tab_block1" style="display: block;">
					<div class="col-sm-8 padder">
						<div class="left-log-venu">
							<h4 class="m-4-0 m-b-15">Venue Details</h4>
							<form method="post" id="updatesalon" enctype="multipart/form-data">

								<div class="left-log-venu-2">
									<div class="col-sm-4 padder">
										<div class="left-img-blog">
											<?php if($img['0']==''){?>
											<img src="img/dummy_icon.png" id="blah">
											<?php }else{
												?>
												<img src="../../image/<?php echo $img['0'];?>" id="blah">
												<?php }?>
												<div class="uipload">
													<input type="file" name="file[]"  id="imgInp" multiple="multiple" >
													<button>Upload</button>
												</div>

											</div>
										</div>
										<div class="col-sm-8">
											<div class="right-blog-2">
												<div class="form-group">
													<input type="text" placeholder="" class="form-control"  name="business_name" value="<?php echo $users['business_name'];?>" >
												</div>
									<!-- 	<div class="form-group">
											<label>Primary type</label>
											<select class="form-control" name="prime_type">
												<option value="Beauty Salon">Beauty Salon</option>
											</select>
										</div> -->
									</div>
								</div>
								<div class="part-2venudetail">
									<p><b>Where is your located?</b></p>
									<div class="form-group">
										<div class="col-sm-3">
											<label>Address</label>
										</div>
										<div class="col-sm-9 text-right">
											<input type="text" class="form-control" name="adress"  id="txtPlacesss" autocomplete="off" value="<?php echo $users['adress'];?>" >
											<input type="hidden" name="latitude" id="latitude">
											<input type="hidden" name="longitude" id="longitude">
										</div>
									</div>
									<div class="form-group">
										<div class="col-sm-3">
											<label>Postcode</label>
										</div>
										<div class="col-sm-9 text-right">
											<input type="text" class="form-control" placeholder="L19 9DT" name="postcode" value="<?php echo $users['postcode'];?>">
										</div>
									</div>
									<div class="form-group">
										<div class="col-sm-3">
											<label>Country</label>
										</div>
										<div class="col-sm-9 text-right">
											<select class="form-control" name="country">
												<option value="<?php echo $users['country'];?>"><?php $sqliicss=mysqli_fetch_array(mysqli_query($conn,"select * from countries where id='".$users['country']."'"));echo $sqliicss['name'];?></option>
												<?php $sqliic=mysqli_query($conn,"select * from countries");
												while($counm=mysqli_fetch_array($sqliic)){
													?>
													<option value="<?php echo $counm['id'];?>"><?php echo $counm['name'];?></option>
													<?php }?>
												</select>
											</div>
										</div>
										<div class="form-group">
											<div class="col-sm-3">
												<label>Location on the map</label>								
											</div>
											<div class="col-sm-9">
												<div id="map" style="width: 100%; height: 400px;"></div>

												<!-- <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m12!1m3!1d14663.944853671816!2d77.4357627!3d23.243588749999997!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1569834731508!5m2!1sen!2sin" width="100%" height="250" frameborder="0" style="border:0;" allowfullscreen=""></iframe>-->
											</div> 

										</div>
										<button type="submit" name="submit" class="btn btn-default btn-success pull-right">Save</button>
										<div id="getdata"></div>
									</div>
								</div>
							</form>
						</div>
					</div>
					<div class="col-sm-4">
						<div class="venue-photos">
							<div class="venues-photos">
								<h4 class="m-4-0 m-b-15">Venue Photos</h4>
								<?php $imgss=explode(',',$users['salon_pic']);
								foreach ($imgss as $key => $imgnm) {?>

								<div class="venu-pic">
									<img src="../../image/<?php echo $imgnm;?>">
								</div>

								<?php }?>
								

							</div>
						</div>
					</div>
				</div> 
				<div class="tab-pane" id="tab_block2" style="display: none;" >
					<div class="form-group">
<?php $counts=mysqli_num_rows(mysqli_query($conn,"select * from  salon_opening_hr where salon_id ='".$_SESSION['user_id']."'"));

if($counts > '0'){?> 
<?php $sqliii=mysqli_query($conn,"select * from salon_opening_hr where salon_id ='".$_SESSION['user_id']."'");
while($slnophr=mysqli_fetch_array($sqliii)){
?>
<a href="edit_opening_hour.php?edit=<?php echo $slnophr['id'];?>&setting=setting" style="color: black;">
<div class="slm_week">
	<div class="left">
		<img src="img/dot.png">
		<span><b><?php echo $slnophr['day'];?></b></span>
		</div>
		<div class="right">
		<span><b><?php echo $slnophr['start_time'];?></b></span> - <span><b><?php echo $slnophr['end_time'];?></b></span>
	</div>
</div></a>

<?php } }else{

?>


					<form method="post" id="addslnschedule">
						<div class="input-new-box">
							<div class="inoput-box">
								<div class="mr_input_box">
									<label>
										<input type="checkbox" value="Monday" name="day[]">  &nbsp; Monday
									</label>

									<select type="text" class="form-control" name="start_time[]" placeholder="Open Time">
									<option value="">Select Open Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>

									</select>

									<span>To</span>
									
									<select type="text" class="form-control" name="end_time[]" placeholder="Close Time">
									<option value="">Select Close Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>
								</div>
							</div>
						</div>


						<div class="input-new-box">
							<div class="inoput-box">
								<div class="mr_input_box">
									<label><input type="checkbox" value="Tuesday" name="day[]">  &nbsp;Tuesday</label>


									<select type="text" class="form-control" name="start_time[]" placeholder="Open Time">
									<option value="">Select Open Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>
									<span>To</span>
									<select type="text" class="form-control" name="end_time[]" placeholder="Close Time">
									<option value="">Select Close Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>


								</div>
							</div>
						</div>


						<div class="input-new-box">
							<div class="inoput-box">
								<div class="mr_input_box">

									<label><input type="checkbox" value="Wednesday" name="day[]">  &nbsp; Wednesday</label>


									<select type="text" class="form-control" name="start_time[]" placeholder="Open Time">
									<option value="">Select Open Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>
									<span>To</span>
									<select  class="form-control" name="end_time[]" placeholder="Close Time">
									<option value="">Select Close Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>
								</div>
							</div>
						</div>


						<div class="input-new-box">
							<div class="inoput-box">
								<div class="mr_input_box">
									<label><input type="checkbox" value="Thursday" name="day[]">  &nbsp; Thursday</label>
									<select type="text" class="form-control" name="start_time[]" placeholder="Open Time">
									<option value="">Select Open Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>

									<span>To</span>
									<select  class="form-control" name="end_time[]" placeholder="Close Time">
									<option value="">Select Close Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>

								</div>
							</div>
						</div>


						<div class="input-new-box">
							<div class="inoput-box">
								<div class="mr_input_box">

									<label><input type="checkbox" value="Friday" name="day[]">  &nbsp; Friday</label>

									<select type="text" class="form-control" name="start_time[]" placeholder="Open Time">
									<option value="">Select Open Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>
									<span>To</span>
									<select class="form-control" name="end_time[]" placeholder="Close Time">
									<option value="">Select Close Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>

								</div>
							</div>
						</div>


						<div class="input-new-box">
							<div class="inoput-box">
								<div class="mr_input_box">

									<label><input type="checkbox" value="Saturday" name="day[]">  &nbsp;Saturday</label>
									<select type="text" class="form-control" name="start_time[]" placeholder="Open Time">
									<option value="">Select Open Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>
									<span>To</span>
									<select type="text" class="form-control" name="end_time[]" placeholder="Close Time">
                                 <option value="">Select Close Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>
								</div>
							</div>
						</div>


						<div class="input-new-box">
							<div class="inoput-box">
								<div class="mr_input_box">
									<label><input type="checkbox" value="Sunday" name="day[]">  &nbsp; Sunday</label>
									<select  class="form-control" name="start_time[]" placeholder="Open Time">
									<option value="">Select Open Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>
									<span>To</span>
									<select type="text" class="form-control" name="end_time[]" placeholder="Close Time">
									<option value="">Select Close Time</option>

									<option value="10:00 am">10:00 am</option>
									<option value="11:00 am">11:00 am</option>
                                    <option value="12:00 pm">12:00 pm</option>
									<option value="01:00 pm">01:00 pm</option>
									<option value="02:00 pm">02:00 pm</option>
									<option value="03:00 pm">03:00 pm</option>
									<option value="04:00 pm">04:00 pm</option>
                                    <option value="05:00 pm">05:00 pm</option>
                                    <option value="06:00 pm">06:00 pm</option>
                                    </select>

								</div>
							</div>
						</div>
 
						<div class="form-group text-right">
							<button class="btn btn-default addsalonbtn" name="submit" type="submit">Submit
							</button>
						</div>
						<div id="addschesln"></div>
						</form>


<?php }?>

				</div>

				<div class="tab-pane" id="tab_block3" style="display: none;" >
					<h3>Menu 2</h3>
					<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
				</div>
				<div class="tab-pane" id="tab_block4" style="display: none;" >

					<?php $sourccount=mysqli_num_rows(mysqli_query($conn,"select * from resources where salon_id='".$_SESSION['user_id']."'"));

					if($sourccount=='0'){

						?>

						<div class="setting-blog-1">
							<div class="setting-blog-2">
								<div class="img-div">
									<img src="img/salon.png">
								</div>
								<div class="para-contetn">
									<p>Resources help you to manage availability of your rooms, chairs, beds or equipment. Add your resources here.</p>
									<button class="btn btn-success" data-toggle="modal" data-target="#addnew" >+ Add New</button>
								</div>

							</div>
						</div>
						<?php }else{?>
						<br>
						<p style="padding-right: 450px;"><button class="btn btn-success" data-toggle="modal" data-target="#addnew" >+ Add New</button></p>
						<div class="show-resouces-table">
							<div class="table-responsive">
								<table class="table table-bordered">
									<thead>
										<tr>
											<th>Resource Name</th>
											<th>Quantity</th>
										</tr>
									</thead>
									<tbody>
										<?php $sqlii=mysqli_query($conn,"select * from resources where salon_id='".$_SESSION['user_id']."'");
										while($renm=mysqli_fetch_array($sqlii)){

											?>
											<tr>
												<td><?php echo $renm['name'];?></td>
												<td><?php echo $renm['quantity'];?></td>
											</tr>
											<?php }?>

										</tbody>

									</table>
								</div>
							</div>
							<?php }?>
						</div>
					</div>


				</div>
			</div>



			<!-- Resources -->
			<!-- Modal -->
			<div class="modal fade" id="addnew" role="dialog">
				<div class="modal-dialog">

					<!-- Modal content-->
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal">&times;</button>
							<h4 class="modal-title">ADD RESOURCE</h4>
						</div>
						<div class="modal-body">
							<div class="addresouncres-blog">
								<p><b>By adding resources you  will have a clear overview of the availability of specific resources for different type of treatments.</b></p>
								<form method="post" id="addresources">
									<div class="">
										<div class="form-group">
											<div class="col-sm-3 text-right">
												<label>Resource name</label>
											</div>
											<div class="col-sm-9 ">
												<input type="text" class="form-control" name="name"  autocomplete="off" value="" >								
											</div>
										</div>
										<div class="form-group">
											<div class="col-sm-3 text-right">
												<label>Quantity</label>
											</div>
											<div class="col-sm-9 ">
												<input type="text" class="form-control" value="" name="quantity">								
											</div>
										</div>
										<div class="form-group">
											<div class="col-sm-3 text-right">
												<p><i>Assigned services</i></p>
											</div>		
											<div class="col-sm-9 ">

												<?php
												$sqlii=mysqli_query($conn,"select * from category");
												while($catnm=mysqli_fetch_array($sqlii)){
													?>
													<p><b><input type="checkbox" style="opacity: 0;" name="category_id[]" value="<?php echo $catnm['id']?>" class="checkboxall checkboxalldm<?php echo $catnm['id'];?>"><?php echo $catnm['name'];?></b></p>	
													<div class="show-services">
														<?php $sub=mysqli_query($conn,"select * from subcategory where category_id='".$catnm['id']."'");
														while($subnm=mysqli_fetch_array($sub)){
															?>
															<div class="show-resouces">
																<input type="checkbox" name="subcategory_id[]" onclick="checkedinsidecat('<?php echo $catnm['id'];?>');" value="<?php echo $subnm['id'];?>">
																<p><?php echo $subnm['name'];?></p>
															</div>
															<?php }?>

														</div>							

														<?php }?>
													</div>
												</div>

											</div>
										</div>
									</div>
									<div class="modal-footer22">
										<div class="save text-right" style="border-top: 1px solid #ddd">
											<button class="save_bnt" style="width: unset;padding: 16px 35px;border-radius: 0px;" name="submit" type="submit">Save</button>
										</div>
									</div>
									<div id="getdatas"></div>
								</form>
							</div>

						</div>
					</div>
					<style type="text/css">
						.tab-content>.tab-pane {
							display: UNSET;
						}
					</style>

					<?php include ('footer.php'); ?>

					<script>

						function togless(id){ 
							$('#tab_block').hide(); 
							$('#tab_block1').hide();
							$('#tab_block2').hide();  
							$('#tab_block3').hide();  
							$('#tab_block4').hide();  
							$('#'+id).toggle();    
						}


						function checkedinsidecat(id){

							$(".checkboxalldm"+id).prop('checked', true);

						}
					</script>

					<script type="text/javascript">
						function readURL(input)
						{
							if (input.files && input.files[0]) {
								var reader = new FileReader();
								reader.onload = function(e) {
									$('#blah').attr('src', e.target.result);
								}
								reader.readAsDataURL(input.files[0]);
							}
						}

						$("#imgInp").change(function() {
							readURL(this);
						});


					</script>


					<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE&sensor=false&libraries=places"></script>

					<script type="text/javascript">

						google.maps.event.addDomListener(window, 'load', function () {

	/*    var options = {

	  componentRestrictions: {country: "in"}
	};*/
	var places = new google.maps.places.Autocomplete(document.getElementById('txtPlacesss'));

	google.maps.event.addListener(places, 'place_changed', function () {

		var place = places.getPlace();

		var address = place.formatted_address;

		var latitude = place.geometry.location.lat();

		var longitude = place.geometry.location.lng();

		var mesg = "Address: " + address;

		mesg += "\nLatitude: " + latitude;

		mesg += "\nLongitude: " + longitude;


		$("#latitude").val(latitude);
		$("#longitude").val(longitude);

	});

});



$(document).ready(function (addteams) {
$("#updatesalon").on('submit',(function(addteams) {
		   	//alert();

$("#form_abc1_img").show();
addteams.preventDefault();
$.ajax({
url: "php/update_salon.php",
type: "POST",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,
success: function(data){
// 	alert(data);
$("#form_abc1_img").hide();
$("#getdata").show().html(data);
},
error: function(){}          
});

}));
});



$(document).ready(function (addteamsd) {
$("#addresources").on('submit',(function(addteamsd) {
//alert();

$("#form_abc1_img").show();
addteamsd.preventDefault();
$.ajax({
url: "php/addresource.php",
type: "POST",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,
success: function(data){
// 	alert(data);
$("#form_abc1_img").hide();
$("#getdatas").show().html(data);
},
error: function(){}          
});

}));
});


$(document).ready(function (addslnsche) {
$("#addslnschedule").on('submit',(function(addslnsche) {
//alert();

$("#form_abc1_img").show();
addslnsche.preventDefault();
$.ajax({
url: "php/add_sln_schedule.php",
type: "POST",
data:  new FormData(this),
contentType: false,
cache: false,
processData:false,
success: function(data){
// 	alert(data);
$("#form_abc1_img").hide();
$("#addschesln").show().html(data);
},
error: function(){}          
});

}));
});

</script>
	<!-- <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE">
</script> -->

<script type="text/javascript">
	$(document).ready(function(){
		getLocation();
	})

	function getLocation() {
		if (navigator.geolocation) {
			navigator.geolocation.getCurrentPosition(showPosition);
		} else {
			x.innerHTML = "Geolocation is not supported by this browser.";
		}
	}

	function showPosition(position) {
		var clatt = position.coords.latitude;
		var clongi = position.coords.longitude; 



		var locations = [
		<?php 


		$saln=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$_SESSION['user_id']."'"));
		if($saln['latitude']!=""){
			?>

			['<?php echo mysqli_real_escape_string($conn,$saln['adress']);?>', <?php echo $saln['latitude'];?>, <?php echo $saln['longitude'];?>, 1],


			<?php }?>
			];
			var map = new google.maps.Map(document.getElementById('map'), {
				zoom: 10,
				center: new google.maps.LatLng(clatt, clongi),
				mapTypeId: google.maps.MapTypeId.ROADMAP
			});

			var infowindow = new google.maps.InfoWindow();

			var marker, i;

			for (i = 0; i < locations.length; i++) {  
				marker = new google.maps.Marker({
					position: new google.maps.LatLng(locations[i][1], locations[i][2]),
					map: map
				});

				google.maps.event.addListener(marker, 'click', (function(marker, i) {
					return function() {
						infowindow.setContent(locations[i][0]);
						infowindow.open(map, marker);
					}
				})(marker, i));
			}





			var locations1 = [


			['My Location', clatt, clongi, 1],
			];


			var marker1;
			for (i = 0; i < locations1.length; i++) {  
				marker1 = new google.maps.Marker({
					icon: {
						path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
						strokeColor: "green",
						scale: 3
					},
					position: new google.maps.LatLng(locations1[i][1], locations1[i][2]),
					map: map
				});



				google.maps.event.addListener(marker1, 'click', (function(marker1, i) {
					return function() {
						infowindow.setContent(locations1[i][0]);
						infowindow.open(map, marker1);
					}
				})(marker1, i));
			}

		}
	</script>