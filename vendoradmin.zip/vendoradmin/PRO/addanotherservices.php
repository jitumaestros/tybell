<?php include('header.php');?>
<div class="addanother-services">
	<div class="addserevice-header">
		<ul class="anotherservices-menu-tab">
			<li><a href="javascript:;" id="add1" class="active-ser" onclick="tabs('tab-1','add1')">Precio</a></li>
			<li><a href="javascript:;" id="add2" onclick="tabs('tab-2','add2')">Description</a></li>
		</ul>
	</div>
	<form method="post" enctype="multipart/form-data" id="addservcie">
	<input type="hidden" name="service" value="<?php echo $_GET['service'];?>">
	<div class="addanother-serives-blogtab">
		<div class="addservice-tab-1" id="tab-1">
			<div class="servicestab-1-1">
				<div class="addseroivceform">
					<div class="col-sm-4">
						 <div class="form-group">
						 	<label>Tipo de Servicio</label>
						 	<select class="form-control" required="required" name="category_id" onchange="getsubcat(this.value);">
						 	     <option value="<?php echo $_GET['catid'];?>"> <?php $ctt=mysqli_fetch_array(mysqli_query($conn,"select * from category where id='".$_GET['catid']."'"));echo $ctt['name'];?></option>

						 		 <?php $sqliii=mysqli_query($conn,"select * from category");

                                   while($stnm=mysqli_fetch_array($sqliii)){

                                      ?>

                              <option value="<?php echo $stnm['id'];?>"><?php echo $stnm['name'];?></option>

                             <?php }?>

						 	</select>
						 </div>
					</div>
					<div class="col-sm-4">
						 <div class="form-group">
						 	<label>Servicio  </label>
						 	

						 	<select class="form-control"  name="subcategory_id" id="change" required="required">
						 	     <?php $cttas=mysqli_query($conn,"select * from subcategory where category_id='".$_GET['catid']."'");
						 	     while($ctts=mysqli_fetch_array($cttas)){

						 	     ?>

						 	   <option value="<?php echo $ctts['id'];?>"> <?php echo $ctts['name'];?>  </option>
						 	   <?php }?>
						 	</select>
						 </div>
					</div>
					<div class="col-sm-4">
						 <div class="form-group">
						 	<label>Título del servicio</label>
						 	<input class="form-control" name="name" required="required">
						 </div>
					</div>
					<div class="col-sm-4">
						 <div class="form-group">
						 	<label>Descuento</label>
						 	<select class="form-control" name="offer">
						 		<option value="">No hay Descuento</option>
						 		
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>

													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

						 	</select>
						 </div>
					</div>
				</div>
				<div class="show-user-add-anoither">
					<p>EQUOPO-que recibe citas online para este servicio</p>
					<ul>
					<?php $sqliiis=mysqli_query($conn,"select * from staff where salon_id='".$_SESSION['user_id']."' ");

      while($stnm=mysqli_fetch_array($sqliiis)){

        ?>
						<li>
							<div class="list-ofuser">
								<input type="checkbox" name="stylist[]" value="<?php echo $stnm['id'];?>">
								<div class="username-ser">
									<p><b><?php echo $stnm['name'];?></b></p>
									<!-- <p>Permium</p> -->
								</div>
							</div>
						</li>
						<?php }?>
						
					</ul>
				</div>
				<div class="addanother-servivces-blogo3">
					<div class="table-responsive">
						<table class="table">
							<thead>
								<tr>
									<th>Nombre del nivel de precios</th>
									<th>Duration</th>
									<th>Precio</th>
									<th>Precio de Venta</th>
									<th></th>
									
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>
										<div class="form-group">
											
											<input type="text" class="form-control"  name="name_price_vevel[]">
										</div>
									</td>
									<td>
										<div class="form-group">
											
											<select class="form-control" name="duration[]">
												<option value="30 m">30 m</option>
                        <option value="1 h">1 h</option>
                         <option value="2 h">2 h</option>
                        <option value="3 h">3 h</option>
                        <option value="4 h">4 h</option>
                        <option value="5 h">5 h</option>
											</select>
										</div>
									</td>
									<td>
										<div class="form-group">
											
											<input type="text" class="form-control"  name="price[]" >
										</div>
									</td>
									<td>
										<div class="form-group">
											
											<input type="text" class="form-control"  name="sale_price[]">
										</div>
									</td>
									<td>
										<button class="close-btn"><i class="fa fa-times"></i></button>
									</td>


								</tr>
								
							</tbody>
						</table>
					</div>
					<a href="javascript:;" class="addanoth-btn">+ Anadir otra opcion de percio</a>
				</div>
			</div>
		</div>

		<div class="desciption-blog" id="tab-2" style="display: none;">
			<div class="devription">
				<h3>Descripción</h3>
				<textarea name="description"></textarea>
			</div>
		</div>
	</div>

	<div class="add-another-blog-footer">
		<button class="save-btn" name="submit" type="submit"> Guardar</button>
	</div>
	</form>
	<div id="datart"></div>
</div>


<script type="text/javascript">
	$(document).ready(function(){
       

    $(".addanoth-btn").click(function(){
 var mtt = Math.floor(Math.random() * 20); 
        $(".table").append('<tr id="divids'+mtt+'"><td><div class="form-group"><input type="text" class="form-control" name="name_price_vevel[]"></div></td><td><div class="form-group"><select class="form-control" name="duration[]"><option value="30 m">30 m</option><option value="1 h">1 h</option><option value="2 h">2 h</option><option value="3 h">3 h</option> <option value="4 h">4 h</option> <option value="5 h">5 h</option></select></div></td><td><div class="form-group"><input type="text" class="form-control" name="price[]"></div></td><td><div class="form-group"><input type="text" class="form-control" name="sale_price[]"></div></td><td><button class="close-btn"><i class="fa fa-times" onclick="hidss(this.id)" id="'+mtt+'"></i></button></td></tr>');

    });
    
});

                         
  function hidss(id){
   // alert('divids'+id)
    $("#divids"+id).html('');

  } 

function tabs(id,add){
	$('#tab-1').hide();
	$('#tab-2').hide();
	$('#'+id).toggle();
	$('#add1').removeClass('active-ser');
	$('#add2').removeClass('active-ser');
	$('#'+add).addClass('active-ser');

}

</script>
<style type="text/css">
textarea {
    width: 100%;
    height: 185px;

    }
    </style>

<!-- <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>


  <style type="text/css">
      
.mce-notification-warning{

display: none;

}

  </style> -->
<?php include('footer.php');?>
<script type="text/javascript">
 function getsubcat(id){
$.ajax({
       type: "POST",

         url: "php/subcategory.php",

            data: "cat="+id, 

          success: function(html)

            {     
              $("#change").html(html);


             }

            });

      }
</script>

<script type="text/javascript">

$(document).ready(function (actsdser) {
 $("#addservcie").on('submit',(function(actsdser) {
  $("#form_abc1_img").show();
 // alert();
  actsdser.preventDefault();
  $.ajax({
   url: "php/add_service.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert(data);
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});

</script>




