<?php include('../../../common/config.php');

  extract($_POST);

$strtotime=strtotime('now');
$dobs=$datess.' '.$dob;

$check= mysqli_query($conn,"INSERT INTO users (role, first_name, phone, email, gender, dob,notes)VALUES ('0', '$first_name', '".$phone."', '$email', '$gender', '".$dobs."','$notes')");

 $insert_id= mysqli_insert_id($conn);

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Cliente agregado exitosamente</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="Clientes.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

	
}

 


?>