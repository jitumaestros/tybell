<?php include('../../common/config.php');
extract($_POST);
$schedule_dateq=strtotime($dates);


$schedule_date1=date('m/d/Y',$schedule_dateq);

$bookincnt=mysqli_num_rows(mysqli_query($conn,"select * from block_staff where salon_id='".$_SESSION['user_id']."' and staff_id='".$staff_id."' and dates='".$schedule_date1."'"));

$start_time1=$start_time;

$end_time1=$end_time;

                $time1a = strtotime($end_time1);
                $time2a =strtotime($start_time1);
                $diffdhg = $time2a-$time1a;
                date("d H:i:s",$diffdhg);
                $days = $diffdhg / 86400;
                $day_explode = explode(".", $days);
                $d = $day_explode[0];
                $hours = '.'.$day_explode[1].'';
                $hour = $hours * 24;
                $hourr = explode(".", $hour);
                $h = $hourr[0];
                $minute = '.'.$hourr[1].'';
                $minutes = $minute * 60;
                $minute = explode(".", $minutes);
                $m = $minute[0];
                $seconds = '.'.$minute[1].'';
                $second = $seconds * 60;
                $s = round($second);
                if($h==1){
                  $hr=$h.' hour';
                }
                else{
                  $hr=$h.' hours';
                }
                $hour =$da *24+$ha;
                $day =$d;
                $month =$d/30;
                $year =$d/365;
                $week =$d/7;
                $weeks =round($week, 0);
              
              $duratingvi=$h;
              

if($bookincnt >0){

mysqli_query($conn,"delete from block_staff  where salon_id='".$_SESSION['user_id']."' and staff_id='".$staff_id."' and dates='".$schedule_date1."'");



  for($i=0;$i<$duratingvi;$i++)

{
  if($i=='1'){

$dur1='60';

}else if($i=='2'){

$dur1='120';

}else if($i=='3'){

$dur1='180';

}
else if($i=='4'){

$dur1='240';

}
else if($i=='5'){

$dur1='300';

}else{

$dur1=$i;

}

$endTime = strtotime("+$dur1 minutes",strtotime($start_time));

$dtess= date('h:i a',$endTime);


  $mysqld = mysqli_query($conn,"insert into block_staff set salon_id='".$_SESSION['user_id']."',staff_id='".$staff_id."',dates='".$schedule_date1."',strtotime='".$schedule_dateq."',start_time='$dtess',end_time='$end_time',notes='$notes'");


}
}
else{

for($i=0;$i<$duratingvi;$i++)

{
  if($i=='1'){

$dur1='60';

}else if($i=='2'){

$dur1='120';

}else if($i=='3'){

$dur1='180';

}
else if($i=='4'){

$dur1='240';

}
else if($i=='5'){

$dur1='300';

}else{

$dur1=$i;

}

$endTime = strtotime("+$dur1 minutes",strtotime($start_time));

$dtess= date('h:i a',$endTime);
/*$staff_id1='1,30';
*/
/*$excc=explode(',',$staff_id1);
*/
foreach ($staff_id as $key => $valuse) {
 

  $mysqld = mysqli_query($conn,"insert into block_staff set salon_id='".$_SESSION['user_id']."',staff_id='".$valuse."',dates='".$schedule_date1."',strtotime='".$schedule_dateq."',start_time='$dtess',end_time='$end_time',notes='$notes'");
}


}



}


echo '<div class="alert alert-success text-center">Personal bloqueado con éxito</div>';
echo '<script>  window.setTimeout(function () { window.location="index.php"; }, 4000);</script>';


