<?php include ('header.php'); ?>
<!-- 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<div class="add_client_bloc_main">
  <div class="container-fluid">
    <div class="row">
      <div class="col -sm-12">
        <div class="add_client_Model import_clients">  
          <div class="mian_head">
            <h1> 1 </h1>
             <h2>
                Importacion de clientes  
                <span> Sube archivo </span>
             </h2>

          </div>
          <div class="body_block">
            <div class="import_block_data">
              <h5> Supported file formats:</h5>
              <h6> <i class="fa fa-check"></i> XLS, XLSX <span> or </span> CSV </h6>
              <p>El documento debe contener la lista de clientes, uno por fila. Las columnas deben contener los siguientes valores (solo son obligatorios el nombre del cliente y el teléfono o la dirección de correo electrónico): </p>
              <div class="col-sm-12 padder">
                <div class="col-sm-6">
                  <div class="point_main">
                    <p><span> A- </span> Nombre completo </p>
                    <p><span> B- </span> Número de teléfono </p>
                    <p><span> C- </span> Dirección de correo electrónico </p>
                    <p><span> D- </span> Notas</p>
                    <p><span> E- </span> Consentimiento del cliente con respecto a la comunicación de marketing (I-sí / 0 o campo vacío - no)</p>
                    <p><span> F- </span> Género (M. masculino / F- femenino)</p>
                    <p><span> G- </span> Idioma</p>
                    <p><span> H- </span> Año de nacimiento</p>
                    <p><span> I- </span> Mes de nacimiento</p>
                    <p><span> J- </span> Día de nacimiento</p>
                  </div>
                </div>
                <div class="col-sm-6">
                  <div class="chke_block">
                    <p>
                      <b>El Reglamento General de Protección de Datos de la UE (GDPR)</b> requiere que obtenga el consentimiento específico, informado, otorgado libremente y activo de cualquiera de los clientes a los que desea enviar comunicaciones de marketing. Dado que el envío de comunicaciones de marketing sin consentimiento puede dar lugar a penalizaciones, trataremos el consentimiento como negativo, a menos que esté marcado específicamente con "1". Gano más sobre los requisitos de GDPR.
                    </p>
                  </div>
                </div>
              </div> 
                          <form enctype="multipart/form-data" method="post" role="form" id="excelform">

              <div class="col-sm-12 padder">
                <div class="upl-Load_block">
                    <label> Sube archivo con los details de los clientes </label>
                    <div class="file_block">
                      <input type="file"  name="image" id="image" class="filress">
                       
                    </div>
                </div>
              </div>
            </div>
          </div>         

          <div class="col-sm-12">
            <div class="form-group btn_block">
              <div class="col-sm-6 padder">
                <div class="text-left">
                  <button class="cancel"> Cancelar </button>
                </div>
              </div>
              <div class="col-sm-6 padder">
                <div class="text-right">
                  <button class="btn Guardar_button"><i class="fa fa-check"></i>  Guardar </button>
                </div>
              </div>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>
<div id="returndfdg"></div> 

<?php include ('footer.php');?>

 <script type="text/javascript">
   
$(document).ready(function (abc41s) {
 $("#excelform").on('submit',(function(abc41s) {
    $('#loading').show();

  $("#form_abc1_img").show();
  abc41s.preventDefault();
  $.ajax({
   url: "php/importclient.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
                $('#loading').hide();

     $("#form_abc1_img").hide();
   $("#returndfdg").show().html(data);
      },
     error: function(){}          
    });

 }));
});

 </script>
