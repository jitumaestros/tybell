<?php include ('header.php');
?>

<style type="text/css">
	.btn-info:not(:disabled):not(.disabled).active, .btn-info:not(:disabled):not(.disabled):active, .show>.btn-info.dropdown-toggle {
		color: #fff;
		background-color: #193f7a;
		border-color: #173a6f;
	}
	.cucstoem-mod li a {
		font-size: 14px;
		color: #1f262d;
		text-transform: capitalize;
		font-weight: 600;
		text-decoration: none;
		display: block;
		padding: 6px 10px;
	}
	.li{

		list-style: none;
		text-decoration: none;
	}
	.dropdown-menu {
		position: absolute;
		top: 100%;
		left: 0;
		z-index: 1000;
		display: none;
		float: left;
		min-width: 10rem;
		padding: 0.5rem 0;
		margin: 0.125rem 0 0;
		font-size: 0.875rem;
		color: #3e5569;
		text-align: left;
		list-style: none;
		background-color: #fff;
		background-clip: padding-box;
		border: 1px solid #e9ecef;
		border-radius: 2px;
	}
	.cucstoem-mod li {
		display: block;
		width: 100%;
		max-width: 100%;
	}

	.cucstoem-mod {
		background: white;
		box-shadow: 1px 1px 6px 1px rgba(0, 0, 0, 0.2);
		padding: 10px 20px;
		list-style: none;
		width: auto;
		white-space: unset;
		overflow: unset;
		min-width: 220px;
		    top: 31px !important;
    right: 0 !important;
    left: unset !important;
		width: 250px;
	}
</style>
<div class="container-fluid">
	<div class="row page-titles">
		<div class="col-md-6 col-8 align-self-center">
			<h3 class="text-themecolor m-b-0 m-t-0">Gestión de reservas.</h3>
			<ol class="breadcrumb">
				<li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
				<li class="breadcrumb-item active"> Gestión de reservas.</li>
			</ol>
		</div>
		<div class="col-md-6 col-4 align-self-center">
			<!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
		</div>
	</div>
	<div class="addsalon">
		
		<div class="table-respnsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<th>S.No.</th>
<!-- 					<th>Salon Name</th>
-->					<th>Nombre del servicio</th>
                    <th>Fecha y hora de programación</th>
                    <th>Orden ref</th>
                     <th>Estado</th>
                    <th>Gestionar</th>
                    </thead>
                    <tbody>

	<?php
	$n='1';

	$bokkd=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' order by id desc");

	while($bkkstatus=mysqli_fetch_array($bokkd)){

		$sln=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bkkstatus['salon_id']."'"));
		$servci1=explode(',', $bkkstatus['service_id']);

		$sernm='';

		foreach ($servci1 as $key => $valuse) {

			$serbn=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$valuse."'"));

//$price +=$serbn['price'];

			if($sernm==''){

				$sernm=$serbn['name'];

			}else{

				$sernm=$sernm.' & '.$serbn['name'];

			}
		}

		?>

		<tr>
			<td><?php echo $n++;?></td>
			<td><?php echo $sernm;?></td>
			<td><?php echo date('D M d Y', $bkkstatus['dates']);?>, <?php echo $bkkstatus['schedule_time'];?> </td>
			<td><?php echo $bkkstatus['order_ref'];?> </td>
<td><?php if($bkkstatus['booking_status']=='1'){ echo "Confirmada";} elseif($bkkstatus['booking_status']=='2'){ echo "Cancelado por el usuario";}elseif($bkkstatus['booking_status']=='4'){ echo "completados";}else{ echo "Pendiente";} ?></td>


			<td>
				<ul class="list-eeee">
					<li class="dropdown dropdown-itemss" style="text-decoration: none;list-style: none">
						<a href="javascript:;" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
							<i class="fa fa-info-circle" aria-hidden="true" style="color: white;"></i>
						</a>
						<ul class="dropdown-menu cucstoem-mod">
							<li><a href="javascript:;" onclick="confirmbooking('<?php echo $bkkstatus['id'];?>');">Confirmar reservaciones</a></li>
							<li><a href="javascript:;" onclick="deletebook('<?php echo $bkkstatus['id'];?>');">Eliminar reservas</a></li>
							<li><a href="edit_reservations.php?id=<?php echo $bkkstatus['id'];?>">Editar reservas</a></li>

							<li><a href="booking_details.php?id=<?php echo $bkkstatus['id']; ?>">Detalles de la reserva</a></li>
<!-- <li><a href="javascript:;" onclick="completeservice('<?php echo $bkkstatus['id'];?>');">Completar reservas</a></li>
 -->
						</ul> 
					</li>
				</ul>

			</td>

		</tr>
		<?php }?>

	</tbody>
</table>
</div>

</div>
</div>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<?php include ('footer.php');?>
<script type="text/javascript">


function confirmbooking(id)
		{
			$.ajax({
				type: "POST",
				url: "confirmbooking.php",
				data: "id="+id,
				success: function(html)
				{     
					$("#selectjobsds").html(html);

					$('#myModaldele').modal('show');

				}


			});

		}


function completeservice(id)
		{
			$.ajax({
				type: "POST",
				url: "completeserviceform.php",
				data: "id="+id,
				success: function(html)
				{     
					$("#selectjobsds").html(html);

					$('#myModalfdd').modal('show');

				}


			});

		}


	function deletebook(id)
		{
			$.ajax({
				type: "POST",
				url: "deletebookconfimation.php",
				data: "id="+id,
				success: function(html)
				{     
					$("#selectjobsds").html(html);

					$('#myModaldele').modal('show');

				}


			});

		}


</script>
	<div id="selectjobsds"></div>

