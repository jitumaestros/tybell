<?php include ('header.php'); ?>
<!-- 
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css"> -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<div class="Clientes_table_main">
  <div class="container-fluid">
    <div class="row">
      <div class="col -sm-12">
        <div class="Clientes_table_block">
          <div class="col-sm-12 padder">
            <div class="table-responsive"> 
                <table class="table table-bordered" id="datatable">
                  <thead>
                    <tr>
                 <th>S.no</th>
                      <th> <span> Nombre</span> Apellido</th> 
                      <th> Número de teléfono</th>
                      <th> Correo electronico</th>
                      <th> Opt-in <i class="fa fa-filter"></i></th>
                      <th> Reservas <i class="fa fa-filter"></i></th>
                      <th> Ultima visita <i class="fa fa-filter"></i></th>
                    </tr>
                  </thead>
                  <tbody>
                  <?php 
                    $n='1';
                   $sqlii=mysqli_query($conn,"select * from users where role='0'");
                  while($users=mysqli_fetch_array($sqlii)){
    $book=mysqli_num_rows(mysqli_query($conn,"select * from bookings where user_id='".$users['id']."' and status!='2'"));
    $books=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where user_id='".$users['id']."' and status!='2' order by id desc"));

    $time1a = $books['dates'];

                $time2a =strtotime('now');

                $diffdhgg = $time2a-$time1a;
                date("d H:i:s",$diffdhgg);
                $days = $diffdhgg / 86400;
                $day_explode = explode(".", $days);
                $d = $day_explode[0];

                $hours = '.'.$day_explode[1].'';
                $hour = $hours * 24;
                $hourr = explode(".", $hour);
                $h = $hourr[0];

                $minute = '.'.$hourr[1].'';
                $minutes = $minute * 60;
                $minute = explode(".", $minutes);
                $m = $minute[0];

                $seconds = '.'.$minute[1].'';
                $second = $seconds * 60;
                $s = round($second);


                if($h==1){

                $hr=$h.' hour';
                }

                else{

                $hr=$h.' hours';

                }

                $hour =$da *24+$ha;

                $day =$d;

                $month =$d/30;
                $years =$d/365;

                $week =$d/7;
                $weeks =round($week, 0);

                if($weeks==1){

                $weeksdss=$weeks.' Semana';
                }

                else{

                $weeksdss=$weeks.' Semanas';

                }

                if($day==1){

                $dayd=$day.' día';
                }

                else{

                $dayd=$day.' dias';

                }
                $monthd =round($month, 0);

                $year1 =round($years, 0);

                if($monthd==1){

                $monthddd=$monthd.' mes';
                }

                else{

                $monthddd=$monthd.' meses';

                }

                if($year1==1){

                $year12=$year1.' año';
                }

                else{

                $year12=$year1.' años';

                }

                if($day >='365'){

                $duratingD=$year12;

                }


                else if($day >='30'){

                $duratingD=$monthddd;

                }

                else if($day >= '7'){

                $duratingD=$weeksdss;

                }

                else if($day > '0'){
                $duratingD=$dayd;

                }


                else if($h > '0'){
                $duratingD=$hr;

                }

                else{

                $duratingD=$m.' Min';

                }

                    ?>
                    <tr>

                    <td><?php echo $n++;?></td>
                      <td> <label data-toggle="modal" data-target="#myModal<?php echo $users['id'];?>"><?php echo $users['first_name'].' '.$users['last_name'];?> </label> </td>
                      <td><?php echo $users['phone'];?>   </td>
                      <td> <?php echo $users['email'];?> </td>
                      <td> <span class="check"> <i class="fa fa-check"></i> </span>  </td>
                      <td><?php echo $book;?>  </td>
                    
                      <td>  <?php if($book >'0'){?><?php echo date('d-m-Y',$books['dates']);?> hace <?php echo $duratingD;?>  <?php }?></td> 

                    </tr>


<div id="myModal<?php echo $users['id'];?>" class="modal fade" role="dialog">
  <div class="modal-dialog cliente_pro_information">

    <!-- Modal content-->
    <div class="modal-content ">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <h4 class="modal-title">Cliente</h4>
      </div>
      <div class="modal-body">
        <div class="information_block">
          <div class="col-sm-12 padder">
            <div class="col-sm-2 padder">
              <div class="profile-Block">
              <?php if($users['image']!=''){?>
                <img src="../../img/<?php echo $users['image'];?>" class="imger">
                <?php }else{?>
                 <img src="https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png" class="imger"><?php }?>
              </div>
            </div>

            <div class="col-sm-10 padder-right">
              <div class="information_block_right">
                <div class="col-sm-6 padder-left">
                  <div class="personal_ifno">
                    <h3><?php echo $users['first_name'].' '.$users['last_name'];?> <span>  Modificar datos </span></h3>
                    <p class="cls"> Cliente principal Connect </p>
                    <div class="tele_fono">
                      <label>Telefono  </label>
                      <p> <?php echo $users['phone'];?> </p>
                    </div>
                    <div class="tele_fono">
                      <label> Email  </label>
                      <p> <?php echo $users['email'];?> </p>
                    </div>
                    <p class="accept_rec"> <i class="fa fa-check"></i> Acepta recibir correos promocionoles  </p>  
                  </div>
                </div>

                <div class="col-sm-6 padder-left">
                  <div class="personal_ifno_deatils">
                     <p>
                       iSolo pagaras un 2% de gastos de gestion la proxima vez que este cliente reserve! Esto se aplica a clientes habitules a traves de Treatwell y el widget de reserva. <br><br>
                       Si quieres tener mas intormacion sobre el modelo de precios de Treatwell, sigue nuestra guia aqui. <a href="#"> Mas informacion</a>
                     </p>
                  </div>
                </div>
              </div>
            </div>
          </div>


          <div class="col-sm-12 padder">
            <div class="tab_infor_block">
              <ul class="nav nav-tabs">
    
                <li class="active"><a data-toggle="pill" href="#home<?php echo $users['id'];?>">Historial <span>0 </span> </a></li>
                <li><a data-toggle="pill" href="#menu1<?php echo $users['id'];?>">Detalles</a></li> 
              </ul>

              <div class="tab-content">
                <div id="home<?php echo $users['id'];?>" class="tab-pane fade in active">
                  <div class="Historial_detals">
                    <h3>nada aqui</h3> 
                  </div>
                </div>
                <div id="menu1<?php echo $users['id'];?>" class="tab-pane fade">
                  <div class="Detalles_blocks">
                    <div class="col-sm-6 padder-left">
                      <div class="genero_blocks">
                        <h4>
                          <i class="fa fa-venus-mars"></i>
                          Genero
                        </h4>
                        <p>
                    <?php if($users['gender']=='1'){ echo "Mujer";}else{ echo "Hombre";}?>
                         </p>
                      </div>

                      <div class="genero_blocks">
                        <h4>
                          <i class="fa fa-birthday-cake"></i>
                          Cumpleanos
                        </h4>
                        <p>
                         <?php echo $users['dob'];?>
                        </p>
                      </div>
                    </div>


                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div> 
    </div>
  </div>
</div>



                    <?php }?>





                  </tbody>
                </table>
            </div>
          </div>
          <div class="col-sm-12 padder">
            <div class="tabl_bottom_cation">
              <br>
              <div class="col-sm-6 padder-left">
                  <span class="to_row"> 10 total </span>
                  <a href="javascript:;" class="send_mails" onclick="sendemails(id);"> <i class="fa fa-envelope-o"></i> Mandar correo electronico </a>
              </div>
              <div class="col-sm-6 padder-right">
                <div class="btn_block">
                  <div class="col-sm-6"> </div>
                  <div class="col-sm-6 padder-right">
                    <div class="col-sm-6">
                     <a href="tcpdf/tcpdf/examples/client.php"> <button class="btn btn-default btn-Exportar"> <i class="fa fa-upload"></i>   Exportar </button></a>
                    </div>
                    <div class="col-sm-6">
                      <div class="dropdown">
                        <button class="btn btn-default btn-Exportar dropdown-toggle" type="button" data-toggle="dropdown">
                           <i class="fa fa-plus"></i>  Anadir 
                        </button>
                        <ul class="dropdown-menu Exportar_block">
                          <li><a href="add_clientes.php"> <i class="fa fa-plus"></i> Anadir nuevo cliente </a></li>
                          <li><a href="import_clientes.php"> <i class="fa fa-plus"></i> Importar desde fichero </a></li>                       
                        </ul>
                      </div> 
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>



      </div>
    </div>
  </div>
</div>


  
  <div class="Compose_Mail_block" id="shosendhtml" style="display: none"> 
    <div class="mail_header">
      <button type="button" class="close" onclick="mailsclose()">&times;</button>
      <h4 class="modal-title">Compose mail</h4>
    </div>
    <div class="mailing_body">
      <div class="top_heade">
        <h2> Send s to customers in the list  </h2>
        <p> <label> View <a href="#"> Mailing tips and tricks  </a> </label> </p>
      </div>
<form method="post" enctype="multipart/form-data" id="sendemail">
      <div class="body_inspacrtion">
        <div class="input-group">
          <span class="input-group-addon">
            <label> New Mail</label>
          </span>
          <input type="text" name="email" class="form-control">
        </div>


        <div class="body_inspacrtion_details">
          <div class="form-group">
            <div class="col-sm-12 padder">
              <div class="col-sm-5">
                <label> Email Subject </label>
              </div>
              <div class="col-sm-7">
                <input type="text" name="subject" class="form-control" placeholder="More ways you can book with us ">
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="col-sm-12 padder">
              <div class="col-sm-5">
                <label> Venue logo  </label>
              </div>
              <div class="col-sm-7">
                <div class="cust_cherck">
                  <input type="checkbox" name="venue_logo" value="1"> 
                  <div class="cust_text">
                    <label> Show logo in the header of the email </label>
                    <p> Venue Primary image will be used to chnage it. go to <a href="#"> Venue details </a> </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="col-sm-12 padder">
              <div class="col-sm-5">
                <label> Title(Email header) </label>
              </div>
              <div class="col-sm-7">
                <input type="text" name="title" class="form-control" placeholder="More ways you can book with us ">
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="col-sm-12 padder">
              <div class="col-sm-5">
                <label> Message Body </label>
              </div>
              <div class="col-sm-7">
                <textarea cols="4" rows="5" placeholder="" class="text_bloxk" name="description"></textarea>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="col-sm-12 padder">
              <div class="col-sm-5">
                <label>Booking button links to  </label>
              </div>
              <div class="col-sm-7">
                <label>
                  <input type="radio" name="booking_links" value="Venue page on Tybell"> Venue page on Tybell
                </label>

                <label>
                  <input type="radio" name="booking_links" value="Tybell booking widget"> Tybell booking widget
                </label>
              </div>
            </div>
          </div>

          <div class="form-group">
            <div class="col-sm-12 padder">
              <div class="col-sm-5">
                <label> Footer(Signature) </label>
              </div>
              <div class="col-sm-7">
                <textarea cols="3" rows="3" class="text_block1" name="footer">
                  
                </textarea>
              </div>
            </div>
          </div>
      </div>
    </div>

    <div class="mailing_footer">
      <div class="col-sm-6 padder">
        <div class="text-left"> 
          <button class="cancel"> Cancel  </button>
        </div>
      </div>

      <div class="col-sm-6 padder">
        <div class="text-right">
          <button class="send_mail" name="submit" type="submit">  Process and send  </button>
        </div>
      </div> 
    </div>
    </form>
    <div id="returndfdg"></div>
  </div>
</div>


<?php include ('footer.php');?>

<script type="text/javascript">
  
  function sendemails(id){
    $("#shosendhtml").show();
  }


  function mailsclose(){
    $("#shosendhtml").hide();
  }

</script>
 
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/dt-1.10.15/datatables.min.css"/>

<script type="text/javascript" src="https://cdn.datatables.net/v/dt/dt-1.10.15/datatables.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
$('#datatable').DataTable( {

} );
} );


   
$(document).ready(function (abc41s) {
 $("#sendemail").on('submit',(function(abc41s) {
    $('#loading').show();

  $("#form_abc1_img").show();
  abc41s.preventDefault();
  $.ajax({
   url: "php/sendemailclient.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
                $('#loading').hide();

     $("#form_abc1_img").hide();
   $("#returndfdg").show().html(data);
      },
     error: function(){}          
    });

 }));
});

 </script>


