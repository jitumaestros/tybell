<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Dashboard about the services analysis</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Dashboard about the services analysis</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		<div class="input-group">
            <input type="text" class="form-control" placeholder="Type of service" name="">
            <input type="text" class="form-control" placeholder="Schedule" name="">
            <input type="text" class="form-control" placeholder="Location" name="">
            <input type="text" class="form-control" placeholder="Price range" name="">
            <input type="text" class="form-control" placeholder="By salon" name="">
            <span class="input-group-addon">Search</span>
        </div>
		<div class="table-responsive m-t-40">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<tr>
											
						<th>Bookings</th>
						<th>Income</th>
					</tr>
					
				</thead>
				<tbody>
					<tr>
						<td>200</td>
						<td>$2000</td>
						
						
					</tr>
				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>