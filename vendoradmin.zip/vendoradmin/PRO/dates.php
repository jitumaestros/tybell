<?php include('../../common/config.php');

$dates=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' group by schedule_date ");
?>

<script type="text/javascript">
window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
    {
      title:{
        text: "Simple Date-Time Chart"
    },
    axisX:{
        title: "timeline",
    },
    axisY: {
        title: "Downloads"
    },
    data: [
    {        
        type: "line",
        dataPoints: [

        <?php 
          while($sales=mysqli_fetch_array($dates)){

            $countss='';
            $sqliid=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' and schedule_date='".$sales['schedule_date']."'");
            
            
            while ($saless=mysqli_fetch_array($sqliid)){

                $countss +=$saless['total_amount'];

            }


$ndate=strtotime($sales['schedule_date']);
            $day=date('d',$ndate);

            $month=date('m',$ndate);

            $year=date('Y',$ndate);

            $fnal=$year.'-'.$month.'-'.$day;
            $fnlk=date('M',$ndate);

            ?>
            //array
            { label: "<?php echo $fnal;?>",  y: <?php echo $countss;?>  },
        
        <?php }?>

        ]
    }
    ]
});

    chart.render();
}
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</head>
<body>
<div id="chartContainer" style="height: 300px; width: 100%;">
</div>

    <div class="col-sm-6 padder-right">
                    <div class="service_bock">
                        <h2>Top services</h2>                       
                        <table class="table">
                            <tr>
                                <th> By number of bookings   </th>
                                <th>This month </th>
                                <th> Last month   </th>
                            </tr>
<?php 

$ndated=strtotime('now');
    $dd=date('m',$ndated);

$latsm= date('m', strtotime('last month'));
  $return_arrre=array(); 

$sqlii=mysqli_query($conn,"select * from requested_service where salon_id='".$_SESSION['user_id']."' group by service_id");

while($iJobsg=mysqli_fetch_array($sqlii)){

        array_push($return_arrre,$iJobsg);


}   
foreach ($return_arrre as $key => $row) {

$servicecounts=mysqli_num_rows(mysqli_query($conn,"select * from requested_service where service_id='".$row['service_id']."' and month='$dd'"));
 


    $volume[$key]  = $servicecounts;
    
     }

array_multisort($volume, SORT_DESC,  $return_arrre);


foreach ($return_arrre as $key => $reservice) {



$service=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$reservice['service_id']."'"));


$servicecount=mysqli_num_rows(mysqli_query($conn,"select * from requested_service where service_id='".$reservice['service_id']."' and month='$dd'"));

$servicecountl=mysqli_num_rows(mysqli_query($conn,"select * from requested_service where service_id='".$reservice['service_id']."' and month='$latsm'"));


                        ?>
                            <tr>
                                <td> <?php echo $service['name'];?>  </td>
                                <td>  <?php echo $servicecount;?></td>
                                <td>  <?php echo $servicecountl;?></td>
                            </tr>
                            <?php }?>


        

                        </table>
                    </div>

                    <div class="service_bock">
                        <h2> Top Employees </h2>                        
                        <table class="table">
                            <tr>
                                <th> by TTV   </th>
                                <th>This month </th>
                                <th> Last month   </th>
                            </tr>
<?php 

$ndated=strtotime('now');
    $dd=date('m',$ndated);

$latsm= date('m', strtotime('last month'));
  $return_arrrea=array(); 

$sqliwi=mysqli_query($conn,"select * from Top_employe where salon_id='".$_SESSION['user_id']."' group by employe_id");

while($iJobsgs=mysqli_fetch_array($sqliwi)){

        array_push($return_arrrea,$iJobsgs);


}   
foreach ($return_arrrea as $key => $row) {

$servicecounts=mysqli_num_rows(mysqli_query($conn,"select * from Top_employe where employe_id='".$row['employe_id']."' and month='$dd'"));
 


    $volume[$key]  = $servicecounts;
    
     }

array_multisort($volume, SORT_DESC,  $return_arrrea);


foreach ($return_arrrea as $key => $reservices) {



$services=mysqli_fetch_array(mysqli_query($conn,"select * from staff where id='".$reservices['employe_id']."'"));


$servicecountss=mysqli_num_rows(mysqli_query($conn,"select * from Top_employe where employe_id='".$reservices['employe_id']."' and month='$dd'"));

$servicecountls=mysqli_num_rows(mysqli_query($conn,"select * from Top_employe where employe_id='".$reservices['employe_id']."' and month='$latsm'"));
?>

                            <tr>
                                <td> <?php echo $services['name'];?>  </td>
                                <td>  <?php echo $servicecountss;?> </td>
                                <td>  <?php echo $servicecountls;?> </td>
                            </tr>

<?php }?>
                        

                        
                        </table>
                    </div>

                </div>