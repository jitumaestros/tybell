<?php 
@session_start();
global $conn;
$conn = mysqli_connect("localhost", "incarhlt_tybell", "123456");
if(!$conn)
{
  echo "Coudnt find the connection".mysqli_error($conn);  
}
else
{
mysqli_select_db($conn,'incarhlt_tybell');
}





?>