<?php include ('header.php');

if (isset($_GET['deleteid'])) {
mysqli_query($conn,"delete from service where id='".$_GET['deleteid']."'");

	echo"<script>alert('Borrado exitosamente');window.location='service.php';</script>";
}


?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0"> Servicios mas solicitados</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active"> Servicios mas solicitados</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		
		<div class="table-respnsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<th>S.No.</th>
					<th>Nombre</th>
					<th>Precio</th>	
					<th>Material usado</th>

					<th>Estilista</th>
					<th>Mas solicitado</th>

					<th colspan="2"></th>
				</thead>
				<tbody>

				<?php $n='1';
$return_arrre=array(); 

$bokkd=mysqli_query($conn,"select * from requested_service where salon_id='".$_SESSION['user_id']."' group by service_id");

	while($iJobsg=mysqli_fetch_array($bokkd)){


  array_push($return_arrre,$iJobsg);

  }

 foreach ($return_arrre as $key => $row) {

$countsa=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM requested_service where service_id='".$row['service_id']."' "));

   $volume[$key]  = $countsa;

 }

 array_multisort($volume, SORT_DESC,  $return_arrre);

 foreach ($return_arrre as $key => $bkkstatus) {



	$sqli=mysqli_query($conn,"select * from service where id='".$bkkstatus['service_id']."'");
$custm=mysqli_fetch_array($sqli);

	

$counts=mysqli_num_rows(mysqli_query($conn,"SELECT * FROM requested_service where service_id='".$bkkstatus['service_id']."' "));



				?>
					<tr>
						<td><?php echo $n++;?></td>
						<td><?php echo $custm['name'];?></td>
						<td><?php echo $custm['price'];?> </td>
						<td><?php echo $custm['used_material'];?> </td>
						<td><?php echo $custm['stylist'];?> </td>
						<td><?php echo $counts;?> </td>

						<td> </td>		
		
					</tr>
					<?php }?>
					<!-- <tr>
						<td>1</td>
						<td>Lorem Ipsum</td>
						<td>Lorem Ipsum is simply dummy text </td>
						<td>1532565t </td>
						<td>abc@gmail.com </td>
						<td>11/2/2016</td>
						<td>11:00 to 10:00</td>
						
						<td><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						<td><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
						
					</tr> -->
				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>