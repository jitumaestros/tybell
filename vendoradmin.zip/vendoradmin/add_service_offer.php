<?php include ('header.php');?>

 <link rel="stylesheet" href="datepicker/pikaday.css">
<div class="container-fluid">

<form method="post" id="addcustm" enctype="multipart/form-data">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">● Definir ofertas

</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">● Definir ofertas
</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
          
        </div>
    </div>
	<div class="addsalon">
	
	

   <h3>Programar*</h3>

 
    <div class="col-sm-6">

      <div class="form-group">
        <label> Fecha de inicio de la oferta*</label>
        <input type="text" class="form-control" placeholder="" name="offer_start_date" id="dater" autocomplete="off" required="required">
      </div>
    </div>


<div class="col-sm-6">
      <div class="form-group">
        <label>Fecha de cierre de la oferta</label>
        <input type="text" class="form-control" placeholder="" name="offer_end_date" id="daters" autocomplete="off" required="required">
      </div>
    </div>

    
    
<h3>Servicio</h3>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Servicio*</label>
				<select class="form-control" placeholder="" name="service_id" required="required">
<option value="">Servicio</option>
<?php $sqliiii=mysqli_query($conn,"select * from service where salon_id ='".$_SESSION['user_id']."'");
while($ser=mysqli_fetch_array($sqliiii)){ ?>

<option value="<?php echo $ser['id'];?>"><?php echo $ser['name'];?></option>
  <?php 
}
?>

        </select>
			</div>
		</div>

		
<div class="col-sm-6">
      <div class="form-group">
        <label>Oferta*</label>
        <input type="text" class="form-control" placeholder="" name="offer" required="required">
      </div>
    </div>
    
		<button class="addsalonbtn" name="submit" type="submit">Añadir servicio ofertas
</button>
		
	</div>
	<div id="datart"></div>
	</form>
</div>
<?php include ('footer.php');?>
    <script src="datepicker/pikaday.js"></script>

<script type="text/javascript">
	
$(document).ready(function (custm) {
 $("#addcustm").on('submit',(function(custm) {
 	   	//alert();

  $("#form_abc1_img").show();
  custm.preventDefault();
  $.ajax({
   url: "php/add_service_offer.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert();
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});



  new Pikaday(
  {
    field: document.getElementById('dater'),
    trigger: document.getElementById('datepicker-button'),
    minDate: new Date(2000, 0, 1),
    ariaLabel: 'Custom label',
    maxDate: new Date(2020, 12, 31),
    yearRange: [2010,2020]

  });



    new Pikaday(
  {
    field: document.getElementById('daters'),
    trigger: document.getElementById('datepicker-button'),
    minDate: new Date(2000, 0, 1),
    ariaLabel: 'Custom label',
    maxDate: new Date(2020, 12, 31),
    yearRange: [2010,2020]

  });
</script>
