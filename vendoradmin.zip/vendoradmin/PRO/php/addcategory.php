<?php include('../../../common/config.php');

extract($_POST);

$counts=mysqli_num_rows(mysqli_query($conn,"select * from category where name='$name'"));
if($counts >0){

echo '<div class="alert alert-danger"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong >Categoría ya existe </strong></div>';

}
else{
$ctn=mysqli_query($conn,"insert into category set name='$name'");
if($ctn){

 echo '<div class="alert alert-success"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong> Categoría añadida con éxito. </strong></div>';

echo  '<script>function auto_refresh(){
       window.location="service.php?service='.$service.'";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

}else{

	 echo '<div class="alert alert-danger"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong > Error </strong></div>';

}
}

?>