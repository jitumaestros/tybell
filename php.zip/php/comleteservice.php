<?php include('../common/config.php');
extract($_POST);
$csnce=mysqli_query($conn,"update bookings set booking_status='4' where id='$id'");

if($csnce){

echo "<strong style='color:green'>Reservas completados exitosamente</strong>";

echo  '<script>function auto_refresh(){
       window.location="feedback.php?id='.$id.'";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

}else{

echo "error..";

}
?>