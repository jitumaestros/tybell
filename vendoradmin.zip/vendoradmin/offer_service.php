<?php include ('header.php');

if (isset($_GET['deleteid'])) {
mysqli_query($conn,"delete from promotion where id='".$_GET['deleteid']."'");

	echo"<script>alert('Borrado exitosamente');window.location='offer_service.php';</script>";
}


?>

<style type="text/css">
    	

    button{

background: #2EDAAA;


    }
    </style>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0"> Definir ofertas
</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active"> Definir ofertas</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
        <a href="add_service_offer.php"><button style=" margin-left: 228px;color: white; width: 47%;border-radius: 5px; height: 39px">Añadir oferta </button></a>
        </div>
    </div>
	<div class="addsalon">
		
		<div class="table-respnsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<th>S.No.</th>
						<th> Fecha de inicio de la oferta</th>
					<th>Fecha de cierre de la oferta</th>
					<th>Service</th>

			 					<th>Oferta</th>
				<th>Editar</th>
				<th>Retirar</th>

					<th colspan="2"></th>
				</thead>
				<tbody>

				<?php $n='1';
				$sqli=mysqli_query($conn,"select * from promotion where salon_id='".$_SESSION['user_id']."' order by id desc");
while($custm=mysqli_fetch_array($sqli)){

	$service=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$custm['service_id']."'"));

				?>
					<tr>
						<td><?php echo $n++;?></td>

				  	   <td><?php echo date('D M d Y ', $custm['offer_start_date']);?></td>
						<td><?php echo date('D M d Y ', $custm['offer_end_date']);?></td>

						<td><?php echo $service['name'];?></td>
						<
						<td><?php echo $custm['offer'];?> %</td>
					
						<td><a href="edit_service_offer.php?id=<?php echo $custm['id'];?>"><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						<td><a href="?deleteid=<?php echo $custm['id']; ?>" onclick="return confirm('Estas seguro que quieres borrarlo');"><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
						
					</tr>
					<?php }?>
					<!-- <tr>
						<td>1</td>
						<td>Lorem Ipsum</td>
						<td>Lorem Ipsum is simply dummy text </td>
						<td>1532565t </td>
						<td>abc@gmail.com </td>
						<td>11/2/2016</td>
						<td>11:00 to 10:00</td>
						
						<td><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						<td><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
						
					</tr> -->
				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>