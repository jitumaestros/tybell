<?php include('../common/config.php');
extract($_POST);

mysqli_query($conn,"delete from comment where id='$id' and post_id='$videoid'");


echo '<div class="alert alert-success"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong >Comentario eliminado con éxito</strong></div>';




echo "<script>function auto_refresh(){

       window.location='blog_deatils.php?id=$videoid';

    }

    var refreshId = setInterval(auto_refresh, 2000);

</script>";


?>

