<?php include ('header.php');
	if($_GET['id']=='1'){
	$blogf=mysqli_fetch_array(mysqli_query($conn,"select * from blog_home where id='".$_GET['id']."'"));
	}else{
	$blogf=mysqli_fetch_array(mysqli_query($conn,"select * from publication where id='".$_GET['id']."'"));
	}
	/*
	$imagef=$blogf['image'];

	$imagelink=$baseurl.$imagef;
	$current_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	$titledata=$titles;*/
?>


<style type="text/css">


</style>


<div class="blog_deatils_wrapper Ds_blog_deatils">
	<div class="container">
		<div class="blog_wrappeer">
	        <div class="col-sm-12">
		        <div class="col-sm-12 padder">
					<div class="page-heading top">
			            <div class="title-box">
			                <div class="line"></div>
			                <h1 class="title"><?php echo $blogf['title'];?></h1>
			            </div>
			            <div class="date"><i><?php echo date('d-m-Y',$blogf['dates']);?> / Editor's picks</i></div>
			        </div>
			    </div>

		        <div class="col-sm-12 padder">
			        <div class="img_div">
			        	<img src="../image/<?php echo $blogf['image'];?>" class="img-responsive img-css">
			        </div>
			    </div>

		        <div class="col-sm-12 padder">
			        <div class="col-sm-8 padder">
			        	<div class="left_blog_1">
			        		<ul class="ds_socail_link">
			        			<li>
			        				<a href="https://www.facebook.com/sharer.php?u=<?php echo $urls; ?>" onclick="window.open(this.href, 'mywin', 'left=20, top=20, width=500, height=500, toolbar=1, resizable=0'); return false;">
			        					<img class="app_icon" src="<?php echo $baseurl; ?>/treatment-files/img/facebook_logo.png">
			        				</a>
			        			</li>
			        			<li>
			        				<a target="_blank" href="https://twitter.com/share?text=<?php echo $blogf['title'];?>&amp;url=<?php echo $urls; ?>">
			        					<img src="img/twitter.png" class="shareiocn">
			        				</a>
			        			</li>
		 						<li>
		 							<a href="https://web.whatsapp.com/?text=" title="Tybell" onclick="window.open('https://web.whatsapp.com/send?text= <?php echo $blogf['title'];?>: ' + encodeURIComponent(document.URL)); return false;">
		                                	<img src="img/whats_up.png" class="imf-cosal" width="50px">
		                    		</a>
		                    	</li>
		                    </ul>
			        		<?php echo $blogf['description'];?>
			        		<!-- <p>By Rachel Spedding</p> -->
							<div class="comment-blog dsr_comment_readmore">
								<div class="contet-blog-2">
									<div class="title-box">
						                <h1 >Comentario</h1>
						    	    	<form method="post" id="addcomnt" enctype="multipart/form-data">
						        		<input type="hidden" name="post_id" value="<?php echo $_GET['id'];?>">

						               	<!--
							               	<div class="col-sm-6">
							                	 <div class="input_box">

												<label>Título:</label>

												<input type="email" placeholder="" class="form-control" name="email" style="width: 100%;">

												</div>
							                </div> -->
							               	<!--  <div class="col-sm-6">
							                	<div class="input_box">

												<label>Imagen:</label>

												<input type="file" placeholder="" class="form-control" name="email" style="width: 100%;">

												</div>
							                </div>
							            -->
						                 
						                <div class="col-sm-12 padder">
						                	<div class="input_box">
		                                    	<label>Comentario <span style="color: red;">*</span>:</label>
												<textarea class="form-control" name="description" id="messageaa"> 
												</textarea>
											</div>
											<button class="get_itbtn" name="submit" type="submit">Enviar </button>
										</div>
										</form>
										<div id="datatickt"></div>
						            </div>
								</div>
							</div>



















							<div class="y_comment_readmore dsr_comment_Section_block">
						 		<div class="dsr_comment_area" id="form_abc1a_data" >
									<?php 
										$cmt=mysqli_query($conn,"select * from comment where post_id='".$_GET['id']."'  order by id desc");
										while ($cmtvi=mysqli_fetch_array($cmt))
										{
										$uscm=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$cmtvi['user_id']."'"));
										$date=strtotime('now');
										$dates=date('Y-m-d',$catvideo['strtotime']);
										
										$time1a = $cmtvi['strtotime'];

										$time2a =strtotime('now');

										$diffdhg = $time2a-$time1a;
										date("d H:i:s",$diffdhg);
										$days = $diffdhg / 86400;
										$day_explode = explode(".", $days);
										$d = $day_explode[0];

										$hours = '.'.$day_explode[1].'';
										$hour = $hours * 24;
										$hourr = explode(".", $hour);
										$h = $hourr[0];

										$minute = '.'.$hourr[1].'';
										$minutes = $minute * 60;
										$minute = explode(".", $minutes);
										$m = $minute[0];

										$seconds = '.'.$minute[1].'';
										$second = $seconds * 60;
										$s = round($second);

										if($h==1){

										$hr=$h.' hour';
										}

										else{

										$hr=$h.' hours';

										}


										$hour =$da *24+$ha;

										$day =$d;

										$month =$d/30;

										$week =$d/7;
										$weeks =round($week, 1);


										if($weeks==1){

										$weeksdss=$weeks.' Week';
										}

										else{

										$weeksdss=$weeks.' Weeks';

										}


										if($day==1){

										$dayd=$day.' day';
										}

										else{

										$dayd=$day.' days';

										}

										$monthd =round($month, 1);

										if($day >='30'){

										$duratingD=$monthd.' Months';

										}

										else if($day >= '7'){

										$duratingD=$weeksdss;

										}

										else if($day > '0'){
										$duratingD=$dayd;

										}

										else if($h > '0'){
										$duratingD=$hr;

										}

										else{

										$duratingD=$m.' Min';

										}

										$replycount=mysqli_num_rows(mysqli_query($conn,"select * from comment_reply where comment_id='".$cmtvi['id']."' and video_id='".$_GET['id']."' "));


										$userddccc=mysqli_num_rows(mysqli_query($conn,"select * from comment where user_id='".$_SESSION['user_id']."' and post_id='".$_GET['id']."' and id='".$cmtvi['id']."'"));





											$likescounts=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$_GET['id']."' and status='0' and comment_id='".$cmtvi['id']."'"));

											$likes=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$_GET['id']."' and status='0' and user_id='".$_SESSION['user_id']."' and comment_id='".$cmtvi['id']."'"));


											$dislikescounts=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$_GET['id']."' and status='1' and comment_id='".$cmtvi['id']."'"));

											$dislikes=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$_GET['id']."' and status='1' and user_id='".$_SESSION['user_id']."' and comment_id='".$cmtvi['id']."'"));
										?>

									<div class="comchat-block" id="deletecommnts<?php echo $cmtvi['id'];?>">		<div class="left">
											<a href="User_profile.php?id=<?php echo $uscm['id'];?>">
												<img src="img/profile.png" class="Profle">
											</a>
										</div>
										<div class="right">
											<div class="col-sm-12 padder">
												<div class="col-sm-10 padder">
													<label class="user_name">
														<?php echo $uscm['first_name'].' '.$uscm['last_name'];?>
														<span> <?php echo $duratingD;?> ago</span>
													</label>
												</div>
												<div class="col-sm-2 padder-right">
													<?php if($userddccc!=''){?> 
												 		<a class="delete" href="javascript:;" onclick="deletecomemnt('<?php echo $cmtvi['id'];?>','<?php echo $_GET['id'];?>');">
												 			<i class="fa fa-trash-o" aria-hidden="true"></i>
												 		</a>
												 	<?php }?>
												</div>
											</div>

										<div class="col-sm-12 padder">
											<p><?php echo $cmtvi['description'];?></p>
											<ul class="reply">
											<li id="likesvid<?php echo $cmtvi['id'];?>">
												<?php if($likes=='0'){?> 
												<a href="javascript:;" onclick="likevdeo('<?php echo $_GET['id'];?>','<?php echo $_SESSION['user_id'];?>','<?php echo $cmtvi['id'];?>');">
													<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
													<?php echo $likescounts;?>
												</a> 
												<?php }else{?> 
												<a  href="javascript:;" onclick="unlikevdeo('<?php echo $_GET['id'];?>','<?php echo $_SESSION['user_id'];?>','<?php echo $cmtvi['id'];?>');">
													<i class="fa fa-thumbs-up" aria-hidden="true"></i>
												<?php echo $likescounts;?>
												</a>
												<?php }?>
											</li>
		 									
		 									<li id="dilikesvid<?php echo $cmtvi['id'];?>">
							                    <?php if($dislikes=='0'){?>
												<a href="javascript:;" onclick="dislikevdeo('<?php echo $_GET['id'];?>','<?php echo $_SESSION['user_id'];?>','<?php echo $cmtvi['id'];?>');">
													<i class="fa fa-thumbs-o-down" aria-hidden="true"></i>
													<?php echo $dislikescounts;?> 
											</a>
											<?php }else{?>
											<a href="javascript:;" onclick="undislikevdeo('<?php echo $_GET['id'];?>','<?php echo $_SESSION['user_id'];?>','<?php echo $cmtvi['id'];?>');">
													<i class="fa fa-thumbs-down" aria-hidden="true"></i>
												<?php echo $dislikescounts;?> 
											</a>
											<?php }?>
											</li>
											</ul>
											<div class="col-sm-12 padder">
												<div class="recomment">
													<div id="replycmt<?php echo $cmtvi['id'];?>"></div>
												</div>
											</div>
											
											<div class="col-sm-12 padder">
												<div id="VIRWSreplycmt<?php echo $cmtvi['id'];?>"></div>
											</div>
										</div>
									</div>
								</div>
							<?php }?>	
							</div></div>

			        	</div>

			        </div>

	    <!--      <div class="col-sm-4">

	        	<div class="article-item item_default margin_top">

	                <div class="blog_thumb" style="min-height: 360px;">

	                    <div class="page-title-top editors-pick">

	                        <div class="post_category_name">Editor's picks</div>

	                    </div>

	                    <img src="img/mum-feature.jpg" >

	                 </div>

	                <div class="article-content dotdot">

	                    <span class="title">9 mum-friendly salons you (and the kids) should visit this year</span>

	                    <span class="date"><i>25/03/2019</i></span>

	                    <p class="is-truncated" style="overflow-wrap: break-word;">Relaxation and small child – two phrases not often paired together. Good news, we’re... </p>

	                    <span class="read-more">Read more</span>

	                </div>

	            </div>

	        </div>
 -->


		</div>
		</div>

	</div>

</div>

<?php include ('footer.php');?>

<script type="text/javascript">
	
  $(document).ready(function (adcnt) {
  $("#addcomnt").on('submit',(function(adcnt) {

 	$("#form_abc1_img").show();
 	adcnt.preventDefault();
 	$.ajax({
 		url: "php/add_comment.php",
 		type: "POST",
 		data:  new FormData(this),
 		contentType: false,
 		cache: false,
 		processData:false,
 		success: function(data){
 			$("#form_abc1_img").hide();
 $("#form_abc1a_data").show().html(data);
 		document.getElementById("messageaa").value = "";

},
error: function(){}          
});

 }));
	});

  function likevdeo(id,user_id,comment_id){
		

if(user_id==''){


	window.location="<?php echo $baseurl;?>login.php?loginid="+id;

}else{

	$.ajax({
		type: "POST",
		url: "php/likevdeo.php",
		data: "id="+id+"&user_id="+user_id+"&comment_id="+comment_id, 
		success: function(html)
		{  
			$("#likesvid"+comment_id).html(html);

		}
	});
}


}


function unlikevdeo(id,user_id,comment_id){

if(user_id==''){

	window.location="<?php echo $baseurl;?>login.php?loginid="+id;

}else{

	$.ajax({
		type: "POST",
		url: "php/unlikevdeo.php",
		data: "id="+id+"&user_id="+user_id+"&comment_id="+comment_id, 
		success: function(html)
		{     
			$("#likesvid"+comment_id).html(html);

		}

	});
}

}


function dislikevdeo(id,user_id,comment_id){
   
if(user_id==''){

	window.location="<?php echo $baseurl;?>login.php?loginid="+id;

}else{

	$.ajax({
		type: "POST",
		url: "php/dislikevdeo.php",
		data: "id="+id+"&user_id="+user_id+"&comment_id="+comment_id, 
		success: function(html)
		{

			$("#dilikesvid"+comment_id).html(html);

		}
	});
}

}


function undislikevdeo(id,user_id,comment_id){

if(user_id==''){

	window.location="<?php echo $baseurl;?>signin.php?loginid="+id;

}else{

	$.ajax({
		type: "POST",
		url: "php/undislikevdeo.php",
		data: "id="+id+"&user_id="+user_id+"&comment_id="+comment_id, 
		success: function(html)
		{     


			$("#dilikesvid"+comment_id).html(html);

		}

	});
}

}

function deletecomemnt(id,videoid){

	$.ajax({
		type: "POST",
		url: "deletecomment.php",
		data: "id="+id+"&videoid="+videoid, 
		success: function(html)
		{ 
			$("#deletecommnts"+id).html(html);

		}
	});
}

</script>
