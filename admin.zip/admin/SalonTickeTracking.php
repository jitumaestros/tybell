<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Salon Ticket Tracking</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Salon Ticket Tracking</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Salon</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>General Manager Name</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Phone Manager Name</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Email Manager Name</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Incident</label>
				<select class="form-control">
					<option>Type</option>
					<option>Platform</option>
					<option>Payment</option>
					<option>Others</option>
				</select>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Detail</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Date of ticket creation </label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Tybell HelpDesk assigned</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>Actual Status</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		
		
		
		<button class="addsalonbtn">Salon Ticket Tracking</button>
		
		
		
		
		

	</div>

</div>
<?php include ('footer.php');?>