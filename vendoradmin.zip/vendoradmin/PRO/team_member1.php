<?php include ('header.php');?>
<div class="team_member_blog">
	<div class="team-wrapper">
		<button class="btn btn-default">Active</button>
		<a href="team_member_from.php"><button class="addmenber" >+ Add team member</button></a>
		<div class="show_team_memeber">

			<div class="usetr_blog">
				
				<div class="img_blog">
					<div class="team_member-img_blog">
						<img src="img/images.jpg">
					</div>
				</div>
				<div class="team_member_content">
					<span class="pull-right" style="color: #6BBE4A;"><i class="fa fa-circle"></i> &nbsp;Provides Services</span>
					<h2 class="team-name">Mrs. Owner</h2>
					<p class="team-post">Director</p>
					<span class="btn btn-default">Owner</span>
					<span  class="addmenber pull-unset">Can log in</span>
				</div>
			</div>
			<div class="usetr_blog">
				
				<div class="img_blog">
					<div class="team_member-img_blog">
						<img src="img/images.jpg">
					</div>
				</div>
				<div class="team_member_content">
					<span class="pull-right" style="color: #6BBE4A;"><i class="fa fa-circle"></i> &nbsp;Provides Services</span>
					<h2 class="team-name">Mrs. Owner</h2>
					<p class="team-post">Director</p>
					<span class="btn btn-default">Owner</span>
					<span  class="addmenber pull-unset">Can log in</span>
				</div>
			</div>
		</div>
	</div>
</div>











<?php include ('footer.php');?>