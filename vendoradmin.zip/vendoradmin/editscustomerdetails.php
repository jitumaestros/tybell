<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Edit customers Details</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Edit customers Details</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		<div class="salon_img_div" style="background: url('img/capello-salon-naranpura-ahmedabad-beauty-spas-1ynrr6n.jpg');">
			<input type="file" class="choosefile" name="">
			
		</div>
		
		<div class="col-sm-12">
			<div class="form-group">
				<label>Vendor Name</label>
				<input type="text" class="form-control" placeholder="" name="" value="Lorem Ipsum">
			</div>
		</div>

		<div class="col-sm-12">
			<div class="form-group">
				<label>customers Name</label>
				<input type="text" class="form-control" placeholder="" name="" value="Lorem Ipsum">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>Upload file</label>
				<input type="file" class="form-control" placeholder="" name="" value="Lorem Ipsum">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>customers Address</label>
				<input type="text" class="form-control" placeholder="" name="" value="Lorem Ipsum is simply dummy text">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>Mobile Number</label>
				<input type="text" class="form-control" placeholder="" name="" value="1532565t">
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>customers Email Address</label>
				<input type="text" class="form-control" placeholder="" name="" value="abc@gmail.com">
			</div>
		</div>
		
		
		
		
		<button class="addsalonbtn">Save</button>
		

	</div>
</div>
<?php include ('footer.php');?>