<?php include('../../common/config.php');

 extract($_POST);

$strtotime=strtotime('now');

       $description1 = mysqli_real_escape_string($conn,$description);
$image=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], "../../image/$image");
if(!empty($_FILES['image']['name'])){


	$check= mysqli_query($conn,"update publication set image='$image', title='$title', description='$description1', dates='$strtotime' where id='".$ids."'");

}else{
$check= mysqli_query($conn,"update publication set title='$title', description='$description1', dates='$strtotime' where id='".$ids."'");



}

 $insert_id= mysqli_insert_id($conn);

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Publicación Editado con éxito</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="publication.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 


?>