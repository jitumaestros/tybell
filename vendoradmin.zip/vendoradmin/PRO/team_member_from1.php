<?php include ('header.php');?>
  <div class="team_member_from">
		<div class="">  			
			<div class="team_wrapper">
				<div class="tem_add_title">
					Team Member
				</div>
				<div class="col-sm-6">
					<div class="top_team">
						
							<div class="left_tem_img">
								<div class="img_blog_team">
									<img src="img/dummy_icon.png">
									<input type="file" class="choose" name="">
								</div>
							</div>
							<div class="form_div_blog1">
								<div class="form-group add-team-input">
									<input type="text" class="form-control" placeholder="First and last name" name="">
								
										<input type="checkbox" name=""> &nbsp; Provides treatments & services
									
									
								</div>
							</div>
							
					</div>
					<div class="team_from_add">
						<div class="form-group">
							<label><i>Pricing Level</i></label>
							<select class="form-control">
								<option>Default</option>
							</select>
						</div>
						<div class="form-group">
							<label><i>Job title</i></label>
							<input type="text" class="form-control" name="">
						</div>
						<div class="form-group">
							<label><i>Phone</i></label>
							<input type="text" class="form-control" name="">
						</div>
						<div class="form-group">
							<label><i>Gender</i></label>
							<select class="form-control">
								<option>Other / prefer not to disclose</option>
							</select>
						</div>
						<div class="form-group">
							<label>Email Address</label>
							<input type="text" class="form-control" name="">
								<div class="ckechoinpu">
							<input type="checkbox" name=""> &nbsp; Can log in to Dala3 Connect</div>
						</div>
						<div class="form-group">
							<label><i>Pricing</i></label>
							<select class="form-control">
								<option>Stylist/Therapist</option>
							</select>
							<a href="javascript:;" class="ckechoinpu" data-toggle="modal" data-target="#Customise11">Customise Permissions</a>
						</div>
					</div>
					<div class="baout_team">
						<div class="form-group">
							<label><i>About</i></label>
							<textarea class="form-control" cols="4" rows="4"></textarea>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="right_option_blog">
						<div class="right_copunt-blog2">
							<div class="form-group">
								<p><b>What services can be booked for this employee online?</b></p>
								<input type="checkbox" name=""> &nbsp;All services
							</div>
							<div class="form-group">
								<p><b>Hair</b> &nbsp;&nbsp; <a href="">Selectall</a> &nbsp;&nbsp; <a href="">Deselectall</a></p>
								<p><input type="checkbox" name=""> &nbsp;Ladies' haircuts</p>
								<p><input type="checkbox" name=""> &nbsp;Men's Haircuts & Hairdressing</p>
								<p><input type="checkbox" name=""> &nbsp;Children's  Haircut</p>
							</div>
							<div class="form-group">
								<p><b>Polish Maincure & Pedicure</b> &nbsp;&nbsp; <a href="">Selectall</a> &nbsp;&nbsp; <a href="">Deselectall</a></p>
								<p><input type="checkbox" name=""> &nbsp;Maincure</p>
								<p><input type="checkbox" name=""> &nbsp;Pedicure</p>
								<p><input type="checkbox" name=""> &nbsp;Two Week Pedicure</p>
								<p><input type="checkbox" name=""> &nbsp;Two Week Maincure</p>
								<p><input type="checkbox" name=""> &nbsp;Gel Nail Maincure</p>
							</div>
							<div class="form-group">
								<p><b>Massage</b> &nbsp;&nbsp; <a href="">Selectall</a> &nbsp;&nbsp; <a href="">Deselectall</a></p>
								<p><input type="checkbox" name=""> &nbsp;Hot Stone Massage</p>
								<p><input type="checkbox" name=""> &nbsp;Back, Neck & Shoulders Massage</p>
								<p><input type="checkbox" name=""> &nbsp;Foot Massage</p>
								<p><input type="checkbox" name=""> &nbsp;Deep Tissue Massage</p>
							</div>
							<div class="form-group">
								<p><b>Face</b> &nbsp;&nbsp; <a href="">Selectall</a> &nbsp;&nbsp; <a href="">Deselectall</a></p>
								<p><input type="checkbox" name=""> &nbsp;Hot Stone Massage</p>
								<p><input type="checkbox" name=""> &nbsp;Back, Neck & Shoulders Massage</p>
								<p><input type="checkbox" name=""> &nbsp;Foot Massage</p>
								<p><input type="checkbox" name=""> &nbsp;Deep Tissue Massage</p>
							</div>
						</div>
					</div>
				</div>
				
			</div>
		</div>
  </div>
  <!-- Modal -->


  <div class="modal fade" id="Customise11" role="dialog">
    <div class="modal-dialog modal-lg">
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-body1 overflow-h">
        	<div class="tem_add_title">
					Team Member
			</div>
        	 <div class="right_option_blog1">
        	 	<div class="col-sm-6">
        	 		<div class="right_copunt-blog2">
						
						<div class="form-group">
							<p><b>General</b></p>
							<p><input type="checkbox" name=""> &nbsp;View list of bookings</p>
							<p><input type="checkbox" name=""> &nbsp;Manage venue details</p>
							<p><input type="checkbox" name=""> &nbsp;View Finance deatils</p>
							<p><input type="checkbox" name=""> &nbsp;View Sales report</p>
							<p><input type="checkbox" name=""> &nbsp;Can refound transactions</p>
							<p><input type="checkbox" name=""> &nbsp;Can edit service prices in checkout</p>
						</div>
						<div class="form-group">
							<p><b>Menu</b></p>
							<p><input type="checkbox" name=""> &nbsp;View menu</p>
							<p><input type="checkbox" name=""> &nbsp;Edit menu</p>
							
						</div>
						<div class="form-group">
							<p><b>Clients</b></p>
							<p><input type="checkbox" name=""> &nbsp;View Clinet list</p>
							<p><input type="checkbox" name=""> &nbsp;View/ edit client contact details</p>
							
						</div>
						
						
					</div>
        	 	</div>
				<div class="col-sm-6">
					<div class="right_copunt-blog2">
						
						<div class="form-group">
							<p><b>Calendar</b></p>
							<p><input type="checkbox" name=""> &nbsp;Manage own calendar</p>
							<p><input type="checkbox" name=""> &nbsp;View Others' calendar</p>
							<p><input type="checkbox" name=""> &nbsp;Manage Others' calendar</p>
							<p><input type="checkbox" name=""> &nbsp;Can delete appointments</p>
							
						</div>
						<div class="form-group">
							<p><b>Hotel/Spa</b></p>
							<p><input type="checkbox" name=""> &nbsp;Manage Spa Day inventory</p>
							<p><input type="checkbox" name=""> &nbsp;Manage Overnight inventory</p>					
						</div>
						<div class="form-group">
							<p><b>Staff</b></p>
							<p><input type="checkbox" name=""> &nbsp;Add therapists</p>
							<p><input type="checkbox" name=""> &nbsp;Change user permissions</p>
							
						</div>
						
						
					</div>
				</div>
			</div>
			 <div class="col-sm-12 padder">
	        	<div class="modal-footer">
	        		 	<button type="button" class="save_btn" style="background:#6BBE4A; border:1px solid #6BBE4A;color: #fff;">Save</button>
		          	<button type="button" class="save_btn" style="background: #FFFFFF; border:1px solid #ddd;color: #333;" data-dismiss="modal">Close</button> 
		         
		        </div>
	        </div>
        </div>
       
        
      </div>
      
    </div>
  </div>
  
<?php include ('footer.php');?>