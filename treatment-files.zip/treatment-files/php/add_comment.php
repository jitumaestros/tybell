<?php include('../../common/config.php');

  extract($_POST);
if($_SESSION['user_id']==''){

echo "<script>window.location='login.php?loginid=$post_id';</script>";

}
else{

$dates=strtotime('now');


       $description1 = mysqli_real_escape_string($conn,$description);

 $in= mysqli_query($conn,"INSERT INTO comment (user_id, description, strtotime, post_id)VALUES ('".$_SESSION['user_id']."','$description1', '$dates', '$post_id')");

 $insert_id= mysqli_insert_id($conn);

 
    $cmt=mysqli_query($conn,"select * from comment where post_id='".$post_id."' order by id desc");

$ids=mysqli_insert_id($conn);

    if($in)
    {
while($cmtvi=mysqli_fetch_array($cmt)){

							$uscm=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$cmtvi['user_id']."'"));
$time1a = $cmtvi['strtotime'];


            $time2a =strtotime('now');


            $diffdhg = $time2a-$time1a;

            date("d H:i:s",$diffdhg);
    $days = $diffdhg / 86400;
    $day_explode = explode(".", $days);
    $d = $day_explode[0];


    $hours = '.'.$day_explode[1].'';
    $hour = $hours * 24;
    $hourr = explode(".", $hour);
    $h = $hourr[0];
    
    $minute = '.'.$hourr[1].'';
    $minutes = $minute * 60;
    $minute = explode(".", $minutes);
    $m = $minute[0];
    
    $seconds = '.'.$minute[1].'';
    $second = $seconds * 60;
    $s = round($second);



                            if($h==1){

                            $hr=$h.' hour';
                            }

                            else{

                            $hr=$h.' hours';

                            }


                         


                            $hour =$da *24+$ha;

                            $day =$d;

                            $month =$d/30;

                                 $week =$d/7;
                             $weeks =round($week, 1);


                            if($weeks==1){

                            $weeksdss=$weeks.' Week';
                            }

                            else{

                            $weeksdss=$weeks.' Weeks';

                            }


if($day==1){

                            $dayd=$day.' day';
                            }

                            else{

                            $dayd=$day.' days';

                            }





                            $monthd =round($month, 1);

                            if($day >='30'){

                            $duratin=$monthd.' Months';

                            }

                           else if($day >= '7'){

                            $duratin=$weeksdss;

                            }


                            else if($day > '0'){
                            $duratin=$dayd;

                            }
               
                           

                         else if($h > '0'){
                            $duratin=$hr;

                            }


                  


                            else{

                            $duratin=$m.' Min';

                            }
$replycount=mysqli_num_rows(mysqli_query($conn,"select * from comment_reply where comment_id='".$cmtvi['id']."' and video_id='".$_GET['id']."' "));


							$userddccc=mysqli_num_rows(mysqli_query($conn,"select * from comment where user_id='".$_SESSION['user_id']."' and post_id='".$post_id."' and id='".$cmtvi['id']."'"));





								$likescounts=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$post_id."' and status='0' and comment_id='".$cmtvi['id']."'"));

								$likes=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$post_id."' and status='0' and user_id='".$_SESSION['user_id']."' and comment_id='".$cmtvi['id']."'"));


								$dislikescounts=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$post_id."' and status='1' and comment_id='".$cmtvi['id']."'"));

								$dislikes=mysqli_num_rows(mysqli_query($conn,"select * from likes where post_id='".$post_id."' and status='1' and user_id='".$_SESSION['user_id']."' and comment_id='".$cmtvi['id']."'"));
      ?>
	<div class="comchat-block" id="deletecommnts<?php echo $cmtvi['id'];?>">			
							<div class="left">
								<a href="User_profile.php?id=<?php echo $uscm['id'];?>">
									<img src="img/profile.png" class="Profle"  style="width:90px">
								</a>
							</div>
							<div class="right">
								<div class="col-sm-12 padder">
									<div class="col-sm-10 padder">
										<label class="user_name">
											<?php echo $uscm['first_name'].' '.$uscm['last_name'];?>
											<span> <?php echo $duratingD;?> ago</span>
										</label>
									</div>
									<div class="col-sm-2 padder-right">
										<?php if($userddccc!=''){?> 
									 		<a class="delete" href="javascript:;" onclick="deletecomemnt('<?php echo $cmtvi['id'];?>','<?php echo $post_id;?>');">
									 			<i class="fa fa-trash-o" aria-hidden="true"></i>
									 		</a>
									 	<?php }?>
									</div>
								</div>

								<div class="col-sm-12 padder">
									<p><?php echo $cmtvi['description'];?></p>
									<h4 class="reply">
									<li id="likesvid<?php echo $cmtvi['id'];?>">
										<?php if($likes=='0'){?> 
							<a href="javascript:;" onclick="likevdeo('<?php echo $post_id;?>','<?php echo $_SESSION['user_id'];?>','<?php echo $cmtvi['id'];?>');">
									<i class="fa fa-thumbs-o-up" aria-hidden="true"></i>
								<?php echo $likescounts;?>
								</a> 
								<?php }else{?> 
								<a  href="javascript:;" onclick="unlikevdeo('<?php echo $post_id;?>','<?php echo $_SESSION['user_id'];?>','<?php echo $cmtvi['id'];?>');">
									<i class="fa fa-thumbs-up" aria-hidden="true"></i>
								<?php echo $likescounts;?>
								</a>
								<?php }?>
								</li>
 						<li id="dilikesvid<?php echo $cmtvi['id'];?>">

                     <?php if($dislikes=='0'){?>
		
							<a href="javascript:;" onclick="dislikevdeo('<?php echo $post_id;?>','<?php echo $_SESSION['user_id'];?>','<?php echo $cmtvi['id'];?>');">
								<i class="fa fa-thumbs-o-down" aria-hidden="true"></i>
							
							<?php echo $dislikescounts;?> 
							</a>
							<?php }else{?>
		
							<a href="javascript:;" onclick="undislikevdeo('<?php echo $post_id;?>','<?php echo $_SESSION['user_id'];?>','<?php echo $cmtvi['id'];?>');">
								<i class="fa fa-thumbs-down" aria-hidden="true"></i>
							
							<?php echo $dislikescounts;?> 
							</a>
							<?php }?>
</li>
									</h4>
									<div class="col-sm-12 padder">
										<div class="recomment">
											<div id="replycmt<?php echo $cmtvi['id'];?>"></div>
										</div>
									</div>
									
									<div class="col-sm-12 padder">
										<div id="VIRWSreplycmt<?php echo $cmtvi['id'];?>"></div>
									</div>
								</div>
							</div>
						</div><?php } }
 else
 {
 echo"Failed Insert";
   echo mysql_error();
 }
	}	
 ?>


