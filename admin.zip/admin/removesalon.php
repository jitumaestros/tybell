<?php include ('header.php');

if(isset($_GET['deleteid'])){
	mysqli_query($conn,"DELETE FROM `users` WHERE `id`='".$_GET['deleteid']."'");
	echo "<script> window.location='removesalon.php?msg=Delete Sucessful';</script>";


	}
?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Remove Salon</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Remove Salon</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		
		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
<!-- 					<th>S.No.</th>
 -->					<th> Name</th>
					<th> Email</th>
					<th> Password</th>
					<th>District </th>
					<th> Address</th>
					<th>Mobile Number</th>
				     <th>Image</th>
					<th>Action</th>
					<th>Financial Blance</th>

				</thead>
				<tbody>

<?php $saln=mysqli_query($conn,"select * from users where role='2' order by id desc");
$n='1';
while($salnm=mysqli_fetch_array($saln)){
	$district=mysqli_fetch_array(mysqli_query($conn,"select * from district where id='".$salnm['district']."'"));

	$img=explode(',',$salnm['salon_pic']);
?>

					<tr>
<!-- 						<td><?php echo $n++;?></td>
 -->						<td><?php echo $salnm['first_name'].' '.$salnm['last_name'];?></td>
						<td><?php echo $salnm['email'];?> </td>
						<td><?php echo $salnm['password'];?> </td>
						<td><?php echo $district['name'];?> </td>
						<td><?php echo $salnm['adress'];?> </td>
						<td><?php echo $salnm['contact_number'];?> </td>
						<td><img src="../image/<?php echo $img['0'];?>" width="100px" height="100px"></td>
						
						<td><a href="edit_salon.php?edit=<?php echo $salnm['id'];?>"><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button>
						<a href="?deleteid=<?php echo $salnm['id'];?>" onclick="return confirm('Are you sure you want to delete');"><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button>

						</td>
						<td>
						<a href="financial_balance.php?salon_id=<?php echo $salnm['id'];?>"><button type="button" class="btn btn-primary">Patner Fees/Comisión Partner</button></td>
					</tr>
					<?php }?>
					<!-- <tr>
						<td>1</td>
						<td>Lorem Ipsum</td>
						<td>Lorem Ipsum is simply dummy text </td>
						<td>1532565t </td>
						<td>abc@gmail.com </td>
						<td>11/2/2016</td>
						<td>11:00 to 10:00</td>
						
						<td><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						<td><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
						
					</tr> -->
				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>