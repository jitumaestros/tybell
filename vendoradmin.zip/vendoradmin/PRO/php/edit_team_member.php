<?php include('../../../common/config.php');
extract($_POST);

$strtotime=strtotime('now');

$image=$_FILES['image']['name'];
move_uploaded_file($_FILES['image']['tmp_name'], "../../img/".$image);

$category_id1=implode(',', $category_id);
$subcategory_id1=implode(',', $subcategory_id);

if(!empty($_FILES['image']['name'])){
$check= mysqli_query($conn,"update staff set name='$name', mobile='$mobile', email='".$email."',status='$status',pricing_level='$pricing_level',job_title='$job_title',gender='$gender',permissions='$permissions',about='$about',category_id='$category_id1',subcategory_id='$subcategory_id1',profile_pic_path='$image' where id='$ids'");

}
else{
$check= mysqli_query($conn,"update staff set name='$name', mobile='$mobile', email='".$email."',status='$status',pricing_level='$pricing_level',job_title='$job_title',gender='$gender',permissions='$permissions',about='$about',category_id='$category_id1',subcategory_id='$subcategory_id1' where id='$ids'");

}
 $insert_id= mysqli_insert_id($conn);
$ex=explode(',', $permission_name);





foreach ($ex as $key => $value) {

$counts=mysqli_num_rows(mysqli_query($conn,"select * from staff_permission where staff_id='$ids' and name='$value'"));


if($counts >0){
  mysqli_query($conn,"update staff_permission set staff_id='$ids',name='$value' where staff_id='$ids'");


}else{

mysqli_query($conn,"insert into staff_permission set staff_id='$ids',name='$value'");

}
}




 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Team member Edited successfully</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="team_member.php?setting=setting";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

	
}

 


?>