<?php
//============================================================+
// File name   : example_048.php
// Begin       : 2009-03-20
// Last Update : 2013-05-14
//
// Description : Example 048 for TCPDF class
//               HTML tables and table headers
//
// Author: Nicola Asuni
//
// (c) Copyright:
//               Nicola Asuni
//               Tecnick.com LTD
//               www.tecnick.com
//               info@tecnick.com
//============================================================+

/**
 * Creates an example PDF TEST document using TCPDF
 * @package com.tecnick.tcpdf
 * @abstract TCPDF - Example: HTML tables and table headers
 * @author Nicola Asuni
 * @since 2009-03-20
 */

// Include the main TCPDF library (search for installation path).
require_once('tcpdf_include.php');
include('c.php');

$n='1';

$id=$_SESSION['id'];

$jobsid=$_GET['jobsid'];

$order=mysqli_query($conn, "SELECT * FROM expert_request WHERE expert_id='$id' AND id IN ($jobsid)ORDER BY date ASC ");


     while($row1 = mysqli_fetch_array($order)){
     
     $cat=$row1['cat_id'];
        $subcat=$row1['subcat_id'];
        $ex=$row1['expert_id'];

     $cat =mysqli_fetch_array(mysqli_query($conn,"select * from add_category where id='$cat'"));

     $subcst =mysqli_fetch_array(mysqli_query($conn,"select * from add_sub_category where id='$subcat'"));

 $user=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM wp_users WHERE ID='$ex'"));

          $service=mysqli_fetch_array(mysqli_query($conn,"SELECT * FROM `s_request` WHERE `s_id`='".$row1['service_id']."'"));




 
   $lattitude=$row1['lattitude'];
$longitude=$row1['longitude'];


$ur1l = "https://maps.googleapis.com/maps/api/geocode/json?latlng=$lattitude,$longitude&sensor=false&key=AIzaSyCWXNTc_QfM-j_Y43CDAZY0X6jaGiwXgrw&sensor=false&libraries=places";

// Make the HTTP request
$data = @file_get_contents($ur1l);
// Parse the json response
$jsondata = json_decode($data,true);


//print_r($jsondata);

$place1=  $jsondata["results"][0]["formatted_address"];

        
$my_html .= '<tr>

<td>'.$user['type'].'</td>

<td>'.$row1['description'].'</td>
<td>'.$place1.'</td>
<td>'.$cat['cat_name'].'</td>
<td>'.$subcst['sub_category'].'</td>
<td>'.$row1['date'].'</td>

<td><img src="https://experts24hr.com/experts/upload/'.$service['photo'].'" width="140px" height="140px"></td>


 </tr>';
  }



// create new PDF document
$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
$pdf->SetCreator(PDF_CREATOR);
$pdf->SetAuthor('Nicola Asuni');
$pdf->SetTitle('TCPDF Example 048');
$pdf->SetSubject('TCPDF Tutorial');
$pdf->SetKeywords('TCPDF, PDF, example, test, guide');

// set default header data
/*$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, PDF_HEADER_TITLE.' 048', PDF_HEADER_STRING);
*/
// set header and footer fonts
$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

// set margins
$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

// set auto page breaks
$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

// set image scale factor
$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

// set some language-dependent strings (optional)
if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
  require_once(dirname(__FILE__).'/lang/eng.php');
  $pdf->setLanguageArray($l);
}

// ---------------------------------------------------------

// set font
$pdf->SetFont('helvetica', 'B', 20);

// add a page
$pdf->AddPage();

$pdf->Write(0, 'Experts24HR.com 
Job Invoices', '', 0, 'L', true, 0, false, false, 0);



$pdf->SetFont('helvetica', '', 8);

// -----------------------------------------------------------------------------


// -----------------------------------------------------------------------------

// NON-BREAKING TABLE (nobr="true")



// -----------------------------------------------------------------------------

// NON-BREAKING ROWS (nobr="true")

$tbl =<<<EOD
<table border="1" align="center">
      

 <tr>
 
 
 
  <th>Title</th>
 
  <th>Description</th>
  <th>Address</th>

  <th>Category</th>
  <th>Subcategory</th>
  
   <th>DATE</th>
  <th>Image</th>

</tr>

$my_html

</table>
EOD;

$pdf->writeHTML($tbl, true, false, false, false, '');

// -----------------------------------------------------------------------------

//Close and output PDF document
//$pdf->Output('example_048.pdf', 'I');
$pdf->Output('all_jobs.pdf', 'D');


//============================================================+
// END OF FILE
//============================================================+
