<?php include ('header.php');?>
<div class="upload_list">
	 <div class="upload_list_blog">
	 	
	 	<div class="client_btn">
	 		<div class="serah_box">
		 		<div class="input-group">			   
				    <input  type="text" class="form-control" placeholder="Search...">
				     <span class="input-group-addon"><i class="fa fa-search"></i></span>
				 </div>
		 	</div>
	 		<button class="btn btn-default"><i class="fa fa-upload"></i> &nbsp; Export</button>
	 		<span class="dropdown">
	 			<button class="btn btn-default dropdown-toggle"  data-toggle="dropdown" aria-expanded="true" ><i class="fa fa-plus"></i> &nbsp; Add</button>
	 			<ul class="dropdown-menu drop_menu_1">
                     	<li><a href="javascript:;" data-toggle="modal" data-target="#addclient"><i class="fa fa-plus"></i> &nbsp; Add new client</a></li>
	 					<li><a href="javascript:;" data-toggle="modal" data-target="#myModal"><i class="fa fa-level-down"></i>  &nbsp; Import from file</a></li>
                    </ul>              
	 		</span>
	 	
	 		
	 	</div>
	 	<div class="table-responsive">
	 		<table class="table table-bordered table-hover">
	 			<thead>
	 				<tr>
	 					<th>First name</th>
	 					<th>Last name</th>
	 					<th>Phone</th>
	 					<th>Email</th>
	 					<th>Opt-in</th>
	 					<th>Bookings</th>
	 					<th>Last Visit</th>
	 				</tr>
	 			</thead>
	 		</table>
	 	</div>
	 </div>
</div>




<!-- add file  Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
        
        <div class="modal-body111">
         	<div class="exprt_file">
         		<span class="clent-num">1</span>
         		<h1>Client import </h1>
         		<p>Upload file</p>
         	</div>
         	<div class="upload_file">
         		<p>Supported file formats :</p>
         		<p><span style="color: #A9B643;"><i class="fa fa-check"></i></span> &nbsp; <b>XLS, XLSX or CSV</b> </p>
         		<p>The document must contain the list of customer, one per row. Columns should contain the following values (only client name and either phone or email address are mandatroy):</p>
         		<div class="col-sm-6 padder">
         			<div class="filt-uploadleft-blog">
         				<ul>
         					<li><b>A</b> - Full name</li> 
         					<li><b>B</b> - Phone number </li>
         					<li><b>C</b> - Email address </li>
         					<li><b>D</b> - Notes</li> 
         					<li><b>E</b> - Client's consent regarding marketing communication (I- yes / 0 or empty field - no) </li>
         					<li><b>F</b> - Gender (M - male / F- female) </li>
         					<li><b>G</b> - Language </li>
         					<li><b>H</b> - Birth year</li> 
         					<li><b>I</b> - Birth month</li> 
         					<li><b>J</b> - Birth day </li>
         				</ul>
         			</div>
         		</div>
         		<div class="col-sm-6">
         			<div class="file_content_right_blog">
         				<p><b>EU General Data Protection Regulation (GDPR)</b> requires you to obtain specific, informed, freely given and active consent from any of the customers you want to send marketing communication to. Since sending marketing communication without a consent may result in penalties, we'll treat consent as negative, unless it's specifically marked by "1".<a href="">Learn more about GDPR requirements.</a>   </p>
         			</div>
         		</div>
         	</div>

         	<div class="file_upload_blog_bottom">
         		<p><b>Please upload file with customer details</b></p>
         		<div class="form-group">
         			<input type="file" class="form-control" name="">
         		</div>
         	</div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-default" >Continue &nbsp; <i class="fa fa-caret-right"></i></button>
        </div>
      </div>
      
    </div>
  </div>




  <!-- add client  Modal -->

 <!-- Modal -->
  <div class="modal fade" id="addclient" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content overflow-h">
        <div class="tem_add_title">
					Client
				</div>
        <div class="modal-body ">
          <div class="col-sm-12">
					<div class="team_from_add">
						<div class="form-group">
							<label>Name</label>
							<input type="text" class="form-control" name="">
						</div>						
						<div class="form-group">
							<label>Phone</label>
							<input type="text" class="form-control" name="">
						</div>
						
						<div class="form-group">
							<label>Email </label>
							<input type="email" class="form-control" name="">
							<br><br>
								<div class="ckechoinpu">
									<div class="file_content_right_blog">
				         				<p><b>Marketing Communication</b> </p>
				         				<input type="checkbox" name="">
				         					<p>I confirm that I have obtained specific, informed, freely 
												given and active consent from this customer to receive 
												invites to rebook and other marketing emails and SMS 
												from my salon and have a record of this consent.
												<a href="">Learn more about GDPR requirements.</a>   </p>
				         			</div>
								</div>
						</div>
						<div class="form-group">
							<label><i>Gender</i></label>
							<select class="form-control">
								<option>Other / prefer not to disclose</option>
							</select>
						</div>
						<div class="form-group">
							<label><i>Birthday</i></label>
							<select class="form-control">
								<option>Month</option>
							</select><br><br>
							<div class="ckechoinpu">
								<input type="text" placeholder="Day" class="form-control" name=""> &nbsp;&nbsp;
								<a href="">Set year</a>
							</div>
							
						</div>
					</div>
					<div class="baout_team">
						<div class="form-group">
							<label><i>Notes</i></label>
							<textarea class="form-control" cols="4" rows="4"></textarea>
						</div>
					</div>
				</div>
        </div>
        <div class="col-sm-12 padder">
	        <div class="modal-footer">
	        	
	         <button type="button" class="save_btn" style="background:#6BBE4A; border:1px solid #6BBE4A;color: #fff;">Save</button>
	          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
	        </div>
	    </div>
      </div>
      
    </div>
  </div>
  



<?php include ('footer.php');?>