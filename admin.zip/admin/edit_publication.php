<?php include ('header.php');
$edit=mysqli_fetch_array(mysqli_query($conn,"select * from publication where id='".$_GET['id']."'"));
?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0"> publicación</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active"> publicación</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
         
        </div>
    </div>
    <form method="post" id="addcustm" enctype="multipart/form-data">
    <input type="hidden" name="ids" value="<?php echo $_GET['id'];?>">
	<div class="addsalon">
		<div class="conmment_img_div" >
			<img src="../image/<?php echo $edit['image'];?>" width="100%" class="img-responsive" style="  max-width: 200px;"> 
			<div class="upload_img">
				<button> Imagen</button>
				<input type="file" name="image" value="">
			</div>
			
		</div>
		
		
		<div class="col-sm-12">
			<div class="form-group">
				<label>Título</label>
				<input type="text" class="form-control" name="title" value="<?php echo $edit['title'];?>" >
			</div>
		</div>
		<div class="col-sm-12">
			<div class="form-group">
				<label>Descripción</label>
				<textarea class="form-control" name="description"> <?php echo $edit['description'];?>
				</textarea>
			</div>
		</div>
	

		
		<button class="addsalonbtn" type="submit"> Salvar</button>
		

	</div>
	<div id="datart"></div>
</div>

<?php include ('footer.php');?>

 

<script type="text/javascript">
	
$(document).ready(function (custm) {
 $("#addcustm").on('submit',(function(custm) {
 	  // 	alert();

  $("#form_abc1_img").show();
  custm.preventDefault();
  $.ajax({
   url: "php/edit_publication.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert(data);
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});
</script>


<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>


  <style type="text/css">
      
.mce-notification-warning{

display: none;

}

  </style>