<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Financial balance</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">Financial balance</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
           <a href="add_financial_balance.php?salon_id=<?php echo $_GET['salon_id'];?>" class="btn pull-right hidden-sm-down btn-success">Add Financial balance</a> 
        </div>
    </div>
	<div class="addsalon">
	
		<div class="table-respnsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<th>Title</th>
					<th>Fee </th>
					<th>Action</th>
				</thead>
				<tbody>

<?php $saln=mysqli_query($conn,"select * from financial_balance WHERE salon_id='".$_GET['salon_id']."'");

while($salnm=mysqli_fetch_array($saln)){
?>

					<tr>					
						<td><?php if($salnm['title']=='1'){ echo "Fee for New customers";}else{ echo "Fee for Old Customers";}?> </td>
						<td><?php echo $salnm['fee'];?> %</td>
						
						<td><a href="edit_financial_balance.php?id=<?php echo $salnm['id'];?>&salon_id=<?php echo $_GET['salon_id'];?>"><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						
						
					</tr>
					<?php }?>
					
				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>