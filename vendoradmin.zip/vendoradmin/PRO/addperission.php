<?php extract($_POST);
 $idss=implode(',',$name);

?><input type="" name="permission_name" value="<?php echo $idss;?>">