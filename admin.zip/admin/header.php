<?php include ('../common/config.php');?>
<style type="text/css">
    .slimScrollDiv {
    overflow: auto !important;
}

.scroll-sidebar {
    padding-bottom: 60px;
    padding-top: 30px;
    height: auto !important;
}
</style>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Tybell</title>
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
    <script src="https://unpkg.com/ionicons@4.5.5/dist/ionicons.js"></script> 
</head>

<body class="fix-header fix-sidebar card-no-border">
    
    <div class="preloader">
        <svg class="circular" viewBox="25 25 50 50">
            <circle class="path" cx="50" cy="50" r="20" fill="none" stroke-width="2" stroke-miterlimit="10" /> </svg>
    </div>
    
    <div id="main-wrapper">
        
        <header class="topbar">
            <nav class="navbar top-navbar navbar-toggleable-sm navbar-light">
                
                <div class="navbar-header">
                    <a class="navbar-brand" href="dashboard.php">
                        <!-- Logo icon -->
                        <b>
                        <span style="color: #C12B5C;    font-size: 35px;">Tybell</span>
                        </b>
                        
                        <span>
                        </span>
                    </a>
                </div>
               
                <div class="navbar-collapse">
                    <ul class="navbar-nav mr-auto mt-md-0 ">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="ti-menu"></i></a> </li>
                        <li class="nav-item hidden-sm-down">
                            <form class="app-search p-l-20">
                                <input type="text" class="form-control" placeholder="Search for..."> <a class="srh-btn"><i class="ti-search"></i></a>
                            </form>
                        </li>
                    </ul>
                    
                    <ul class="navbar-nav my-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle text-muted waves-effect waves-dark" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><img src="assets/images/users/1.jpg" alt="user" class="profile-pic m-r-5" />Markarn Doe</a>
                        </li>
                         <li class="nav-item dropdown">
                            <a href="logout.php" class="nav-link dropdown-toggle text-muted waves-effect waves-dark " style="color: #fff;"><ion-icon name="power"></ion-icon></a>
                        </li>
                    </ul>
                </div>
            </nav>
        </header>
        
        <aside class="left-sidebar">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul >

                        <li class="active">
                            <a href="dashboard.php" class="waves-effect"><i class="fa fa-clock-o m-r-10" aria-hidden="true"></i>Dashboard</a>
                        </li>

                        <!-- <li >
                            <a href="financial_balance.php" class="waves-effect"><i class="fa fa-clock-o m-r-10" aria-hidden="true"></i>Financial Balance </a>
                        </li> -->
                        
                        <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="cut"></ion-icon></i> Salon management  <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="Addnewsalon.php">Add new salon</a></li>
                                <li><a href="removesalon.php">Remove salons</a></li>
<!--                                 <li><a href="editsalondetails.php">Edit salon information</a></li>
 -->                              </ul>
                        </li>
                         <li class="dropdown">
                            <a href="advertisment_management.php" class="waves-effect  dropdown-toggle" data-toggle="dropdown" ><i class="fa fa-buysellads"></i> Advertising management   <span class="fa fa-angle-down right-errow"></span> </a>
                             <ul class="dropdown-menu menu_drop">
                                <li><a href="Registeradvertising.php">Register advertising</a></li>
                                <li><a href="Executeadvertising.php">Execute advertising</a></li>
                                <li><a href="Analyzeinteractionandeffectiveness.php">Analyze interaction and effectiveness</a></li>
                               
                              </ul> 
                        </li>
                         <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="briefcase"></ion-icon></i>Incident Management  <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="SalonTickeTracking.php">Salon Ticket Tracking</a></li>
                                <li><a href="UserTicketTracking.php">User Ticket Tracking</a></li>
                              <!--   <li><a href="#">Assign responsible</a></li>
                                <li><a href="#">Attention availability control</a></li> -->
                              </ul>
                        </li>
                         <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="people"></ion-icon></i>Human resources management <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="Staffregistration.php">Staff registration</a></li>
                             <!--    <li><a href="Measurementbyobjectives.php">Measurement by objectives</a></li> -->
                                <li><a href="Payrollmanagement.php">Payroll management</a></li>
                              </ul>
                        </li>
                        <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i><ion-icon name="briefcase"></ion-icon></i>Financial management<span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                <li><a href="Controlofaccountsreceivable.php">Control of accounts receivable</a></li>
                                <li><a href="Controlofaccountsreceivable.php">Control of income / expenses</a></li>
                                <li><a href="Controlofaccountsreceivable.php">Balance control</a></li>
                                <li><a href="Controlofaccountsreceivable.php">Results status control</a></li>
                              </ul>
                        </li>
                        <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i class="fa fa-th"></i> Blog management<span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                               <!--  <li><a href="Commentscontrol.php">Comments control</a></li>
                                <li><a href="Topicalcontrol.php">Topical control</a></li> -->
                                <li><a href="Reportbypublications.php">Report by publications</a></li> 
                                <li><a href="Commentscontrol.php">Top users</a></li> 
                                <li><a href="Topicalcontrol.php">Top publications</a></li>                            
                                
                            </ul>
                        </li>
                       
                        <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i class="fa fa-lightbulb-o"></i>Operation management <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                                    <li><a href="servicesanalysis.php">Dashboard about the services analysis</a></li>
                            </ul>
                        </li>

                          <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i class="fa fa-th"></i> Blog de inicio <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                       
                                <li><a href="blog_home.php">Home</a></li> 
                                <li><a href="publication.php">Publications</a></li> 
                                
                            </ul>
                        </li>

                          <li class="dropdown">
                            <a href="" class="waves-effect dropdown-toggle" data-toggle="dropdown"><i class="fa fa-th"></i> Guía de tratamiento <span class="fa fa-angle-down right-errow"></span></a>
                            <ul class="dropdown-menu menu_drop">
                       
                                <li><a href="treatment_guide.php">Añadir Guía de tratamiento</a></li> 
                                <li><a href="wheretogochoose.php">¿Dónde ir? ¿Qué tratamiento elegir?</a></li> 
                                
                            </ul>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>
        <div class="page-wrapper">