<?php include('../../../common/config.php');


    extract($_POST);
          $file = $_FILES['image']['tmp_name'];
          $handle = fopen($file, "r");
          $c = 0;
           $s = 0;
          while(($filesop = fgetcsv($handle, 1000, ",")) !== false)
                    {
                      if($s!=0){
          $first_name = mysqli_real_escape_string($conn,$filesop[0]);
          $email = mysqli_real_escape_string($conn,$filesop[1]);
          $phone =mysqli_real_escape_string($conn, $filesop[2]);
          $gender = mysqli_real_escape_string($conn,$filesop[3]);
          $dob = mysqli_real_escape_string($conn,$filesop[4]);
         $notes= mysqli_real_escape_string($conn,$filesop[5]);
      
         
           $sql = "INSERT INTO `users`(`first_name`,`email`, `phone`, `gender`, `dob`, `notes`,`added_by`) values ('$first_name','$email','$phone','$gender','$dob','$notes','1')";
          $stmt = mysqli_prepare($conn,$sql);
          mysqli_stmt_execute($stmt);

         $c = $c + 1;

       }

         $s=1;
           }

            if( $stmt >0){

  echo '<div class="alert alert-success"  style="">
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong >Cliente cargado correctamente... </strong></div>';






echo "<script>function auto_refresh(){

       window.location='Clientes.php';

    }

    var refreshId = setInterval(auto_refresh, 2000);

</script>";


             } 
		 else
		 {
            echo "Sorry! Unable to impo.";
          }


?>
