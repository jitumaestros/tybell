<?php include('../../common/config.php');
$users=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$_SESSION['user_id']."'"));
$img=explode(',',$users['salon_pic']);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Salon</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" href="css/bootstrap.min.css">
		<script src="js/jquery.min.js"></script> 
		<script src="js/bootstrap.min.js"></script>

		<link rel="stylesheet" type="text/css" href="css/fullcalendar.min.css">
		<link rel="stylesheet" type="text/css" href="css/scheduler.min.css">

		<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css">
		<link rel="stylesheet" href="datepicker/pikaday.css">

		<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>

		<script src="js/moment.min.js"></script>
		<script src="js/jquerycal.min.js"></script>

		<script src="js/fullcalendar.min.js"></script>
		<script src="js/scheduler.min.js"></script>
		<script type="text/javascript" src="js/jquery-ui.min.js"></script>


		<link rel="stylesheet" type="text/css" href="css/style.css">
		<link rel="stylesheet" type="text/css" href="css/style1.css"><!-- 
		 -->

		<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

	</head>
	<body>
  	<header>
    <div class="pro_top_header"> 
		<nav class="navbar navbar-inverse ">
		  	<div class="container-fluid">
		    	<div class="navbar-header">
			      	<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
				        <span class="icon-bar"></span>
			      	</button>
			      	<a class="navbar-brand" href="index.php"> <?php echo $users['business_name'];?></a>
		    	</div>
		    	<div class="collapse navbar-collapse" id="myNavbar">
			      	<ul class="nav navbar-nav pro_nav_left">
						<li class="actives"><a href="index.php">Calendario</a></li>
						<li><a href="service.php?service=service">Servicios </a></li>
						<li><a href="Clientes.php">Clientes </a></li>
						<li><a href="reports.php?report=report">Informes </a></li>
						<li><a href="setting.php?setting=setting">Configuración</a></li>
			      	</ul>
			      	<ul class="nav navbar-nav navbar-right pro_nav_right">
				        <li>
				            <div class="input-group input-search-box">                  
				              <input id="msg" type="text" class="form-control" name="msg" placeholder="Additional Info">
				              <span class="input-group-addon">
				              	<button class="search_button"> <i class="fa fa-search"></i> </button>
				              </span>
				            </div>
			          	</li>
			          	<li>
			            	<a href="javascript:;" data-toggle="modal" data-target="#notification">
				              	<i class="fa fa-bell"></i>
				              	<div class="notify"> 0 </div>
			            	</a>
			          	</li>             
		          
			          	<li class="dropdown">
				            <a href="#" class="user_img_a dropdown-toggle" data-toggle="dropdown" onclick="usermenu()">
				            	<img src="../../image/<?php echo $img['0'];?>" class="user_img">
                        <span class="caret"></span>
				            </a>     
                    <ul class="dropdown-menu" id="dropdown-menu" style="display: none;"> 
                      <li><a href="logout.php">Logout</a></li> 
<!--                       <li><a href="#">dd</a></li>   
 -->                    </ul>     
			          	</li> 
				    </ul>
		    	</div>
		  	</div>
		</nav> 
	</div>

	<div class="side_nav_bar"> 
		<div class="slide_bar_nav">
    		<ul class="slide_bar_nav_menu">
      			<?php if($_GET['service']!=''){ ?>
              	<li>
                	<a href="service.php?service=service" type="button" class="dropdown-toggle menu_btn1">
                  	<i class="fa fa-scissors"></i> Servicios
                	</a>
              	</li> 
              	<li>
                	<a href="disount-page.php?service=service" type="button" class="dropdown-toggle menu_btn1">
                  		<i class="fa fa-percent img-circle" aria-hidden="true"></i> Descuentos
                	</a>
              	</li> 
              	<?php }elseif($_GET['report']!=''){?>

                          <li>
                	<a href="reports.php?report=report" type="button" class="dropdown-toggle menu_btn1">
                  	<i class="fa fa-signal" aria-hidden="true"></i> Stats
                	</a>
              	</li> 
              	<li>
                	<a href="customer_review.php?report=report" type="button" class="dropdown-toggle menu_btn1"><i class="fa fa-star-o" aria-hidden="true" style="font-size: 20px;"></i> Customer Reviews
                	</a>
              	</li> 

              	<?php }elseif($_GET['setting']!=''){?>

                          <li>
                	<a href="setting.php?setting=setting" type="button" class="dropdown-toggle menu_btn1">
                  	<img src="img/clock.png" width="30px" height="30px"> Local
                	</a>
              	</li> 
              	<li>
                	<a href="Finance.php?setting=setting" type="button" class="dropdown-toggle menu_btn1"><img src="img/fin_50.png" width="30px" height="30px"> Finanzas
                	</a>
              	</li> 

              	<li>
                	<a href="team_member.php?setting=setting" type="button" class="dropdown-toggle menu_btn1"><img src="img/user.png" width="30px" height="30px"> Equipo
                	</a>
              	</li> 

              	<?php }else{ ?>
                <li>
                  	<a href="booking.php"  class="dropdown-toggle menu_btn" type="button" >  
                    	Reservas
                  	</a>
                </li> 
                <li>
	                <div class="date-picker open" style="min-height: 400px;">
	                 
	              <!--       <input type="button"  class="addbtn" value="+ &nbsp; Add..." class="form-control" name="">
 -->
	                    	<a href="javascript:;" onclick="showappointment('<?php echo $bookings1['id'];?>','11:00 am','<?php echo $stfnm['id'];?>','','<?php echo $bookings1['service_id'];?>');" class="addbtn"   type="button" data-toggle="dropdown">  
                    	+ &nbsp; Añadir...
                  	</a>
	                
	                  <div class="calendar calendar_block"></div>
	                </div>
                </li>
		        <?php }?>
		    </ul>

		    <div class="header-bottom">
	        	<div class="bottom-1">
	        		<i class="fa fa-phone" aria-hidden="true"></i>
	         		<span><?php echo $users['contact_number'];?></span>
	         	</div>
	          	<div class="bottom-2"><a href="#">Obten Ayuda </a></div>
	      	</div> 
		</div>		
	</div>
</header>


<div class="wrapper pro_wrapper_block">

 
<script type="text/javascript">
   $(function() {
$( "#datepicker" ).datepicker();
});


function showbooking(id){

alert(id);
 window.location.href='index.php?dates='+id;

}

</script>


    

<script type="text/javascript">
  
$(document).ready(function(){
  $("#datepickera").click(function(){
    (".pika-single").addClass('cmss');
  });
});

</script>


<style type="text/css">

</style>
<style type="text/css">
  /*body {
  background: #f7f6f3;
  font-family: sans-serif;
}*/

/*.date-picker {
  margin: 200px auto;
}*/




</style>
<input type="hidden"  name="get" value="<?php echo $_GET['dates'];?>" class="date-picker">
<input type="hidden"  name="today" value="<?php echo date('m/d/Y');?>" class="date-picker">

<script type="text/javascript">










  $(function() {
  $( ".calendar" ).datepicker({
    dateFormat: 'mm/dd/yy',
    firstDay: 1
  });
  
  $(document).on('click', '.date-picker .input', function(e){
    var $me = $(this),
        $parent = $me.parents('.date-picker');
    $parent.toggleClass('open');
  });
  
  
  $(".calendar").on("change",function(){
    var me = $(this),
        selected = me.val(),
        parent = me.parents('.date-picker');


    parent.find('.result').children('span').html(selected);

    parent.find('.result').children('span').html(selected);



/*$.ajax({
       type: "POST",
         url: "showbooking.php",
            data: "id="+selected, 
          success: function(html)
            {     
              $("#bkinid").html(html);
                   //alert(html);   
             }
        

            });*/


                window.location.href='index.php?dates='+selected;



  });
});



</script>


<style type="text/css">
 
</style>

<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>

<script type="text/javascript">

function showappointment(id,time,staff_id,dates,service_id)
{
  //alert(service_id);
  $.ajax({
     type: "POST",
     url: "appointment.php",
     data: "id="+id+"&time="+time+"&staff_id="+staff_id+"&dates="+dates+"&service_id="+service_id,
    success: function(html)
    {  
      $("#myModalssgg").html(html);
      $("#myModalss").addClass('show');
      $("#myModalss").addClass('in');
      $("#myModalss").css("display","block");


      // alert(html);
    }
  });
}
</script>


<!-- 
<script type="text/javascript">
  
$(document).ready(function(){
  $("#drop_user_menu").click(function(){
    $("#dropdown-menu").css();
    $("#dropdown-menu").toggle();
    alert();
  });
});


</script>
 -->
 <script>
function usermenu() {
  var x = document.getElementById("dropdown-menu");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>

<style type="text/css">
  .pro_top_header .pro_nav_right>li>a .user_img {
    float: left;
}
</style>


