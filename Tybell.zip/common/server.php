<?php
$server_link="http://ruparnatechnology.com/christian/";
$server_mail="customersupport@homechow.co.za";
$from='Homechow';
?>