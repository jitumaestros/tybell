<?php include('header.php');?>
 <link rel="stylesheet" href="datepicker/pikaday.css">

<div class="addanother-services">
	<div class="addserevice-header">
		<ul class="anotherservices-menu-tab">
			<li><a href="javascript:;" id="add1" class="active-ser" onclick="tabs('tab-1','add1')">Configuracion de los descuentos</a></li>
			<li><a href="javascript:;" id="add2" onclick="tabs('tab-2','add2')">Servicios asignados</a></li>
		</ul>
	</div>
	<form method="post" enctype="multipart/form-data" id="addseroffrd">
	<div class="addanother-serives-blogtab">
		<div class="addservice-tab-1" id="tab-1">
			<div class="servicestab-1-1">
				<div class="addseroivceform">
					<div class="col-sm-9">
						 <div class="form-group">
						 	<label>Nombre de descuento</label>
						 	<input type="text" class="form-control" value="" name="name" placeholder="descuento en pelo">
						 </div>
					</div>
					<div class="col-sm-3">
						 <div class="form-group shitch-blog">
						 	<label>Activar descuento</label>
						 	<label class="switch" for="checkbox">
							    <input type="checkbox" id="checkbox" />
							    <div class="slider round"></div>
							</label>
					 </div>
					</div>
					<!-- <div class="col-sm-12">
						<div class="alert alert-warning">
						  <strong>Advertencia!</strong> Indica una advertencia que podría necesitar atención.
						</div>
					</div>
					 -->
					
					
				</div>
				<div class="show-user-add-anoither ">
					<p><b>Programar Descuento Promocional </b></p>
					<div class="check-box">
						<input type="radio" name="ship_rd" value="0">
						<span>&nbsp; Habilitar descuento promocional en un periodo de tiempo </span>
					</div>
					<div class="daa-ness-table-cs ship_rdaio" id="ship_rdaio0" style="display: none;">
						<div class="table-responsive">
							<table class="table">
								<thead>
									<tr><th>Descuento</th>
										
										<th>Fecha Inicio</th>
										<th>Fecha Fin</th>

										
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<div class="form-group">
												
												<select class="form-control" name="offer">
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>

													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>



												</select>
											</div>
										</td>
										
										<td>
											<div class="form-group">
												
												<input type="text" class="form-control"  placeholder="Fecha" name="offer_start_date" id="dater">
											</div>
										</td>
										<td>
											<div class="form-group">
												
												<input type="text" class="form-control" placeholder="Fecha" name="offer_end_date" id="daters">
											</div>
										</td>
										


									</tr>
									
								</tbody>
							</table>
						</div>
						
					</div>
				</div>
				<div class="show-user-add-anoither">
					<p><b>Descuentos para horario de minima actividad </b></p>
					<div class="check-box">
						<input type="radio" name="ship_rd" value="1">
						<span>&nbsp; Habilitar descuento basados en el horario de las citas</span>
					</div>
					<div class="daa-ness-table-cs ship_rdaio" id="ship_rdaio1" style="display: none;">
						<div class="table-responsive">
							<table class="table">
								<thead>
									<tr>
										<th></th>
										
										<th>Lunes</th>
										<th>Martes</th>
										<th>Miercoles</th>
										<th>jueves</th>
										<th>Virenes</th>
										<th>Sabado</th>
										<th>Domingo</th>
										
										
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>
											<p><input type="checkbox" name="day[]" class="checkboxallds1" value="1" style="opacity: 0;"><b>Mañana</b>(hasta 12:00) </p>
										</td>
										<td>
											<div class="form-group">
											<input type="checkbox" name="weeknmmon[]" class="checkboxalldsnm1" value="1" style="opacity: 0;">
											<input type="checkbox" name="dayweek1[]" class="checkboxalldsnm1" id="getoffer1" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek12[]" onchange="daychecked('1');checkedweeknm('1','1',this.value);">
												<option value="0">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
											<input type="checkbox" name="weeknmmon[]" class="checkboxalldsnm2" value="2" style="opacity: 0;">

											<input type="checkbox" name="dayweek1[]" class="checkboxalldsnm2" id="getoffer2" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek12[]" onchange="daychecked('1');checkedweeknm('1','2',this.value);">
												<option value="0">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
											  <input type="checkbox" name="weeknmmon[]" class="checkboxalldsnm3" value="3" style="opacity: 0;">
											<input type="checkbox" name="dayweek1[]" class="checkboxalldsnm3" id="getoffer3" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek12[]" onchange="daychecked('1');checkedweeknm('1','3',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">

											<input type="checkbox" name="weeknmmon[]" class="checkboxalldsnm4" value="4" style="opacity: 0;">
											<input type="checkbox" name="dayweek1[]" class="checkboxalldsnm4" id="getoffer4" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek12[]" onchange="daychecked('1');checkedweeknm('1','4',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">

											<input type="checkbox" name="weeknmmon[]" class="checkboxalldsnm5" value="5" style="opacity: 0;">
											<input type="checkbox" name="dayweek1[]" class="checkboxalldsnm5" id="getoffer5" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek12[]" onchange="daychecked('1');checkedweeknm('1','5',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
										<input type="checkbox" name="weeknmmon[]" class="checkboxalldsnm6" value="6" style="opacity: 0;">
											<input type="checkbox" name="dayweek1[]" class="checkboxalldsnm6" id="getoffer6" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek12[]" onchange="daychecked('1');checkedweeknm('1','6',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
												<input type="checkbox" name="weeknmmon[]" class="checkboxalldsnm7" value="7" style="opacity: 0;">
											<input type="checkbox" name="dayweek1[]" class="checkboxalldsnm7" id="getoffer7" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek12[]" onchange="daychecked('1');checkedweeknm('1','7',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>

										

									</tr>
									<tr>
										<td>
											<p><b><input type="checkbox" name="day[]" class="checkboxallds2" value="2" style="opacity: 0;">Tarde</b>(12:00-17:00) </p>
										</td>
										<td>
											<div class="form-group">
												<input type="checkbox" name="weeknm2nb[]" class="checkboxalldsnmtr1" value="1" style="opacity: 0;">
														<input type="checkbox" name="dayweek2[]" class="checkboxalldsnmtr1" id="getff1" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek2e[]" onchange="daychecked('2');checktrade('2','1',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">										
													<input type="checkbox" name="weeknm2nb[]" class="checkboxalldsnmtr2" value="2" style="opacity: 0;">

														<input type="checkbox" name="dayweek2[]" class="checkboxalldsnmtr2" id="getff2" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek2e[]" onchange="daychecked('2');checktrade('2','2',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
												<input type="checkbox" name="weeknm2nb[]" class="checkboxalldsnmtr3" value="3" style="opacity: 0;">
											<input type="checkbox" name="dayweek2[]" class="checkboxalldsnmtr3" id="getff3" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek2e[]" onchange="daychecked('2');checktrade('2','3',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
												<input type="checkbox" name="weeknm2nb[]" class="checkboxalldsnmtr4" value="4" style="opacity: 0;">
											<input type="checkbox" name="dayweek2[]" class="checkboxalldsnmtr4" id="getff4" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek2e[]" onchange="daychecked('2');checktrade('2','4',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
												<input type="checkbox" name="weeknm2nb[]" class="checkboxalldsnmtr5" value="5" style="opacity: 0;">
											<input type="checkbox" name="dayweek2[]" class="checkboxalldsnmtr5" id="getff5" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek2e[]" onchange="daychecked('2');checktrade('2','5',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
												<input type="checkbox" name="weeknm2nb[]" class="checkboxalldsnmtr6" value="6" style="opacity: 0;">
											<input type="checkbox" name="dayweek2e[]" class="checkboxalldsnmtr6" id="getff6" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek2[]" onchange="daychecked('2');checktrade('2','6',this.value);"> 
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
											<input type="checkbox" name="weeknm2nb[]" class="checkboxalldsnmtr7" value="7" style="opacity: 0;">
											<input type="checkbox" name="dayweek2[]" class="checkboxalldsnmtr7" id="getff7" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek2e[]" onchange="daychecked('2');checktrade('2','7',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										
										
									</tr>
									<tr>
										<td>
											<p><b><input type="checkbox" name="day[]" class="checkboxallds3" value="3" style="opacity: 0;">Noche</b> (17:00 y después) </p>
										</td>
										<td>
											<div class="form-group">
											<input type="checkbox" name="weeknm3dy[]" class="checkboxalldsnnoch1" value="1" style="opacity: 0;">
											<input type="checkbox" name="dayweek3[]" class="checkboxalldsnnoch1" id="gethrni1" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek3s[]" onchange="daychecked('3');checknight('3','1',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
											<input type="checkbox" name="weeknm3dy[]" class="checkboxalldsnnoch2" value="2" style="opacity: 0;">
											<input type="checkbox" name="dayweek3[]" class="checkboxalldsnnoch2" id="gethrni2" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek3s[]" onchange="daychecked('3');checknight('3','2',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
											<input type="checkbox" name="weeknm3dy[]" class="checkboxalldsnnoch3" value="3" style="opacity: 0;">

												<input type="checkbox" name="dayweek3[]" class="checkboxalldsnnoch3" id="gethrni3" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek3s[]" onchange="daychecked('3');checknight('3','3',this.value);">
												<option value="">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
												<input type="checkbox" name="weeknm3dy[]" class="checkboxalldsnnoch4" value="4" style="opacity: 0;">
												<input type="checkbox" name="dayweek3[]" class="checkboxalldsnnoch4" id="gethrni4" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek3s[]" onchange="daychecked('3');checknight('3','4',this.value);">
												<option value="0">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
										<input type="checkbox" name="weeknm3dy[]" class="checkboxalldsnnoch5" value="5" style="opacity: 0;">
												<input type="checkbox" name="dayweek3[]" class="checkboxalldsnnoch5" id="gethrni5" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek3s[]" onchange="daychecked('3');checknight('3','5',this.value);">
												<option value="0">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
											<input type="checkbox" name="weeknm3dy[]" class="checkboxalldsnnoch6" value="6" style="opacity: 0;" >
												<input type="checkbox" name="dayweek3[]" class="checkboxalldsnnoch6" id="gethrni6" value="" style="opacity: 0;">

												
											<select class="form-control" name="dayweek3s[]" onchange="daychecked('3');checknight('3','6',this.value);">
												<option value="0">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>
										<td>
											<div class="form-group">
											<input type="checkbox" name="weeknm3dy[]" class="checkboxalldsnnoch7" value="7" style="opacity: 0;">
												<input type="checkbox" name="dayweek3[]" class="checkboxalldsnnoch7" id="gethrni7" value="" style="opacity: 0;">

												<select class="form-control" name="dayweek3s[]" onchange="daychecked('3');checknight('3','7',this.value);">
												<option value="0">Precio final</option>
													<option value="10">10%</option>
													<option value="15">15%</option>
													<option value="20">20%</option>
													<option value="25">25%</option>
													<option value="30">30%</option>
													<option value="35">35%</option>
													<option value="40">40%</option>
													<option value="45">45%</option>
													<option value="50">50%</option>
													<option value="55">55%</option>
													<option value="60">60%</option>
													<option value="65">65%</option>
													<option value="70">70%</option>
													<option value="75">75%</option>
													<option value="80">80%</option>
													<option value="85">85%</option>
													<option value="90">90%</option>
													<option value="95">95%</option>

												</select>
											</div>
										</td>

									</tr>
									
								</tbody>
							</table>
						</div>
						
					</div>
				</div>
				<!--  -->
			</div>
		</div>

		<div class="desciption-blog" id="tab-2" style="display: none;">
			<div class="devription">
				<div class="discount-blog-2">
					<?php $r = rand();
					$sqlii=mysqli_query($conn,"select * from service where salon_id='".$_SESSION['user_id']."' group by category_id");
					while($sernm=mysqli_fetch_array($sqlii)){

						$catnm=mysqli_fetch_array(mysqli_query($conn,"select * from category where id='".$sernm['category_id']."'"));
						?>
						<div class="check-box check_1">
							<input type="checkbox" name="catid[]" id="jobchk<?php echo $catnm['id'];?>" style='float: left' class="checkboxall"  onclick="checkedinside('<?php echo $catnm['id'];?>');" value="<?php echo $catnm['id'];?>">
							<span>&nbsp; <?php echo $catnm['name'];?> </span>
						</div>
						<?php 
						$sqliis=mysqli_query($conn,"select * from service where salon_id='".$_SESSION['user_id']."' and category_id='".$sernm['category_id']."'");
						while($sernm1=mysqli_fetch_array($sqliis)){
							?>
							<div class="check-box check_2" > 
								<input type="checkbox" name="service_id[]" id="schffdk<?php echo $rs;?>" style='float: left' class="checkboxall checkboxalld<?php echo $catnm['id'];?>"  value="<?php echo $sernm1['id'];?>">						

								<span>&nbsp; <?php echo $sernm1['name'];?> </span>
							</div>
							<?php } }?>

						</div>
					</div>
				</div>
		<button type="submit" name="submit"  class="btn" >Guardar</button>
	</div> 
	</form>
	<div id="datart"></div>
	
</div>

<script type="text/javascript">

$(document).ready(function() {
	$("input[name$='ship_rd']").click(function() {
	    var test = $(this).val();
	    $(".ship_rdaio").hide();
	     $("#ship_rdaio" + test).show();
	});
});

</script>


<script type="text/javascript">
	$(document).ready(function(){
       

    $(".addanoth-btn").click(function(){
 var mtt = Math.floor(Math.random() * 20); 
        $(".table").append('<tr id="divids'+mtt+'"><td><div class="form-group"><input type="text" class="form-control" name=""></div></td><td><div class="form-group"><select class="form-control"><option>30 min</option></select></div></td><td><div class="form-group"><input type="text" class="form-control" name=""></div></td><td><div class="form-group"><input type="text" class="form-control" name=""></div></td><td><button class="close-btn"><i class="fa fa-times" onclick="hidss(this.id)" id="'+mtt+'"></i></button></td></tr>');

    });
    
});

                         
  function hidss(id){
   // alert('divids'+id)
    $("#divids"+id).html('');

  } 


function tabs(id,add){
	$('#tab-1').hide();
	$('#tab-2').hide();
	$('#'+id).toggle();
	$('#add1').removeClass('active-ser');
	$('#add2').removeClass('active-ser');
	$('#'+add).addClass('active-ser');

}



$(document).ready(function(){

    $("#clickcheck").click(function(){

     if (!$(this).is(':checked')) {

        $(".checkboxall").prop('checked', false);

        
    }else{
      $(".checkboxall").prop('checked', true);
      

  }
})


})


$(document).ready(function(){
    var mtt = Math.floor(Math.random() * 20);

//$("#clickcheckj"+mtt).click(function(){
    $(".checkboxall").click(function(){
        var ids =$(this).attr('id');
  /// alert(ids);

/*
 if (!$(this).is(':checked')) {

    $(".checkboxalld"+ids).prop('checked', false);

        
        }else{
          $(".checkboxalld"+ids).prop('checked', true);
       

      }*/
  })


})


function checkedinside(id){
    //alert(id);

   if (!$("#jobchk"+id).is(':checked')) {

    $(".checkboxalld"+id).prop('checked', false);

    
}else{
  $(".checkboxalld"+id).prop('checked', true);
  

}
}


function checkedinsidess(id){
   // alert(id);

   if (!$("#schffdk"+id).is(':checked')) {

    $(".checkboxallddd"+id).prop('checked', false);

    
}else{
  $(".checkboxallddd"+id).prop('checked', true);
  

}
}



$(document).ready(function(){

    $("#clickchecks").click(function(){

     if (!$(this).is(':checked')) {

        $(".checkboxall").prop('checked', false);

        
    }else{
      $(".checkboxall").prop('checked', true);
      

  }
})


})

function selecteall(){
  // alert();
  setInterval(function(){
      $('form#loginform1').submit();
  }, 1000);


}

function daychecked(id){
    //alert(id);

   /*if (!$("#jobchk"+id).is(':checked')) {

    $(".checkboxallds"+id).prop('checked', false);

    
}else{*/
  $(".checkboxallds"+id).prop('checked', true);
  

//}
}

function checkedweeknm(id,ids,ofid){
    //alert(ids);

   /*if (!$("#jobchk"+id).is(':checked')) {

    $(".checkboxallds"+id).prop('checked', false);

    
}else{*/
  $(".checkboxalldsnm"+ids).prop('checked', true);

  $("#getoffer"+ids).val(ofid);


//}
}

function checktrade(id,ids,ofids){
   // alert(ids);

   /*if (!$("#jobchk"+id).is(':checked')) {

    $(".checkboxallds"+id).prop('checked', false);

    
}else{*/
  $(".checkboxalldsnmtr"+ids).prop('checked', true);
  $("#getff"+ids).val(ofids);



//}
}


function checknight(id,ids,getthr){
    //alert(ids);

   /*if (!$("#jobchk"+id).is(':checked')) {

    $(".checkboxallds"+id).prop('checked', false);

    
}else{*/
  $(".checkboxalldsnnoch"+ids).prop('checked', true);
    $("#gethrni"+ids).val(getthr);




//}
}


</script>

<script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>


  <style type="text/css">
      
.mce-notification-warning{

display: none;

}

  </style>
<?php include('footer.php');?>

 <script src="datepicker/pikaday.js"></script>

<script type="text/javascript">
	
$(document).ready(function (addseroffr) {
 $("#addseroffrd").on('submit',(function(addseroffr) {
 	   	//alert();

  $("#form_abc1_img").show();
  addseroffr.preventDefault();
  $.ajax({
   url: "php/add_service_offer.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert(data);
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});



  new Pikaday(
  {
    field: document.getElementById('dater'),
    trigger: document.getElementById('datepicker-button'),
    minDate: new Date(2000, 0, 1),
    ariaLabel: 'Custom label',
    maxDate: new Date(2020, 12, 31),
    yearRange: [2010,2020]

  });



    new Pikaday(
  {
    field: document.getElementById('daters'),
    trigger: document.getElementById('datepicker-button'),
    minDate: new Date(2000, 0, 1),
    ariaLabel: 'Custom label',
    maxDate: new Date(2020, 12, 31),
    yearRange: [2010,2020]

  });
</script>
