<?php include('../common/config.php');?>

<!DOCTYPE html>

<html lang="en">

<head>

  <title>Tybell</title>

  <meta charset="utf-8">

  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link rel="stylesheet" href="css/bootstrap.min.css">


<link href="https://unpkg.com/@ionic/core@latest/css/ionic.bundle.css" rel="stylesheet">

  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">


  <script src="js/jquery.min.js"></script>

  <script src="js/bootstrap.min.js"></script>

<script src="js/jquery-1.11.3.min.js"></script>

<!-- <script src="js/jquery.mobile-1.4.5.min.js"></script> -->

  <script src="https://unpkg.com/@ionic/core@latest/dist/ionic.js"></script>

<link rel="stylesheet" type="text/css" href="css/style.css">

<link rel="stylesheet" type="text/css" href="../css/responsive.css">

<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">

 
</head>

<body>

	<div class="business_wrapper" style="background: url('img/an.png');">

		<div class="container">

			<div class="businerr_wrapper_blog">

				<div class="logo_sec">

					<a href="">Tybell</a>

				</div>

				<div class="col-sm-6 padder">

					<div class="left_business_blog">

						<h1 class="tw-homepage">Conviértete en un socio Tybell y haz crecer tu negocio</h1>

						<p class="tw-homepage_para">¿Quieres que te hablemos a través de nuestra combinación ganadora</p>

						<button class="request_btn">Solicitar consulta gratuita
</button>

					
					</div>

				</div>

				<div class="col-sm-6">

					<div class="right_business_blog">

					
					</div>

				</div>

			
			</div>

		</div>

	</div>

	<div class="form_businee tw-form">
<form method="post" enctype="multipart/form-data" id="editprof">
		<div class="container">

			<div class="from_div">

				<div class="fl-rich-text">

					<h2><span style="margin-right: 110px;">¡Da el primer paso y

 </span><br>

					<span style="margin-left: 100px;">completa el formulario!</span></h2>

				</div>

				<div class="fl-rich-text">

					<p >Completa el formulario y nuestro equipo se pondrá en contacto contigo para aclarar todas tus dudas, sin ningún compromiso. ¡Descubre cómo tener más clientes con Tybell!
<br>

				Actualmente no aceptamos profesionales a domicilio o salones ubicados en un hogar.


</p>

				</div>



				<div class="col-sm-6">

					<div class="from_left_blog">

						<h4 style="color: #001E62;">Acerca del salón

</h4>

						<div class="form-group input_box">

							<span>Nombre del establecimiento </span>

							<input type="text" class="form-control" placeholder="" name="business_name" required="required">

						</div>

						<div class="div_2_input_div">

							<div class="form-group div_1 input_box">

								<span>Actividad principal</span>

								<select class="form-control" name="type_of_business" required="required">

						          <option value="" disabled="" selected="">Choose your type of business</option>
<?php $sqlii=mysqli_query($conn,"select * from business ");

while($busi=mysqli_fetch_array($sqlii)){
?>
						          <option value="<?php echo $busi['id'];?>"><?php echo $busi['name'];?> </option>
<?php }?>
						        </select>

							</div>

							<div class="form-group div_2 input_box">

								<span>Empleados</span>

								<select class="form-control" name="employees" required="required">

						          <option value="" disabled="" selected=""></option>

						          <option value="1">1</option>

						          <option value="2">2</option>

						          <option value="3">3</option>

						          <option value="4">4</option>

						          <option value="5">5</option>

						          <option value="5">6</option>

						          <option value="5">7</option>

						          <option value="5">8+</option>

						        </select>

							</div>

						</div>

						<div class="form-group input_box">

							<span>Distrito</span>

							<select type="text" class="form-control" placeholder="" name="district" required="required">

							<?php $serv=mysqli_query($conn,"select * from district ");

             		while($sernm=mysqli_fetch_array($serv)){

             			?>

             			<option value="<?php echo $sernm['id'];?>"><?php echo $sernm['name'];?></option>

             			<?php }?> 
</select>
						</div>

						<div class="div_2_input_div">

							<div class="form-group div_3 input_box">

								<span>Dirección</span>

								<input type="text" class="form-control" placeholder="" name="adress" id="txtPlacesss" required="required">

							</div>
							<input type="hidden" name="latitude" id="latitude">
							<input type="hidden" name="longitude" id="longitude">

							<div class="form-group div_4 input_box">

								<span>Ciudad</span>

								<select class="form-control" name="city" required="required">						        

							          <option value="" disabled="" selected="">Select your city</option>

							          <option value="Greater London">Greater London</option>

							          <option value="Greater Manchester">Greater Manchester</option>

							          <option value="Leeds">Leeds</option>

							          <option value="Edinburgh">Edinburgh</option>

							          <option value="Glasgow">Glasgow</option>

							          <option value="Bristol">Bristol</option>

							          <option value="Brighton">Brighton</option>

							          <option value="Other">other</option>       

						        </select>

							</div>

						</div>

						<div class="form-group input_box">

							<span>Página web/ link de facebook</span>

							<input type="text" class="form-control" placeholder="" name="website" required="required">

						</div>

					</div>

				</div>

				<div class="col-sm-6">

					<div class="right_form_blog">

							<h4 style="color: #001E62;">Cuéntanos algo sobre ti</h4>

						<div class="div_2_input_div">

							<div class="form-group div_5 input_box">

								<span>Nombre</span>

								<input type="text" class="form-control" placeholder="" name="first_name" required="required">

							</div>

							<div class="form-group div_6 input_box">

								<span>Apellidos</span>

								<input type="text" class="form-control" placeholder="" name="last_name" required="required">

							</div>							

						</div>

						<div class="form-group input_box">

							<span>Dirección Email</span>

							<input type="email" class="form-control" placeholder="" name="email" required="required">

						</div>


<div class="form-group input_box">

							<span>Contraseña </span>

							<input type="password" class="form-control" placeholder="" name="password" required="required">

						</div>



						<div class="form-group input_box">

							<span>Número de teléfono</span>

							<input type="text" class="form-control" placeholder="+44..." name="contact_number" required="required">

						</div>

						<div class="form-group input_box">

							<span>¿Cómo descubriste Tybell?</span>

							<select class="form-control" name="share" required="required">

						        <option value="" disabled="" selected="">Please select an option</option>

						        <option value="Me lo recomendó un cliente">Me lo recomendó un cliente</option>

						        <option value="Me lo recomendó otro salón">Me lo recomendó otro salón</option>

						        <option value="Revistas o flyers">Revistas o flyers</option>

						        <option value="Facebook/ Instagram">Facebook/ Instagram</option>

						        <option value="LinkedIn">LinkedIn</option>

						        <option value="Google">Google</option>

						        <option value="Comparador de Softwares">Comparador de Softwares</option>

						        <option value="Publicidad en exteriores">Publicidad en exteriores</option>

						        <option value="Publicidad en TV">Publicidad en TV</option>

						        <option value="Evento Creative Head / Salon Smart
">Evento Creative Head / Salon Smart
</option>

						        <option value="Otros">Otros</option>

						      </select>

						</div>

						<p>Tybell utilizará los datos que introduzcas para ponerse en contacto contigo por email y/o por teléfono.</p>

						<p>Puedes obtener más información sobre cómo Tybell almacena, utiliza y protege tus datos en nuestra  <a href="" style="color: #FF5C39;">política de privacidad.

.</a> </p>
						<input class="request_demo pull-right" type="submit" name="submit"  value="Solicitud">

					</div>

				</div>

			</div>

		</div>
</form>
<div id="datart"></div>
	</div>

	

</body>

</html>
<script type="text/javascript">
	
	$(document).ready(function (profil) {
 $("#editprof").on('submit',(function(profil) {
 	//alert();
  $("#form_abc1_img").show();
  profil.preventDefault();
  $.ajax({
   url: "php/add_vender.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
     $("#form_abc1_img").hide();
 // alert(data);
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});
</script>

<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE&sensor=false&libraries=places"></script>

<script type="text/javascript">

  google.maps.event.addDomListener(window, 'load', function () {

/*    var options = {

      componentRestrictions: {country: "in"}
    };*/
    var places = new google.maps.places.Autocomplete(document.getElementById('txtPlacesss'));

    google.maps.event.addListener(places, 'place_changed', function () {

      var place = places.getPlace();

      var address = place.formatted_address;

      var latitude = place.geometry.location.lat();

      var longitude = place.geometry.location.lng();

      var mesg = "Address: " + address;

      mesg += "\nLatitude: " + latitude;

      mesg += "\nLongitude: " + longitude;


      $("#latitude").val(latitude);
      $("#longitude").val(longitude);

    });

  });

</script>




<style type="text/css">
	html:not(.hydrated) body {
    display: block !important;
}
	
</style>





