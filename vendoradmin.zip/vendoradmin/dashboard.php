<?php include ('header.php');

$totals='';
$bookss=mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."'");
while($torals=mysqli_fetch_array($bookss)){
    $totals +=$torals['total_amount'];


}

$schedule_dateq=date('m/d/Y');

$monday = strtotime("last monday");
$monday = date('w', $monday)==date('w') ? $monday+7*86400 : $monday;

$sunday = strtotime(date("m/d/Y",$monday)." +6 days");

$this_week_sd = date("m/d/Y",$monday);
$this_week_ed = date("m/d/Y",$sunday);




$weektotals='';
$booksas=mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and schedule_date between '$this_week_sd' and '$this_week_ed'");
while($wetorals=mysqli_fetch_array($booksas)){
    $weektotals +=$wetorals['total_amount'];


}


$dailyis='';
$schedule_date=date('m/d/Y');
$booksas=mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and schedule_date='$schedule_date'");
while($wetorals=mysqli_fetch_array($booksas)){
    $dailyis +=$wetorals['total_amount'];


}


?>
 <link rel="stylesheet" href="datepicker/pikaday.css">

<div class="container-fluid">
 
  <div class="row page-titles">
    <div class="col-md-6 col-8 align-self-center">
        <h3 class="text-themecolor m-b-0 m-t-0">Dashboard</h3>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
            <li class="breadcrumb-item active">Dashboard</li>
        </ol>
    </div>
    <div class="col-md-6 col-4 align-self-center">
        
    </div>
</div>

<div class="row">
    <!-- Column -->
    <div class="col-sm-4">
        <div class="card">
            <div class="card-block">
                <h4 class="card-title">Daily Booking</h4>
                <div class="text-right">
                    <h2 class="font-light m-b-0"><i class="ti-arrow-up text-success"></i> $<?php echo $dailyis;?></h2>
                    <span class="text-muted">Daily Income</span>
                </div>
                <span class="text-success">80%</span>
                <div class="progress">
                    <div class="progress-bar bg-success" role="progressbar" style="width: 80%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="col-sm-4">
        <div class="card">
            <div class="card-block">
                <h4 class="card-title">Weekly Booking</h4>
                <div class="text-right">
                    <h2 class="font-light m-b-0"><i class="ti-arrow-up text-info"></i> $<?php echo $weektotals;?></h2>
                    <span class="text-muted">Weekly Income</span>
                </div>
                <span class="text-info">30%</span>
                <div class="progress">
                    <div class="progress-bar bg-info" role="progressbar" style="width: 30%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
    </div>


    <div class="col-sm-4">
        <div class="card">
            <div class="card-block">
                <h4 class="card-title">Total Booking</h4>
                <div class="text-right">
                    <h2 class="font-light m-b-0"><i class="ti-arrow-up text-success"></i> $<?php echo $totals;?></h2>
                    <span class="text-muted">Total Income</span>
                </div>
                <span class="text-success">80%</span>
                <div class="progress">
                    <div class="progress-bar bg-success" role="progressbar" style="width: 80%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-block">
                <html>
                <head>  
<!-- <script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
  animationEnabled: true,
  theme: "light2",
  title:{
    text: "Ingresos"
  },
  axisY:{
    includeZero: false
  },
  data: [{        
    type: "line",       
    dataPoints: [
      { y: 450 },
      { y: 414},
      { y: 520, indexLabel: "",markerColor: "red", markerType: "triangle" },
      { y: 460 },
      { y: 450 },
      { y: 500 },
      { y: 480 },
      { y: 480 },
      { y: 410 , indexLabel: "",markerColor: "DarkSlateGrey", markerType: "cross" },
      { y: 500 },
      { y: 480 },
      { y: 510 }
    ]
  }]
});
chart.render();

}
</script>
</head>
<body>
<div id="chartContainer" style="height: 300px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script> -->


<!DOCTYPE HTML>
<html>
<head>
    <?php 

if($_GET['serviceid']!=''){
$servicsa=$_GET['serviceid'];

     $use=mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and booking_status='4' and  FIND_IN_SET('$servicsa', service_id) and month='".$_GET['month']."' group by month");
   }else{

         $use=mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and booking_status='4' group by month");

   }

$schedule_date1=strtotime($_GET['dates']);
$schedule_date=date('m/d/Y',$schedule_date1);


if($_GET['service']!=''){
$servics=$_GET['service'];

    $uses=mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and booking_status='4' and  FIND_IN_SET('$servics', service_id) group by schedule_date");

}else{

    $uses=mysqli_query($conn,"select * from bookings where salon_id ='".$_SESSION['user_id']."' and booking_status='4' group by schedule_date");
}

    ?>
    <script type="text/javascript">
      window.onload = function () {

        var chart = new CanvasJS.Chart("chartContainer",
        {

          title:{
              text: "Ingresos"
          },
          axisX: {
            valueFormatString: "MMM",
            interval:1,
            intervalType: "month"
        },
        axisY:{
            includeZero: false

        },
        data: [
        {
            type: "line",

            dataPoints: [
            <?php 
            while ($sales=mysqli_fetch_array($use)){
               $pricedfd='';

               $saless=strtotime($sales['schedule_date']);

               if($_GET['serviceid']!=''){

               $sqlityt=mysqli_query($conn,"select * from bookings where month='".$_GET['month']."' and salon_id='".$_SESSION['user_id']."' and  FIND_IN_SET('$servicsa', service_id)  ");
               }else{


               $sqlityt=mysqli_query($conn,"select * from bookings where month='".$sales['month']."' and salon_id='".$_SESSION['user_id']."' ");


               }
               
               while($saled=mysqli_fetch_array($sqlityt)){
                  
                $servicea=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$servicsa'"));

                  if($_GET['month']!=''){


                   $pricedfd+=$servicea['price'];
                   
                   }else{

                   $pricedfd+=$saled['total_amount'];


                   }
               }

               $serc=explode(',',$sales['service_id']);
               $sernm='';
               foreach ($serc as $key => $valuea) {
                   $servides=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$valuea."'"));
                   if($sernm==''){

                    $sernm=$servides['name'];

                }else{

                    $sernm=$sernm.','.$servides['name'];


                }


            }

            $totaly=$pricedfd.','.$sernm;

            $ndate=strtotime($sales['schedule_date']);
            $day=date(1);

            $month=date('m',$ndate);

            $year=date('Y',$ndate);

            $fnal=$year.','.($month-1).','.$day;
            $fnlk=date('Y,m,d',$ndate);

            ?>
            { x: new Date(<?php echo $fnal;?>), y: <?php echo $pricedfd;?> },

            <?php }?>
            ]
        }
        ]
    });

        chart.render();





        var chart = new CanvasJS.Chart("chartContainer1",
        {
            title: {
                text: "Ingresos"               
            },
            axisX:{      
                valueFormatString: "DD-MMM" ,
                labelAngle: -50
            },
            axisY: {
              valueFormatString: "#,###"
          },

          data: [
          {        
            type: "line",
            color: "rgba(0,75,141,0.7)",
            dataPoints: [
            <?php 

            while ($sales1=mysqli_fetch_array($uses)){
               $pricedfd1='';

               $saless=strtotime($sales['schedule_date']);

               if($_GET['service']!=''){

               $sqlitytw=mysqli_query($conn,"select * from bookings where  salon_id='".$_SESSION['user_id']."'  and  FIND_IN_SET('$servics', service_id) and schedule_date='".$sales1['schedule_date']."' ");


               }else{
               $sqlitytw=mysqli_query($conn,"select * from bookings where schedule_date='".$sales1['schedule_date']."' and salon_id='".$_SESSION['user_id']."' ");
               }
               
               while($saledq=mysqli_fetch_array($sqlitytw)){


            $services=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='$servics'"));

                  if($_GET['service']!=''){
                  
                  
                                     $pricedfd1+=$services['price'];


                  
                }
                else{


                                     $pricedfd1+=$saledq['total_amount'];

                }
                   
                   
               }


               $ndate1=strtotime($sales1['schedule_date']);
               $day=date('d',$ndate1);

               $months=date('m',$ndate1);

               $year1=date('Y',$ndate1);

               $fnalw=$year1.','.($months-1).','.$day;
               $fnlk=date('Y,m,d',$ndate1);

               ?>
               { x: new Date(<?php echo $fnalw;?>), y: <?php echo $pricedfd1;?> },
               <?php }?>
               ]
           }
           
           ]
       });





        chart.render();
    }
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script></head>
<body>
<form method="post" id="loginform1" enctype="multipart/form-data">

<!--   <input type="text" name="dateds" id="daters" onchange="loginform(this.value);" value="<?php echo $_GET['dates'];?>">
 -->
  <select onchange="loginform(this.value);" name="service" class="form-control" style="width: 20%">
 <?php if($_GET['service']!=''){?>
<option value="<?php echo $_GET['service'];?>"><?php $servnm=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$_GET['service']."'")); echo $servnm['name'];?>
 <?php  }else{ ?>

  <option value="">Type of Service</option>

  <?php } ?>
  


</option>
<?php 
$sqliii=mysqli_query($conn,"select * from service where salon_id='".$_SESSION['user_id']."'");

while($sernm=mysqli_fetch_array($sqliii)) {
 
?>
<option value="<?php echo $sernm['id'];?>"><?php echo $sernm['name'];?></option>
<?php }?>
  </select>
  </form>

    <div id="chartContainer1" style="height: 300px; width: 100%;">
    </div>
    <br>  <br>


<form method="post" id="loginform1A" enctype="multipart/form-data">
<?php /*$effectiveDate = strtotime("+11 months", strtotime('Jan'));
echo date('m',$effectiveDate);
*/ 
if($_GET['month']=='02'){
$nb='Feb';

}
elseif($_GET['month']=='03'){
$nb='Mar';

}
elseif($_GET['month']=='04'){
$nb='Apr';

}elseif($_GET['month']=='05'){
$nb='May';

}elseif($_GET['month']=='06'){
$nb='Jun';

} elseif($_GET['month']=='07'){
$nb='Jul';

}elseif($_GET['month']=='08'){
$nb='Aug';

}elseif($_GET['month']=='09'){
$nb='Sep';

}
elseif($_GET['month']=='10'){
$nb='Oct';

}

elseif($_GET['month']=='11'){
$nb='Nov';

}
elseif($_GET['month']=='12'){
$nb='Dec';

}else{


$nb='Jan';
}



?>
<select onchange="loginforms(this.value);" name="month"  class="form-control" style="width: 20%">
<?php if($_GET['month']!=''){?>
<option value="<?php echo $_GET['month'];?>"><?php echo $nb;?></option>
<?php }else{ ?>
  
  <option value="">Month</option>

<?php }?>
<option value="01">Jan</option>
  <option value="02">Feb</option>
  <option value="03">Mar</option>
  <option value="04">Apr</option>
  <option value="05">May</option>
  <option value="06">Jun</option>
  <option value="07">Jul</option>
  <option value="08">Aug</option>
  <option value="09">Sep</option>
  <option value="10">Oct</option> 
  <option value="11">Nov</option> 
  <option value="12">Dec</option> 

</select>


  <select onchange="loginforms(this.value);" name="serviceid"  class="form-control" style="width: 20%">

  <?php if($_GET['serviceid']!=''){?>

<option value="<?php echo $_GET['service'];?>"><?php $servnm=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$_GET['serviceid']."'")); echo $servnm['name'];?></option>
<?php }else{ ?>

  <option value="">Type of Service</option>

<?php }?>


<?php $sqliii=mysqli_query($conn,"select * from service where salon_id='".$_SESSION['user_id']."'");

while($sernm=mysqli_fetch_array($sqliii)) {
 
?>
<option value="<?php echo $sernm['id'];?>"><?php echo $sernm['name'];?></option>

<?php }?>
  </select>
  </form>

    <div id="chartContainer" style="height: 300px; width: 100%;">
    </div>

</body>
</html>

</body>
</html>                            </div>
</div>
</div>
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-block">
                <!-- <select class="custom-select pull-right">
                    <option selected>January</option>
                    <option value="1">February</option>
                    <option value="2">March</option>
                    <option value="3">April</option>
                </select> -->
                <h4 class="card-title">Client of the Month</h4>
                <div class="table-responsive m-t-40">
                    <table class="table stylish-table">
                        <thead>
                            <tr>
                                <th>Assigned</th>
                                <th>Name</th>
                                <th>Budget</th>
                            </tr>
                        </thead>
                        <tbody>
                         <?php $sqlii=mysqli_query($conn,"select * from bookings where salon_id='".$_SESSION['user_id']."' group by user_id");
                         $return_arrrevi=array(); 

                         while($skillvideovi=mysqli_fetch_array($sqlii)){

                            array_push($return_arrrevi,$skillvideovi);
                        }

                        foreach ($return_arrrevi as $key => $rowvi) {

                            $countssci=mysqli_num_rows(mysqli_query($conn,"select * from bookings where user_id='".$rowvi['user_id']."'"));

                            $volume[$key]  = $countssci;
                        }

                        array_multisort($volume, SORT_DESC,  $return_arrrevi);

                        foreach ($return_arrrevi as $key => $rows) {


                            $pricedfd11='';
                            $staff=mysqli_fetch_array(mysqli_query($conn,"select * from staff where id='".$rows['staffid']."'"));
                            $customer=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$rows['user_id']."'"));

                            $sqlitytsw=mysqli_query($conn,"select * from bookings where user_id='".$rows['user_id']."' and salon_id='".$_SESSION['user_id']."' ");
                            
                            
                            while($saledqs=mysqli_fetch_array($sqlitytsw)){
                              
                                
                               $pricedfd11+=$saledqs['total_amount'];
                               
                               
                           }

                           ?>
                           <tr class="active">
                            <td>
                                <div class="cslms">
                                    <div class="row">
                                        <div class="col-sm-2">
                                            <span class="round"><img src="img/<?php echo $staff['profile_pic_path'];?>" alt="user" width="50" /></span>
                                        </div>
                                        <div class="col-sm-4">
                                            <h6><?php echo $staff['name'];?></h6><small class="text-muted"><?php echo $staff['role'];?></small>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo $customer['first_name'].' '.$customer['last_name'];?></td>
                            <td>$<?php echo $pricedfd11;?></td>
                        </tr>
                        <?php }?>
                        
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
</div>

<div class="row">
 
</div>
<div id="user_details_dataa"></div>
<div id="user_details_data"></div>


<?php include ('footer.php');?>
    <script src="datepicker/pikaday.js"></script>

<script type="text/javascript">
  
  new Pikaday(

  {

    field: document.getElementById('daters'),

    trigger: document.getElementById('datepicker-button'),

    minDate: new Date(2000, 0, 1),

    ariaLabel: 'Custom label',

    maxDate: new Date(2020, 12, 31),

    yearRange: [2010,2020]


  });



     function loginform(id){
     // alert(id);
      $('form#loginform1').submit();

     }



$(document).ready(function (loginabc41) {

 $("#loginform1").on('submit',(function(loginabc41) {
  $("#user_details_data").show();
  loginabc41.preventDefault();
  $.ajax({
   url: "bookingfilter.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
     $("#user_details_data").hide();
   $("#user_details_dataa").show().html(data);
   alert(data);
      },
     error: function(){}          
    });

 }));
});

     function loginforms(id){
      alert(id);
      $('form#loginform1A').submit();

     }


$(document).ready(function (loginabc41dd) {

 $("#loginform1A").on('submit',(function(loginabc41dd) {
  $("#user_details_data").show();
  loginabc41dd.preventDefault();
  $.ajax({
   url: "bookingfilterS.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
     $("#user_details_data").hide();
   $("#user_details_data").show().html(data);
  // alert(data);
      },
     error: function(){}          
    });

 }));
});

</script>