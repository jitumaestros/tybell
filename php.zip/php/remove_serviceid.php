<?php extract($_POST);
$id;

$serviceid=str_replace($id, "", $serviceidF);

/*echo $pricee=str_replace(',', "", $pricee);
*/

echo "<script>window.location='checkout_1.php?salon_id=$salon_id&service_lavel=$service_lavel&dates=$dates&serviceid=$serviceid&staffid=$staffid&open_time=$open_time';</script>";
?>