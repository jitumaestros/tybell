<?php include('../../common/config.php');

extract($_POST);

$bokserv=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where id='".$id."'"));

$user=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bokserv['user_id']."'"));

$userss=$user['first_name'].' '.$user['last_name'];
$sln=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bokserv['salon_id']."'"));

/*echo "update bookings set booking_status='2' where id='$id'";
*/
$slnuser=$sln['first_name'].' '.$sln['last_name'];

$schedule_date1=strtotime($schedule_date);
$csnce=mysqli_query($conn,"update bookings set schedule_date='$schedule_date',dates='$schedule_date1',schedule_time='$schedule_time' where id='$id'");

$servci1=explode(',', $bokserv['service_id']);

$sernm='';

foreach ($servci1 as $key => $valuse) {

  $serbn=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$valuse."'"));
 
//$price +=$serbn['price'];

if($sernm==''){

$sernm=$serbn['name'];

}else{

$sernm=$sernm.' & '.$serbn['name'];

}
}


if($csnce){

	echo "<strong style='color:green'>Reservaciones editadas exitosamente</strong>";

$messagetrrt.='<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td bgcolor="#E5376A" align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
                <tr>
                    <td align="center" valign="top" style="padding: 40px 10px 40px 10px;">
                       
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    <tr>
      <td bgcolor="#E5376A" align="center" style="padding: 0px 10px 0px 10px;">
          <table border="0" cellpadding="0" cellspacing="0" width="480" >
             <tr>
               <td bgcolor="#ffffff" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">
         <a href="" target="_blank">
                            <img alt="Logo" src="http://maestrosinfotech.com/Tybell/img/logo.png" width="100" height="100" style="display: block;  font-family: "Lato", Helvetica, Arial, sans-serif; color: #ffffff; font-size: 18px;" border="0">
                        </a>
                      </td>
                    </tr>
                  </table>';
     $messagetrrt.=' </td>
    </tr>
   
    <tr>
        <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
              <!-- COPY -->
              <tr>
                <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;" >
                  <h4 style="margin: 0;">Editar reservas</h4>
                  <p style="margin: 0;">Hola  </p>

                  <p style="margin: 0;">Esto es para informarle que sus servicios son cambiados por. '.$slnuser.'</p>

                  <p style="margin: 0;">Detalles de la reserva :-</p>


                         <p style="margin: 0;">Orden ref :-'.$bokserv['order_ref'].'</p>

                 <p style="margin: 0;">Metido :-'.date('D M d Y', $schedule_date1).'  '.$schedule_time.' </p>

                          <p style="margin: 0;">Servicios :-'.$sernm.'</p>


                </td>
              </tr>
             
                  
            </table>
        </td>
    </tr>';

     $messagetrrt.='<tr>
        <td bgcolor="#f4f4f4" align="center" style="padding: 30px 10px 0px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
                <tr>
                  <td bgcolor="#f4aec3" align="center" style="padding: 30px 30px 30px 30px; border-radius: 4px 4px 4px 4px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;" >
                    <h2 style="font-size: 20px; font-weight: 400; color: #111111; margin: 0;">Necesitas más ayuda?</h2>
                    <p style="margin: 0;"><a href="" style="color: #E5376A;">Nosotras son aquí, listo para hablar</a></p>
                  </td>
                </tr>
            </table>
        </td>
    </tr>
   
</table>';



     maildss($user['email'],$user['first_name'], 'Editar reservas' ,$messagetrrt,'');






$messagetrrt1.='<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td bgcolor="#E5376A" align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
                <tr>
                    <td align="center" valign="top" style="padding: 40px 10px 40px 10px;">
                       
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    <tr>
      <td bgcolor="#E5376A" align="center" style="padding: 0px 10px 0px 10px;">
          <table border="0" cellpadding="0" cellspacing="0" width="480" >
             <tr>
               <td bgcolor="#ffffff" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">
         <a href="" target="_blank">
                            <img alt="Logo" src="http://maestrosinfotech.com/Tybell/img/logo.png" width="100" height="100" style="display: block;  font-family: "Lato", Helvetica, Arial, sans-serif; color: #ffffff; font-size: 18px;" border="0">
                        </a>
                      </td>
                    </tr>
                  </table>';
     $messagetrrt1.=' </td>
    </tr>
   
    <tr>
        <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
              <!-- COPY -->
              <tr>
                <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;" >
                  <h4 style="margin: 0;">Editar reservas</h4>
                  <p style="margin: 0;">Hola  </p>

                  <p style="margin: 0;">Esto es para informarle que ha cambiado los servicios programados.</p>

                  <p style="margin: 0;">Detalles de la reserva :-</p>


                         <p style="margin: 0;">Orden ref :-'.$bokserv['order_ref'].'</p>

                 <p style="margin: 0;">Metido :-'.date('D M d Y', $schedule_date1).'  '.$schedule_time.' </p>

                          <p style="margin: 0;">Servicios :-'.$sernm.'</p>


                </td>
              </tr>
             
                  
            </table>
        </td>
    </tr>';

     $messagetrrt1.='<tr>
        <td bgcolor="#f4f4f4" align="center" style="padding: 30px 10px 0px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
                <tr>
                  <td bgcolor="#f4aec3" align="center" style="padding: 30px 30px 30px 30px; border-radius: 4px 4px 4px 4px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;" >
                    <h2 style="font-size: 20px; font-weight: 400; color: #111111; margin: 0;">Necesitas más ayuda?</h2>
                    <p style="margin: 0;"><a href="" style="color: #E5376A;">Nosotras son aquí, listo para hablar</a></p>
                  </td>
                </tr>
            </table>
        </td>
    </tr>
   
</table>';






     maildss($sln['email'],$sln['first_name'], 'Editar reservas' ,$messagetrrt1,'');













echo  '<script>function auto_refresh(){
       window.location="booking.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';


}else{

echo "error..";

}


?>