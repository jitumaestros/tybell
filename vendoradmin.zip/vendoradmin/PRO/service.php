<?php include ('header.php');
$countss=mysqli_num_rows(mysqli_query($conn,"select * from service"));
if(isset($_GET['deleteid'])){
mysqli_query($conn,"delete from category where id='".$_GET['deleteid']."'");
mysqli_query($conn,"delete from service where category_id='".$_GET['deleteid']."'");

echo "<script>alert('Borrado exitosamente');window.location='service.php?service=service';</script>";

}
?>
<style type="text/css">
	.cates a{
    background: white !important;
    border-bottom: 0 !important;
	}
</style>

 
<div class="services-blog-1 pro_services_block">
	<div class="services-header-blog-1">
		<div class="col-sm-12 padder">			
			<ul class="listofmenu nav nav-tabs">
				
				<li class="active">
					<a href="service.php?service=service">Todos los servicios</a>
				</li>
				<?php $sqlii=mysqli_query($conn,"select * from category ");
				while($catnm=mysqli_fetch_array($sqlii)){?>
				<li><a href="servicecat.php?catid=<?php echo $catnm['id'];?>&service=service"><?php echo $catnm['name'];?></a></li>
				<?php }?>
				<li class="last_ch"> 
					<select class="form-control tol_form-control">
						<option>Todos los servicios activos <span style="color: red;"><?php echo $countss;?></span></option>
					</select>
				</li>
			</ul>
		</div>

	</div>
</div>

	<div class="main-service-blof01 tab-content" id="0">	
		<?php
			$sqlii=mysqli_query($conn,"select * from category order by id desc");
			while($catnm=mysqli_fetch_array($sqlii))
			{
			$counts=mysqli_num_rows(mysqli_query($conn,"select * from service where category_id='".$catnm['id']."' and salon_id='".$_SESSION['user_id']."'"));
			if($counts >0){
		?>
		<div class="main-show-services">
			<div class="show-servive-header-2">
				<div class="col-sm-6 padder">
					<div class="show-services-blog-left">
						<ul>
							<li><a href="javascript:;" onclick="showservices('1');"><i class="fa fa-bars"></i></a></li>
							<li><a href=""><?php echo $catnm['name'];?></a></li>
						</ul>
					</div>
				</div>
				<div class="col-sm-6 padder">
					<div class="right-header-blo2">
						<ul class="list-button"> 
							<li><a onclick="return confirm('¿Estás seguro de que quieres eliminar?');" href="?deleteid=<?php echo $catnm['id'];?>"><i class="fa fa-trash-o" aria-hidden="true" style="color: red"></i> &nbsp;Eliminate</a></li>


							<li><a href="javascript:;" onclick="showgroup('<?php echo $catnm['id'];?>')";><i class="fa fa-pencil" aria-hidden="true"></i> &nbsp;Editar</a></li>



							<li><a href="addanotherservices.php?catid=<?php echo $catnm['id'];?>&service=service"><i class="fa fa-plus"></i> &nbsp;Anadir nuevo servicio</a></li>
						</ul>
					</div>
				</div>
			</div>


			<?php
				$sqliis=mysqli_query($conn,"select * from service where category_id='".$catnm['id']."' and salon_id='".$_SESSION['user_id']."' order by id desc ");
				while($sernm=mysqli_fetch_array($sqliis)){

				$srvlacount=mysqli_num_rows(mysqli_query($conn,"select * from service_price_level where service_id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."'"));

$discouns=mysqli_num_rows(mysqli_query($conn,"select * from promotion where salon_id='".$_SESSION['user_id']."' and service_id='".$sernm['id']."'"));


	$servicdiscount=mysqli_num_rows(mysqli_query($conn,"select * from service where id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' and offer_status='1'"));

	$servicdis=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' and offer_status='1'"));


$price=$sernm['price'];


			?>
			<div class="services--blog-1">				
				<div class="show-services--1">
					<div class="table-responsive">
						 <table class="table">
						 	<tbody>
						 		<tr>
						 			<?php 
						 			if($srvlacount >0){	 ?>
							 		<td style="width: 55%;">
							 			<div class="tab-1">
							 				<i class="fa fa-scissors"></i> 
							 				&nbsp;
							 				<span><b><?php echo $sernm['name'];?></b></span>
							 				<?php if(($discouns >0) or ($servicdiscount>0)){?>
							 				<span class="dis"><b><i class="fa fa-percent iconss" aria-hidden="true"  style=""></i>&nbsp;&nbsp;&nbsp;Descuento en  <?php echo $catnm['name'];?></b></span>
							 				<?php }?>

							 			</div>
							 		</td>
							 		<td style="width: 40%;">
							 			
							 		</td>
							 		<td>
                  <td><a href="edit_service.php?id=<?php echo $sernm['id'];?>&service=service"> <i class="fa fa-pencil"></i>  </a></td>
							 		</td>
							 		<?php }else{?>
	                               <td style="width: 55%;">
							 			<div class="tab-1">
							 				<i class="fa fa-scissors"></i> 
							 				&nbsp;
							 				<span><b><?php echo $sernm['name'];?></b></span>
							 				<?php if(($discouns >0) or ($servicdiscount>0)){?>
							 				<span class="dis"><b><i class="fa fa-percent iconss" aria-hidden="true" ></i>&nbsp;&nbsp;&nbsp;Descuento en  pelo</b></span>
							 				<?php }?>
							 			</div>
							 		</td>
							 		<td style="width: 40%;">
							 			<?php echo $sernm['duration'];?>
							 		</td>
							 		<td>
							 		$<?php echo $sernm['price'];?>	
							 		</td>
							 		<td><a href="edit_service.php?id=<?php echo $sernm['id'];?>&service=service"> <i class="fa fa-pencil"></i>  </a></td>

							 			<?php }?>
							 	</tr>
								<?php 
									$sqliids=mysqli_query($conn,"select * from service_price_level where service_id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' ");
									while($servinm=mysqli_fetch_array($sqliids)){ 
$todays=date('Y-m-d');

$servicdis=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' and offer_status='1'"));

	$offercount=mysqli_num_rows(mysqli_query($conn,"select * from promotion where service_id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' and status='0' and discount_status='1'"));

		$offercount1co=mysqli_num_rows(mysqli_query($conn,"select * from promotion where service_id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' and status='0' and discount_status='0' and start_date <='$todays' and end_date >='$todays'"));

		$offercount1=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where service_id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' and status='0' and discount_status='0' and start_date <='$todays' and end_date >='$todays'"));



if($servicdiscount >0){
$dis=$servinm['sale_price']*$servicdis['offer']/100;
$totals=$servinm['sale_price']-$dis;
}
elseif($offercount >0){
$m='1';
              $tu='2';
              $wed='3';
              $th='4';
              $fri='5';
              $st='6';
              $t=date('d-m-Y');
              $dayy= date("D",strtotime($t));
              if($dayy=='Mon'){
              $daycount=$m;
              }elseif($dayy=='Tue'){
              $daycount=$tu;
              }elseif($dayy=='Wed'){
              $daycount=$wed;
              }elseif($dayy=='Thu'){
              $daycount=$th;
              }elseif($dayy=='Fri'){
              $daycount=$fri;
              }elseif($dayy=='Sat'){
              $daycount=$st;
              }
              $date= date('H:i'); 
              /*echo $date= '11:00'; 
              */
              $mor='12:00';
              $afet='17:00';
              if(($date >=$mor) && ($date <=$afet)){
              $days='2';
              }elseif($date <=$mor){
              $days='1';
              }else{
              $days='3';
              }
              $days;

              $offerx=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where service_id='".$sernm['id']."' and salon_id='".$_SESSION['user_id']."' and status='0' and discount_status='1'"));
              $offer=mysqli_fetch_array(mysqli_query($conn,"select * from Off_peak_time where salon_id='".$_SESSION['user_id']."' and discount_id='".$offerx['discount_id']."' and day='$days' and FIND_IN_SET('$daycount', dayweekcount)"));
              $prrr=explode(',', $offer['dayweekcount']);
              $ofrd=explode(',', $offer['offer']);
              $day1=$prrr['0'];
              $day2=$prrr['1'];
              $day3=$prrr['2'];
              $day4=$prrr['3'];
              $day5=$prrr['4'];
              $day6=$prrr['5'];
              $offer1=$ofrd['0'];
              $offer2=$ofrd['1'];
              $offer3=$ofrd['2'];
              $offer4=$ofrd['3'];
              $offer5=$ofrd['4'];
              $offer6=$ofrd['5'];
              if($daycount=='1'){
              $offerper=$offer1;
              }elseif($daycount=='2'){
              $offerper=$offer2;
              }elseif($daycount=='3'){
              $offerper=$offer3;
              }elseif($daycount=='4'){
              $offerper=$offer4;
              }elseif($daycount=='5'){
              $offerper=$offer5;
              }elseif($daycount=='6'){
              $offerper=$offer6;
              }
              $totalprice=$servinm['sale_price']*$offerper/100;
              $totals=$servinm['sale_price']-$totalprice;
}elseif($offercount1co >0){

 $totalprice=$servinm['sale_price']*$offercount1['offer']/100;
  $totals=$servinm['sale_price']-$totalprice;

}else{

	$totals=$servinm['sale_price'];
}


								?>
							 	<tr>
							 		<td style="width: 55%;">
							 			<div class="tab-1" style="    padding-left: 40px;">
							 				
							 				<p><?php echo $servinm['name_price_vevel'];?></p>
							 			</div>
							 		</td>
							 		<td style="width: 40%;">
							 			<p><?php echo $servinm['duration'];?></p>
							 		</td>
							 		<td>
							 			<p class="strm"><?php if($servinm['price'] >$servinm['sale_price']){?> <span>$<DEL><?php echo $servinm['price'];?></DEL></span><?php }?><span> $<?php echo $totals;?></span></p>
							 		</td>
							 	</tr>
							 	<?php }?>
						 	</tbody>							 	
						 </table>
					</div>
				</div>					
			</div>
			<?php }?>
		</div>

		 

		<?php }}
		?>
	</div>

<div class="servicee-footer-page">
	<button class="addbtn" data-toggle="modal" data-target="#myModal" ><span data-toggle="tooltip" title="Añadir Grupo – Permite organizqr tus servicios de la forma en que prefieres que tus clientes los visualicen. Usar tipos genéricos como “Peluquería”, “Uñas”, “Masajes”, funciona mejor para ser encontrado más rápido en el buscador!"> + &nbsp; Añadir Grupo</span>
</button>
	
</div>



<!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content">
       <form method="post" id="addcate">

        <div class="modal-body padder">
        	
        	<div class="model-body-content">
        		<div class="form-group">
        			<label>Menu group name</label>
        			<input type="hidden" name="service" value="<?php echo $_GET['service'];?>">
        			<input type="text" class="form-control" name="name" required="required">
        		</div>
        	</div>
        </div>
        <div class="modal-footer myfooer-2">
          <button type="button" class="btn btn-default pull-left" data-dismiss="modal">Close</button>
          <button class="save-btn pull-right" name="submit" tybe="submit">Save</button>
          <div id="datart"></div>
        </div>
        </form>
      </div>
      
    </div>
  </div>

  <script type="text/javascript">
  	function toglless(id){
  		$('#0').hide();
  		$('#1').hide();
  		$('#2').hide();
  		$('#3').hide();
  		$('#4').hide();
  		$('#5').hide();
  		$('#6').hide();
  		
  		$('#'+id).toggle();

  	}
  </script>
<?php include ('footer.php');?>

<style type="text/css">
	.dis{

	    background: #25abb738;
    color: #25ABB7;
    margin-left: 20px;
    padding: 5px 10px;
    border-radius: 45px;
    display: inline-block;
	}
	.iconss{
	width: 20px;
    height: 20px;
    color: #fff;
    background: #25B3CC;
    border-radius: 50px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
	}
.strm
{
	display: flex;
}

.strm span
{
	margin: 4px 10px;
}


</style>


<script type="text/javascript">
	$(document).ready(function (actsd) {
		$("#addcate").on('submit',(function(actsd) {
			$("#form_abc1_img").show();
			//alert();
			actsd.preventDefault();
			$.ajax({
				url: "php/addcategory.php",
				type: "POST",
				data:  new FormData(this),
				contentType: false,
				cache: false,
				processData:false,
				success: function(data){
			//	alert(data);
			$("#form_abc1_img").hide();
			$("#datart").show().html(data);
		},
		error: function(){}          
	});
		}));
	});

function showgroup(id){

$.ajax({
       type: "POST",
         url: "showgroups.php",
            data: "id="+id, 
          success: function(html)
            {     

              $("#showgrousp").html(html);
                   $("#myModalsd").css("display","block");
                   $("#myModalsd").modal('show');
                   $("#myModalsd").addclass("in");

       
             }
        

            });

}

function showservices(id){

$.ajax({
       type: "POST",
         url: "showallservice.php",
            data: "id="+id, 
          success: function(html)
            {     

              $("#0").html(html);
                 
             }
        

            });

}


</script>

<div id="showgrousp"></div>
<script>
$(document).ready(function(){
  $('[data-toggle="tooltip"]').tooltip();
});
</script>