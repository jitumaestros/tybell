<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Payroll management</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Payroll management</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		
		<div class="table-respnsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<th>S.No.</th>
					<th > Name</th>
					<th> Address</th>
					<th>Mobile Number</th>
					<th> Email Address</th>
					<th> joining Date</th>
					<th>Timining</th>
					
					<th colspan="2"></th>
				</thead>
				<tbody>
					<tr>
						<td>1</td>
						<td><!-- <span class="squarimg"><img src="img/capello-salon-naranpura-ahmedabad-beauty-spas-1ynrr6n.jpg" alt="user" width="50"></span> -->
						Lorem Ipsum</td>
						<td>Lorem Ipsum is simply dummy text </td>
						<td>1532565t </td>
						<td>abc@gmail.com </td>
						<td>11/2/2016</td>
						<td>11:00 to 10:00</td>
						
						<td><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						<td><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
						
					</tr>
					<tr>
						<td>1</td>
						<td>Lorem Ipsum</td>
						<td>Lorem Ipsum is simply dummy text </td>
						<td>1532565t </td>
						<td>abc@gmail.com </td>
						<td>11/2/2016</td>
						<td>11:00 to 10:00</td>
						
						<td><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></td>
						<td><button type="button" class="btn btn-danger"><i class="fa fa-trash-o"></i></button></td>
						
					</tr>
				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>