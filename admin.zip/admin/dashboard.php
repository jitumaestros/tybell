<?php include ('header.php');?>
<!-- ============================================================== -->
      
            <!-- ============================================================== -->
            <!-- Container fluid  -->
            <!-- ============================================================== -->
            <div class="container-fluid">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="row page-titles">
                    <div class="col-md-6 col-8 align-self-center">
                        <h3 class="text-themecolor m-b-0 m-t-0">Dashboard</h3>
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                            <li class="breadcrumb-item active">Dashboard</li>
                        </ol>
                    </div>
                    <div class="col-md-6 col-4 align-self-center">
                        <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Start Page Content -->
                <!-- ============================================================== -->
                <!-- Row -->
                <div class="row">
                    <!-- Column -->
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title">Daily Users</h4>
                                <div class="text-right">
                                    <h2 class="font-light m-b-0"><i class="ti-arrow-up text-success"></i> $120</h2>
                                    <span class="text-muted">Total Users </span>
                                </div>
                                <span class="text-success">80%</span>
                                <div class="progress">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: 80%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                     <!-- Column -->
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title">Daily Booking</h4>
                                <div class="text-right">
                                    <h2 class="font-light m-b-0"><i class="ti-arrow-up text-success"></i> $120</h2>
                                    <span class="text-muted">Todays Income</span>
                                </div>
                                <span class="text-success">80%</span>
                                <div class="progress">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: 80%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                    <!-- Column -->
                    <div class="col-sm-4">
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title">Quantity of saloons </h4>
                                <div class="text-right">
                                    <h2 class="font-light m-b-0"><i class="ti-arrow-up text-info"></i> 30</h2>
                                    <span class="text-muted">Total saloons </span>
                                </div>
                                <span class="text-info">30%</span>
                                <div class="progress">
                                    <div class="progress-bar bg-info" role="progressbar" style="width: 30%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Column -->
                </div>
                <!-- Row -->
                <!-- Row -->
                <div class="row">
                    <!-- column -->
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-block">
                                <h4 class="card-title">Incomes</h4>
                                <div id="chartContainer" style="height: 300px; width: 100%;"></div>
                            </div>
                        </div>
                    </div>
                    <!-- column -->
                </div>
                <!-- Row -->
                <!-- Row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="card">
                            <div class="card-block">

                                <h4 class="card-title">Client of the Month</h4>
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Day" name="">
                                    <input type="text" class="form-control" placeholder="Week" name="">
                                    <input type="text" class="form-control" placeholder="Month" name="">
                                    <span class="input-group-addon">Filter</span>
                                </div>
                                <div class="table-responsive m-t-40">
                                    <table class="table stylish-table">
                                        <thead>
                                            <tr>
                                                <th>Salons</th>
                                                <th>Incomes</th>
                                                <th>Bookings</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <!-- <td style="width:50px;"><span class="round">S</span></td> -->
                                                <td>Saloon1</td>
                                                <td>$5000</td>
                                                <td>212</td>
                                            </tr>
                                            <tr class="active">
                                                <td>
                                                    Saloon2</td>
                                                <td>$5000</td>
                                                <td>212</td>
                                            </tr>
                                            <tr>
                                              <!--   <td><span class="round round-success">B</span></td> -->
                                                <td>Saloon3</td>
                                                <td>$5000</td>
                                                <td>212</td>
                                            </tr>
                                            <tr>
                                              <!--   <td><span class="round round-primary">N</span></td> -->
                                                <td>Saloon4</td>
                                                <td>$5000</td>
                                               <td>212</td>
                                            </tr>
                                            <tr>
                                               <!--  <td><span class="round round-warning">M</span></td> -->
                                                <td>Saloon5</td>
                                               <td>$5000</td>
                                                <td>212</td>
                                            </tr>
                                            <tr>
                                                <td>Saloon6</td>
                                               <td>$5000</td>
                                                <td>212</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
 <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
window.onload = function () {

var chart = new CanvasJS.Chart("chartContainer", {
    animationEnabled: true,
    theme: "light2",
    title:{
        text: "Incomes"
    },
    axisY:{
        includeZero: false
    },
    data: [{        
        type: "line",       
        dataPoints: [
            { y: 450 },
            { y: 414},
            { y: 520 },
            { y: 460 },
            { y: 450 },
            { y: 500 },
            { y: 480 },
            { y: 480 },
            { y: 410 },
            { y: 500 },
            { y: 480 },
            { y: 510 }
        ]
    }]
});
chart.render();

}
</script>
            
            <!-- End Container fluid  -->
<?php include ('footer.php');?>