<?php include('../common/config.php');

  extract($_POST);

$dates=strtotime('now');

$incident_image=$_FILES['incident_image']['name'];
move_uploaded_file($_FILES['incident_image']['tmp_name'], "../image/".$incident_image);

 $check= mysqli_query($conn,"INSERT INTO tickets (user_id, incident_image, incident_desc, assigned_to_user_id, incident_type, dates,helpdesk_assigned)VALUES ('".$_SESSION['user_id']."', '$incident_image', '$incident_desc', '$assigned_to_user_id', '$incident_type', '$dates','$helpdesk_assigned')");

 $insert_id= mysqli_insert_id($conn);

 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>Entradas creadas con éxito</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="tickets.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo 'error';
}

 ?>


