<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Execute advertising</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Execute advertising</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
		
		<div class="col-sm-12">
			<div class="form-group">
				<label>Choose advertising name</label>
				<select class="form-control">
					<option>--Select--</option>
				</select>
			</div>
		</div>
		<div class="col-sm-6">
			<div class="form-group">
				<label>Start date</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		
		<div class="col-sm-6">
			<div class="form-group">
				<label>Finish date</label>
				<input type="text" class="form-control" placeholder="" name="">
			</div>
		</div>
		
		
		
		
		<button class="addsalonbtn">Execute Advertising </button>
		
		
		
		
		

	</div>

</div>
<?php include ('footer.php');?>