<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Payroll management</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Payroll management</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">		
		<h2>Report</h2>

		<div id="chartContainer" style="height: 300px; width: 100%;"></div>
		<h2>List of employees</h2>

		<div class="table-responsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<tr>
						<th>Name</th>
						<th>Area</th>
						<th>Type</th>
						<th>Salary</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Lorem Ipsum</td>
						<td>Sales</td>
						<td>Selleres</td>
						<td>$1200</td>
					</tr>
					<tr>
						<td>Lorem Ipsum</td>
						<td>Sales</td>
						<td>Selleres</td>
						<td>$1200</td>
					</tr>
					<tr>
						<td>Lorem Ipsum</td>
						<td>Sales</td>
						<td>Selleres</td>
						<td>$1200</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>
</div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
window.onload = function() {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Report"
	},
	data: [{
		type: "pie",
		startAngle: 45,
		yValueFormatString: "##0.00\"%\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: 50.50, label: "Quantity of employees"},
			{y: 50.50, label: "Cost of employees"},
			
		]
	}]
});


chart.render();

}
</script>
<?php include ('footer.php');?>