<?php include('../../common/config.php');
extract($_POST);

$n='1';

$userss =mysqli_query($conn,"select * from users where id='$val'");

if(mysqli_num_rows($userss)==0){

 echo ' <h5><i class="fa  fa-frown-o"></i> &nbsp; No result Found.</h5>';

}

while($plynm = mysqli_fetch_array($userss)){

  
  ?>

                         <input type="hidden" name="user_id" value="<?php echo $val;?> ">
                                      <div class="col-sm-4 padder">
                                <div class="form-group input_box">
                                <span id="countt">
                                  <input type="text" placeholder="Search for Client" class="form-control" name="full_name" value="<?php echo $plynm['first_name'].' '.$plynm['last_name'];?>" onkeyup="search_client(this.value);" >
 
                                </div>
                              </div>
                              <div class="col-sm-3 ">
                                <div class="form-group input_box">
                                  <input type="text" placeholder="Phone"  class="form-control" name="phone" value="<?php echo $plynm['phone'];?>">
                                </div>
                              </div>
                              <div class="col-sm-4 padder">
                                <div class="form-group input_box ">
                                  <input type="text" placeholder="Email"  class="form-control"  class="Email" name="email" value="<?php echo $plynm['email'];?>">
                                </div>
                              </div>

  
  <?php }?>
