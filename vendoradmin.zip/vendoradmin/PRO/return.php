<?php include('../../common/config.php');
extract($_POST);

$bookincnt=mysqli_num_rows(mysqli_query($conn,"select * from bookings where user_id='".$user_id."' and id='$bookid' and  salon_id='".$_SESSION['user_id']."'"));


$strtotime=strtotime('now');

$strtotime1=strtotime($schedule_date);

$price='';

$price1='';

foreach ($service_id as $key => $valuse) {

	$serbn=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$valuse."'"));
	
$offercount=mysqli_num_rows(mysqli_query($conn,"select * from promotion where service_id='".$serbn['id']."' and status='0'"));

	$offer=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where service_id='".$serbn['id']."' and status='0'"));


	$totalprice=$serbn['price']*$offer['offer']/100;

	$totals=$serbn['price']-$totalprice;

	
	$price +=$totals;

	if($price1=='')
	{

		$price1=$totals;


	}else{

		$price1=$price1.','.$totals;
	}
}


$order_ref1=rand(10000000,999999999);

$schedules=$schedule_date.' '.$schedule_time;

$service_id1=implode(',', $service_id);

$schedule_dateq=strtotime($schedule_date);

$schedule_date1=date('m/d/Y',$schedule_dateq);
$month=date('m');

if($bookincnt > 0)
{


$mysqld = mysqli_query($conn,"update bookings set schedule_time='$schedule_time',service_id='".$service_id1."',service_price='$price1',total_amount='$price',schedule_date='".$schedule_date1."',dates='$strtotime1',status='1',staffid='$staffid',guest_name='$guest_name',schedule='$schedules',note='$note',month='$month',duration='$duration' where user_id='".$user_id."' and id='$bookid' and salon_id='".$_SESSION['user_id']."'");


}else{

$mysqld = mysqli_query($conn,"insert into bookings set user_id='".$user_id."',full_name='".$full_name."',email='".$email."',phone='$phone',schedule_time='$schedule_time',service_id='".$service_id1."',service_price='$price1',total_amount='$price',schedule_date='".$schedule_date1."',salon_id='".$_SESSION['user_id']."',dates='$strtotime1',strtotime='$strtotime',status='1',order_ref='$order_ref1',staffid='$staffid',guest_name='$guest_name',schedule='$schedules',note='$note',month='$month',duration='$duration'");


$bookid=mysqli_insert_id($conn);


/*$mysqld = mysqli_query($conn,"insert into payment set user_id='".$_SESSION['user_id']."',booking_id='".$bookid."',amount='".$price1."',total_amount='".$price."',payment_status='".$_GET['st']."',txnid='".$_GET['tx']."',strtotime='".$strtotime."',salon_id='".$_SESSION['salon_id']."',service_id='".$_SESSION['serviceid']."'");*/


$servci1d=explode(',', $servid);

foreach ($service_id as $key => $valusae) { 

	mysqli_query($conn,"insert into requested_service set service_id='$valusae',booking_id='$bookid',user_id='$user_id',salon_id='".$_SESSION['user_id']."' ");
}

$userss=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='$user_id'"));

$bokserv=mysqli_fetch_array(mysqli_query($conn,"select * from bookings where id='".$bookid."'"));

$slnm=mysqli_fetch_array(mysqli_query($conn,"select * from users where id='".$bokserv['salon_id']."'"));


$servci1w=explode(',', $bokserv['service_id']);

$sernm='';

foreach ($servci1w as $key => $valuse) {

  $serbn=mysqli_fetch_array(mysqli_query($conn,"select * from service where id='".$valuse."'"));
 
//$price +=$serbn['price'];

if($sernm==''){

$sernm=$serbn['name'];

}else{

$sernm=$sernm.' & '.$serbn['name'];

}
}



$messagetrrt.='<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tr>
        <td bgcolor="#E5376A" align="center">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
                <tr>
                    <td align="center" valign="top" style="padding: 40px 10px 40px 10px;">
                       
                    </td>
                </tr>
            </table>
        </td>
    </tr>

    <tr>
      <td bgcolor="#E5376A" align="center" style="padding: 0px 10px 0px 10px;">
          <table border="0" cellpadding="0" cellspacing="0" width="480" >
             <tr>
               <td bgcolor="#ffffff" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">
         <a href="" target="_blank">
                            <img alt="Logo" src="http://maestrosinfotech.com/Tybell/img/logo.png" width="100" height="100" style="display: block;  font-family: "Lato", Helvetica, Arial, sans-serif; color: #ffffff; font-size: 18px;" border="0">
                        </a>
                      </td>
                    </tr>
                  </table>';
     $messagetrrt.=' </td>
    </tr>
   
    <tr>
        <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
              <!-- COPY -->
              <tr>
                <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;" >
                  <h4 style="margin: 0;">Appointment</h4>
                  <p style="margin: 0;">Hola  </p>

                  <p style="margin: 0;">Esto es informarle que cita agregada por '.$slnm['first_name'].' '.$slnm['last_name'].'</p>

                  <p style="margin: 0;">Detalles de la reserva :-</p>

                  <p style="margin: 0;">Salon:- '.$slnm['business_name'].'</p>
                   <p style="margin: 0;">Location:- '.$slnm['adress'].'</p>


                    <p style="margin: 0;">Orden ref :-'.$order_ref1.'</p>

                 <p style="margin: 0;">Metido :-'.date('D M d Y', $bokserv['dates']).'  '.$bokserv['schedule_time'].' </p>

                      <p style="margin: 0;">Servicios :-'.$sernm.'</p>

                      <p style="margin: 0;">Amount : - $ '.$price.'</p>

                </td>
              </tr>
             
                  
            </table>
        </td>
    </tr>';

     $messagetrrt.='<tr>
        <td bgcolor="#f4f4f4" align="center" style="padding: 30px 10px 0px 10px;">
            <table border="0" cellpadding="0" cellspacing="0" width="480" >
                <tr>
                  <td bgcolor="#f4aec3" align="center" style="padding: 30px 30px 30px 30px; border-radius: 4px 4px 4px 4px; color: #666666; font-family: "Lato", Helvetica, Arial, sans-serif; font-size: 18px; font-weight: 400; line-height: 25px;" >
                    <h2 style="font-size: 20px; font-weight: 400; color: #111111; margin: 0;">Necesitas más ayuda?</h2>
                    <p style="margin: 0;"><a href="" style="color: #E5376A;">Nosotras son aquí, listo para hablar</a></p>
                  </td>
                </tr>
            </table>
        </td>
    </tr>
   
</table>';



     maildss($userss['email'],$userss['first_name'], 'Add Appointment' ,$messagetrrt,'');


}
echo '<div class="alert alert-success text-center">agregó una cita con éxito</div>';
echo '<script>  window.setTimeout(function () { window.location="index.php"; }, 4000);</script>';


