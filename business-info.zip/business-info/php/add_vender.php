<?php include('../../common/config.php');

  extract($_POST);

  $select = mysqli_query($conn,"SELECT * FROM users where email='$email'");
 $checkuser= mysqli_num_rows($select);

if ($checkuser >0) {
	echo '<div class="col-sm-12"><div class="alert alert-danger ">
    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
    Email  Already Registered
  </div></div>';
}
else{

 $check= mysqli_query($conn,"INSERT INTO users (business_name, type_of_business, employees, street, website, contact_number,share,postcode,first_name,last_name,city,role,email,password,district,adress,latitude,longitude)VALUES ('$business_name', '$type_of_business', '$employees', '$street', '$website', '$contact_number','$share','$postcode','$first_name','$last_name','$city','2','$email','$password','$district','$adress','$latitude','$longitude')");
 $insert_id= mysqli_insert_id($conn);

$_SESSION['user_id']=$insert_id;

 if ($check) {

   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>¡Gracias por su interés en asociarse con Tybell! Hemos recibido tu solicitud.</span>
</div></div>';
echo  '<script>function auto_refresh(){
       window.location="../vendoradmin/dashboard.php";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';


 }

else{
	echo 'error';
}

 }


?>