<?php extract($_POST);          
   
echo "<script>window.location='dashboard.php?month=$month&serviceid=$serviceid';</script>";
    ?>

