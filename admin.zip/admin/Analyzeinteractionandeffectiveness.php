<?php include ('header.php');?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Advertising Management</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Home</a></li>
                <li class="breadcrumb-item active">Advertising Management</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
				
		<div id="chartContainer" style="height: 300px; width: 100%;"></div>
	</div>
	

</div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
<script>
window.onload = function() {

var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title: {
		text: "Dashboard of KPIS by Advertising"
	},
	data: [{
		type: "pie",
		startAngle: 240,
		yValueFormatString: "##0.00\"%\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: 80.45, label: "Bookings with advertisement"},
			{y: 20.55, label: "Clicks"},
			
		]
	}]
});
chart.render();

}
</script>
<?php include ('footer.php');?>