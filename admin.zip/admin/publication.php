<?php include ('header.php');

if (isset($_GET['deleteid'])) {
mysqli_query($conn,"delete from publication where id='".$_GET['deleteid']."'");

	echo"<script>alert('Borrado exitosamente');window.location='publication.php';</script>";
}


?>
<div class="container-fluid">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">Blog de inicio</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">Blog de inicio</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <a href="add_publication.php" class="btn pull-right hidden-sm-down btn-success"> Añadir publicación
</a> 
        </div>
    </div>
	<div class="addsalon">
	
		<div class="table-respnsive">
			<table class="table table-bordered table-striped table-hover">
				<thead>
					<th>S.No.</th>
					<th>Imagen</th>

					<th>Título </th>
					<th>Descripción</th>

					<th>Fecha</th>

					<th colspan="2">Acción</th>
				</thead>
				<tbody>

<?php $saln=mysqli_query($conn,"select * from publication order by id desc");

while($salnm=mysqli_fetch_array($saln)){
?>

					<tr>
						<td>1</td>
					
						<td><img src="../image/<?php echo $salnm['image'];?>" width="100px" height="100px"></td>
						<td><?php echo $salnm['title'];?> </td>
						<td><?php echo $salnm['description'];?> </td>
						<td><?php echo date('Y-m-d',$salnm['dates']);?> </td>
						
						<td>

<a href="?deleteid=<?php echo $salnm['id'];?>" onclick="return confirm('Are Youy sure');"><button type="button" class="btn btn-primary"><i class="fa fa-trash-o" aria-hidden="true" style="color: red"></i>
</button></a>

						<a href="edit_publication.php?id=<?php echo $salnm['id'];?>"><button type="button" class="btn btn-primary"><i class="fa fa-pencil-square-o"></i></button></a></td>
						
						
					</tr>
					<?php }?>
					
				</tbody>
			</table>
		</div>

	</div>
</div>
<?php include ('footer.php');?>