<?php include ('header.php');

$edit=mysqli_fetch_array(mysqli_query($conn,"select * from promotion where id='".$_GET['id']."'"));
?>

 <link rel="stylesheet" href="datepicker/pikaday.css">
<div class="container-fluid">

<form method="post" id="addcustm" enctype="multipart/form-data">

<input type="hidden" name="ids" value="<?php echo $_GET['id'];?>">
	<div class="row page-titles">
        <div class="col-md-6 col-8 align-self-center">
            <h3 class="text-themecolor m-b-0 m-t-0">● Definir ofertas

</h3>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="javascript:void(0)">Casa</a></li>
                <li class="breadcrumb-item active">● Definir ofertas
</li>
            </ol>
        </div>
        <div class="col-md-6 col-4 align-self-center">
            <!-- <a href="https://wrappixel.com/templates/monsteradmin/" class="btn pull-right hidden-sm-down btn-success"> Upgrade to Pro</a> -->
        </div>
    </div>
	<div class="addsalon">
	
		

   <h3>Programar*</h3>

 
    <div class="col-sm-6">

      <div class="form-group">
        <label> Fecha de inicio de la oferta*</label>
        <input type="text" class="form-control" placeholder="" name="offer_start_date" id="dater" autocomplete="off" value="<?php echo date('D M d Y ', $edit['offer_start_date']);?>">
      </div>
    </div>


<div class="col-sm-6">
      <div class="form-group">
        <label>Fecha de cierre de la oferta</label>
        <input type="text" class="form-control" placeholder="" name="offer_end_date" id="daters" autocomplete="off" value="<?php echo date('D M d Y ', $edit['offer_end_date']);?>">
      </div>
    </div>

    
    
		<div class="col-sm-6">
			<div class="form-group">
				<label>Servicio*</label>
				<select class="form-control" name="service_id" value="<?php echo $edit['name'];?>">
<option value="<?php echo $edit['service_id'];?>"><?php $sernm=mysqli_fetch_array(mysqli_query($conn,"select * from service where id ='".$edit['service_id']."'")); echo $sernm['name'];?></option>
<?php $sqliiii=mysqli_query($conn,"select * from service where salon_id ='".$_SESSION['user_id']."'");
while($ser=mysqli_fetch_array($sqliiii)){ ?>

<option value="<?php echo $ser['id'];?>"><?php echo $ser['name'];?></option>
  <?php 
}
?>

        </select>


			</div>
		</div>


		
<div class="col-sm-6">
      <div class="form-group">
        <label>Oferta*</label>
        <input type="text" class="form-control" placeholder="" name="offer"  value="<?php echo $edit['offer'];?>">
      </div>
    </div>
    
		<button class="addsalonbtn" name="submit" type="submit">Añadir servicio 
</button>
		
	</div>
	<div id="datart"></div>
	</form>
</div>
<?php include ('footer.php');?>
    <script src="datepicker/pikaday.js"></script>

<script type="text/javascript">
	
$(document).ready(function (custm) {
 $("#addcustm").on('submit',(function(custm) {
 	   	//alert();

  $("#form_abc1_img").show();
  custm.preventDefault();
  $.ajax({
   url: "php/edit_service_offer.php",
   type: "POST",
   data:  new FormData(this),
   contentType: false,
         cache: false,
   processData:false,
   success: function(data){
   	//alert();
     $("#form_abc1_img").hide();
   $("#datart").show().html(data);
      },
     error: function(){}          
    });

 }));
});



  new Pikaday(
  {
    field: document.getElementById('dater'),
    trigger: document.getElementById('datepicker-button'),
    minDate: new Date(2000, 0, 1),
    ariaLabel: 'Custom label',
    maxDate: new Date(2020, 12, 31),
    yearRange: [2010,2020]

  });



    new Pikaday(
  {
    field: document.getElementById('daters'),
    trigger: document.getElementById('datepicker-button'),
    minDate: new Date(2000, 0, 1),
    ariaLabel: 'Custom label',
    maxDate: new Date(2020, 12, 31),
    yearRange: [2010,2020]

  });
</script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA4mlo-kY0vyBDIdeXffR2igqE5igx3piE&sensor=false&libraries=places"></script>

<script type="text/javascript">


  google.maps.event.addDomListener(window, 'load', function () {

  /*  var options = {

      componentRestrictions: {country: "in"}
    };*/
    var places = new google.maps.places.Autocomplete(document.getElementById('txtPlacesss'));

    google.maps.event.addListener(places, 'place_changed', function () {

      var place = places.getPlace();

      var address = place.formatted_address;

      var latitude = place.geometry.location.lat();

      var longitude = place.geometry.location.lng();

      var mesg = "Address: " + address;

      mesg += "\nLatitude: " + latitude;

      mesg += "\nLongitude: " + longitude;


      $("#latitude").val(latitude);
      $("#longitude").val(longitude);

    });

  });






</script> <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
  <script>tinymce.init({ selector:'textarea' });</script>


  <style type="text/css">
      
.mce-notification-warning{

display: none;

}

  </style>