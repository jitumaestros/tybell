<?php
session_start();
$conn = mysqli_connect("localhost", "incarhlt_tybell", "123456");
mysqli_select_db($conn,"incarhlt_tybell");

mysqli_set_charset($conn,'utf8');

$baseurl = "https://maestrosinfotech.com/Tybell/";
$adminurl = "http://maestrosinfotech.com/Tybell/admin/";
$vendorurl = "http://maestrosinfotech.com/Tybell/vendoradmin/";
date_default_timezone_set('Asia/Calcutta');

$server_mail = "customersupport@homechow.co.za";
$from = "Tybell";


$admin_details = mysqli_fetch_array(mysqli_query($conn,"select * from signup where id='".$_SESSION['admin_id']."'"));


function mime_content_types($filename) {

  $mime_types = array(

      'txt' => 'text/plain',
      'htm' => 'text/html',
      'html' => 'text/html',
      'php' => 'text/html',
      'css' => 'text/css',
      'js' => 'application/javascript',
      'json' => 'application/json',
      'xml' => 'application/xml',
      'swf' => 'application/x-shockwave-flash',
      'flv' => 'video/x-flv',

      // images
      'png' => 'image',
      'jpe' => 'image',
      'jpeg' => 'image',
      'jpg' => 'image',
      'gif' => 'image',
      'bmp' => 'image',
      'ico' => 'image',
      'tiff' => 'image',
      'tif' => 'image',
      'svg' => 'image',
      'svgz' => 'image',

      // archives
      'zip' => 'application/zip',
      'rar' => 'application/x-rar-compressed',
      'exe' => 'application/x-msdownload',
      'msi' => 'application/x-msdownload',
      'cab' => 'application/vnd.ms-cab-compressed',

      // audio/video
      'mp3' => 'audio',
      'qt' => 'video',
      'mov' => 'video',
      'mp4' => 'video',
	  'wav' => 'audio',

      // adobe
      'pdf' => 'pdf',
      'psd' => 'image/',
      'ai' => 'file',
      'eps' => 'file',
      'ps' => 'file',

      // ms office
      'doc' => 'file',
      'rtf' => 'file',
      'xls' => 'file',
      'ppt' => 'file',

      // open office
      'odt' => 'file',
      'ods' => 'file',
  );


// print_r($mime_types);
  $ext = strtolower(array_pop(explode('.',$filename)));
 // echo $ext;
  
   foreach ($mime_types as $key => $value) {
   // echo $ext."   ".$key."///";
    if($ext==$key){
     $type =  $value;
    }
   }
  
  
if($type!=""){
return $type;
}else{
return 'file';
}

}



//echo  mime_content_types('dsfsdf.png');
//echo  mime_content_types('dsfsdf.mp4');








//--------------------------------------------



function get_image_mime_type($image_path)
{
    $mimes  = array(
        IMAGETYPE_GIF => "image/gif",
        IMAGETYPE_JPEG => "image/jpg",
        IMAGETYPE_PNG => "image/png",
        IMAGETYPE_SWF => "image/swf",
        IMAGETYPE_PSD => "image/psd",
        IMAGETYPE_BMP => "image/bmp",
        IMAGETYPE_TIFF_II => "image/tiff",
        IMAGETYPE_TIFF_MM => "image/tiff",
        IMAGETYPE_JPC => "image/jpc",
        IMAGETYPE_JP2 => "image/jp2",
        IMAGETYPE_JPX => "image/jpx",
        IMAGETYPE_JB2 => "image/jb2",
        IMAGETYPE_SWC => "image/swc",
        IMAGETYPE_IFF => "image/iff",
        IMAGETYPE_WBMP => "image/wbmp",
        IMAGETYPE_XBM => "image/xbm",
        IMAGETYPE_ICO => "image/ico");

    if (($image_type = exif_imagetype($image_path))
        && (array_key_exists($image_type ,$mimes)))
    {
      $sdf = explode("/", $mimes[$image_type]);
        return $sdf[0];
    }
    else
    {


        return FALSE;
    }
}

   


 //get half para
function limit_words($string, $word_limit)
{
    $words = explode(" ",$string);
    return implode(" ",array_splice($words,0,$word_limit));
}

         


function mailds($email,$name,$subject,$messagesd,$rett){
$server_mail= "maya@maestros.co.in";
  $from = "christian";
$baseurl = "http://ruparnatechnology.com/christian/";
define('TO_EMAIL', $email);
define('TO_NAME', $name);
 
define('FROM_EMAIL', $server_mail);
define('FROM_NAME', $from);
 



 $message='<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>

  
<div style="    width: 83%;  padding: 20px;  border: 10px solid #F2F5F8;  margin: 0 auto; background: #F2F5F8; border-radius: 7px;">
<div style="    padding: 20px;  border: 5px solid #F2F5F8;  background: #F2F5F8;">
  

  <center><img src="'.$baseurl.'image/logo.png"></center>

      
'.$messagesd.'
<br/>
<br /><br />
         
       
       <span style="font-size:18px">Thanks</span>
</div>
</div>   
</body>
</html>';


$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: maya@maestrossoftware.com';
//$headers .= 'reply-to: ' . $email;

if(mail($email, $subject, $messagesd, $headers)){

if($rett!=""){

            echo '<div class="alert alert-success" id="success-alrt" >
    <button type="button" class="close" data-dismiss="alert" style="margin-left: 5px">  x  </button>
    <strong > '.$rett.'</strong></div>';
}

  
}else{
  echo 'errorr';
}    

 }




   // mailds('atul.maestros@gmail.com','atul','test44444444444','dfgdfgdfgdfgdfg dg dfg121313','success');

   /*              
 $headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: ruparnatechnology@ruparnatechnology.com';

  if(mail('atul.maestros@gmail.com', 'test', 'fgjdshgfshjg hjsd', $headers)){
 echo "dfdshfjdsf";
  }else{
    echo "ni gaya";
  }

*/


function  gettimeselecr($name,$val){

echo '<select style="" name="'.$name.'" class="form-control">';

$m = 00;
$h =00;
 for($i = 01;$i<=96;$i++){ 



if($m==0){
  $m =00;
} 
  

  $h=sprintf("%02d",$h);
  $m=sprintf("%02d",$m);

  //  echo $h .':'.$m.'<br>';
  if($val==$h.':'.$m){
$sel = 'selected';
  }else{
$sel = '';
  }
  //str_pad();
echo '<option value="'.$h.':'.$m.'" '.$sel.'>'.$h.':'.$m.'</option>';
  $m+=15;

  if($m==60){
    $m = 00;
    $h++;
  }
         } 

echo '</select>';
}







function  roles($status){
  if($status==1){
  $ret = 'Patient';
  }elseif($status==2){
    $ret = 'Doctor';
  }elseif($status==3){
    $ret = 'Surveyor';
   }elseif($status==4){
    $ret = 'Supervisor';
  }elseif($status==5){
 $ret = 'Transcriber';
  }else{
     $ret = 'Manager';
  }

return $ret;

}




function  case_status($status){
  if($status==3){
  $ret = 'Case Under Review';
  }elseif($status==4){
    $ret = 'Sent to UK';
  }elseif($status==5){
    $ret = 'Document Process';
   }elseif($status==6){
    $ret = 'RSI';
  }elseif($status==7){
 $ret = 'Feedback';
  }else{
     $ret = 'File Upload';
  }

return $ret;

}


function  case_chat_status($status){
  if($status==0){
  $ret = "doctor's engaged";
  }elseif($status==1){
    $ret = 'ongoing problem';
  }elseif($status==2){
    $ret = 'resolved';
   }elseif($status==3){
    $ret = 'follow up needed';
   }


return $ret;

}




function maildss($email,$name,$subject, $messagetrrt,$rettmsg){

 $baseurl =  (isset($_SERVER['HTTPS']) ? "https" : "http") . '://'.$_SERVER['HTTP_HOST'].'/Tybell/';

$from = 'Tybell';

  require_once('SMTP/PHPMailer_5.2.0/class.phpmailer.php');

  $mail = new PHPMailer(true); // the true param means it will throw exceptions on errors, which we need to catch

$mail->IsSMTP(); // telling the class to use SMTP

try {

  $mail->Host       = "mail.maestrosinfotech.com"; // SMTP server 

  $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
  $mail->SMTPAuth   = true;                  // enable SMTP authentication
  $mail->Host       = "mail.maestrosinfotech.com"; // sets the SMTP server

  $mail->Port       = 587;              // set the SMTP port for the GMAIL server
  $mail->Username   = "supprts@maestrosinfotech.com"; // SMTP account username
  $mail->Password   = "Maestros@123";        // SMTP account password
  $mail->AddReplyTo('supprts@maestrosinfotech.com', 'Tybell');

  $mail->AddAddress($email, $name);

  $mail->SetFrom('supprts@maestrosinfotech.com', 'Tybell');
  $mail->AddReplyTo('supprts@maestrosinfotech.com', 'Tybell');
  $mail->Subject = $subject;
  $mail->AltBody = 'To view the message, please use an HTML compatible email viewer!'; // optional - MsgHTML will create an alternate automatically
$message='<head><link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet"><meta http-equiv="Content-Type" content="text/html; charset=utf-8" />';

$message.='<title>linkus</title></head><body style="font-family:  arial;"><style>span{ font-size:13px;}</style>';

$message.='<div style="width: 83%;  padding: 55px;  border: 10px solid #F2F5F8;  margin: 0 auto; background: #F2F5F8; border-radius: 7px;"><div style="padding: 20px;  border: 5px solid #F2F5F8;  background: #F2F5F8;font-size: 13px;">';
$message.=$messagetrrt;

  $message.='<br/><br><br><br><strong></strong><br><br><a href="'.$baseurl.'"></a><br><a href="mailto:support@easytosuccess"></a><br>';

$message.= '<span style="font-size:14px">Gracias, Las '.$from.' Equipo</span><br/><div style="float:left"></div><br></div><br><br>';

$message.= ' </div></body>';
$mail->MsgHTML($message);

 if($rettmsg!='0'){

  if($mail->Send()) {

  return 'email success'; 

}else{

  return "Error in sending..";

}

}

} catch (phpmailerException $e) {

   $e->errorMessage(); //Pretty error messages from PHPMailer

} catch (Exception $e) {
   $e->getMessage(); //Boring error messages from anything else!

}

}



//echo maildss('lauryneagle18@gmail.com','dgdfggg name ', 'Your Solvn lisjgjyyyyyyyyy sub' ,'test mesas jj msgg','');







//echo  mailsmtp('atul.maestros@gmail.com','gffghfgh12312312 name','dfgdfgdfgdfgdfg dg dfg121313 msg ','subb','rttt');







































?>