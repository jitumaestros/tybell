<?php include('../../../common/config.php');

extract($_POST);


foreach ($day as $key => $value) {


$check= mysqli_query($conn,"INSERT INTO salon_opening_hr (salon_id, day, start_time, end_time)VALUES ('".$_SESSION['user_id']."', '$value', '$start_time[$key]', '$end_time[$key]')");

}


 if ($check) {
   echo '<div class="col-sm-12"><div class="alert alert-success alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span> Horario de apertura agregado con éxito..</span>
</div></div>';

echo  '<script>function auto_refresh(){
       window.location="setting.php?setting=setting";
    }
    var refreshId = setInterval(auto_refresh, 3000);
</script>';

 }
else{
	echo '<div class="col-sm-12"><div class="alert alert-danger alert-dismissible">
  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
  <span>error</span>
</div></div>';

	
}

 


?>